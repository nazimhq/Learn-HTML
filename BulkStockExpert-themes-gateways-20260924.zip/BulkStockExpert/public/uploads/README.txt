Uploaded images (product photos, category tiles, logo) are stored here at runtime.
Keep this folder when you upload a new version of the source.
