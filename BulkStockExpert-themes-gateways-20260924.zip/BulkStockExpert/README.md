# BulkStockExpert upgraded source

Start with [WHATS-NEW.md](WHATS-NEW.md) for everything added in the latest update (second site design, automatic theme changer, five more payment gateways, new admin pages, bug fixes). Then [UPGRADE.md](UPGRADE.md) for implemented scope, exact source paths, configuration, migration and deployment steps. Read [VERIFICATION.md](VERIFICATION.md) for completed checks and remaining acceptance tests. This is a source release, not a tested live deployment.
