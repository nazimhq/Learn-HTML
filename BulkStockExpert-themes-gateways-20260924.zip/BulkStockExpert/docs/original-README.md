# Bramleigh — UK General Store

A complete, general-purpose online store built for the UK market: electronics, home, fashion
and beauty in one catalogue. Node.js throughout (Next.js/Prisma) — no PHP anywhere.

"Bramleigh" is a placeholder brand name — renaming it is a two-minute job (see **Renaming the
brand** below), nothing is hardcoded to the name beyond `.env` and the seed data.

## Stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · Prisma + PostgreSQL · Zustand ·
React Hook Form + Zod · NextAuth (admin login) · Nodemailer (order emails) · lucide-react

## What's built

- **Storefront** — home page, catalogue with category/brand/price/stock filters and sorting,
  product detail pages (gallery, variant picker, live stock, reviews), a basket drawer.
- **Checkout** — one-page checkout (React Hook Form + Zod), server-side re-pricing (never
  trusts client-sent prices), a coupon code field, and **UK delivery zones matched
  automatically from the postcode** (Highlands & Islands / Northern Ireland surcharges, free-
  delivery thresholds — all admin-editable, see below).
- **Order confirmation + email notifications** — the moment an order is placed, the customer
  gets a confirmation email and the admin inbox gets a new-order alert with the delivery area,
  items and total (`src/lib/email.ts`, wired in `src/app/actions/checkout-actions.ts`). Order
  status changes (e.g. marking an order "Shipped") also email the customer automatically.
- **Order tracking** — `/track-order` (order number + email) shows a live status timeline plus
  a full activity log, backed by `Order.status` + `OrderActivityLog`.
- **Admin panel** (`/admin`, NextAuth-gated, `ADMIN` role only):
  - Dashboard — orders, revenue, low-stock count.
  - Orders — list, filter by status, detail page with status updates (emails the customer),
    tracking number entry, payment status, and an **admin-only cost/margin view** per order.
  - Products — list + edit (price, compare-at price, hidden cost price, stock, status) per
    variant. Cost price is never selected on any storefront query
    (`src/lib/queries/product-select.ts`) — only admin pages ever read it.
  - **Delivery & Settings** — add/edit/delete delivery zones and their charges, free-delivery
    thresholds and postcode-prefix matching, plus site name/tagline/contact/VAT settings — all
    from the UI, no code changes needed.
  - **Tracking** (same Settings page) — Meta (Facebook) Pixel ID, Google Analytics 4 Measurement
    ID, an optional GTM container ID, and the WhatsApp quick-order number. Save an ID and it
    fires on every storefront page immediately (`src/components/storefront/tracking-scripts.tsx`)
    — leave any of them blank and that script simply doesn't load. The WhatsApp number also
    powers the floating chat button site-wide and the "Order via WhatsApp" link on every product
    page (`src/components/storefront/whatsapp-button.tsx`).

## Getting started

```bash
npm install
cp .env.example .env        # fill in DATABASE_URL, SMTP_*, NEXTAUTH_SECRET at minimum
npm run db:push             # creates tables from prisma/schema.prisma
npm run db:seed             # sample catalogue, delivery zones, admin user
npm run dev                 # http://localhost:3000
```

Admin login after seeding: **admin@bramleigh.co.uk / ChangeMe123!** — change this password
immediately (there's no self-service "change password" screen yet; update it directly via
Prisma Studio (`npm run db:studio`) with a fresh `bcrypt` hash, or add a small script).

This sandbox's own network policy blocks `npm install` from a Claude session, so this code has
been written and reviewed by hand, not `npm run dev`-tested inside this sandbox — run it on
your own machine or the live host to install dependencies and try it for real. Everything
follows the same patterns already proven working in your Bangladesh HASN Store build.

### Database

Most cheap/shared cPanel plans don't include PostgreSQL. The easiest fix is a free hosted
Postgres you point `DATABASE_URL` at — Neon (neon.tech) or Supabase both have a generous free
tier and a connection string ready in under a minute. Your host doesn't need to run the
database itself, only the Node.js app.

### Email

`.env.example` defaults to SMTP using a mailbox your domain's cPanel gives you (cPanel → Email
Accounts → create e.g. `orders@yourdomain`, then use its SMTP host/port/user/password). If your
Node host can shell out to `sendmail`, swap the transport in `src/lib/email.ts` for
`nodemailer.createTransport({ sendmail: true })` instead — no SMTP credentials needed. Either
way, order confirmation + admin alert emails are already wired into checkout; you only need to
fill in the four `SMTP_*`/`EMAIL_FROM`/`ADMIN_NOTIFICATION_EMAIL` variables.

### Renaming the brand

1. `.env` → `NEXT_PUBLIC_SITE_NAME`
2. `/admin/settings` → Site name, tagline, contact details (this is what actually renders —
   the `.env` value is only the pre-database-seed fallback)
3. `prisma/seed.ts` → the sample data if you want the seeded catalogue to match

## Deploying to your cPanel host (Node.js app, not PHP)

Your host already runs at least one Node.js app successfully via cPanel's own **"Setup Node.js
App"** feature (Passenger), so the same approach should work cleanly here — this is simpler
than a Python/FastAPI deploy, since Passenger supports Node natively (no WSGI bridge needed).

1. cPanel → **Setup Node.js App** → Create Application → pick a Node version (18+), set the
   **Application root** (e.g. `bramleigh`) and **Application URL** (your chosen subdomain — see
   the note below on subdomain availability first). For the startup file, `npm run build` then
   `npm run start` as the app's start command if your cPanel Node.js App UI lets you set a
   custom start command; otherwise point it at a small `server.js` wrapper that calls Next's
   `next start` (the standard Next.js custom-server pattern).
2. Upload the project (excluding `node_modules`), then use the Node.js App UI's own "Run NPM
   Install" button (it runs inside the correct Node environment) followed by `npm run build`.
3. Set every `.env` variable from `.env.example` in the App's "Environment variables" panel
   (or a `.env` file in the app root — Next.js reads it automatically).
4. Point `DATABASE_URL` at your hosted Postgres (see above), then run `npm run db:push` and
   `npm run db:seed` once via the App's "Run JS Script" / terminal feature.
5. Restart the app from the Node.js App UI after every deploy.

**One thing worth flagging before you pick a subdomain**: on this same hosting account, the
last time I checked, the subdomain slots were capped at 2/2 (already used by two other sites).
If that's still the case, either free one up, ask your host to raise the limit, or we deploy
this one as a path under an existing domain instead (e.g. `yourdomain.com/store/`) the same way
Hizli Wholesale was done — both work fine, just say which you'd prefer once we get to this step.

## Payments

`paymentMethod` (Card/PayPal) is captured at checkout and the order is created with
`paymentStatus: PENDING` so you can test the entire flow — catalogue → basket → checkout →
confirmation email → tracking — without a live payment gateway. Wiring up real Stripe/PayPal
charging is a follow-up step (add the gateway's SDK, capture payment before `placeOrder` marks
`paymentStatus: PAID`) — ask when you're ready and it can be added without touching the rest of
the checkout flow.

## Notes on the hidden cost/margin feature

Every `Product`/`ProductVariant` has an optional `costPrice` (what you paid for it). It is
never included in any customer-facing query — `src/lib/queries/product-select.ts` is the single
shared `select` shape every storefront page imports, deliberately omitting `costPrice`, so this
can't leak by accident. The admin Products and Order Detail pages read it directly from Prisma
(not through that shared file) to show per-product and per-order margin.
