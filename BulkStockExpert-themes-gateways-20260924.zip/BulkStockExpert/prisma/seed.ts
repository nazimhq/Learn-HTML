import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Wiping existing data...");
  await prisma.orderActivityLog.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.review.deleteMany();
  await prisma.productImage.deleteMany();
  await prisma.productVariant.deleteMany();
  await prisma.product.deleteMany();
  await prisma.category.deleteMany();
  await prisma.brand.deleteMany();
  await prisma.deliveryZone.deleteMany();
  await prisma.coupon.deleteMany();
  await prisma.user.deleteMany();
  await prisma.appSettings.deleteMany();

  console.log("Seeding settings...");
  await prisma.appSettings.create({
    data: {
      id: "singleton",
      siteName: "Bramleigh",
      tagline: "Everyday essentials, considered.",
      contactEmail: "hello@bramleigh.co.uk",
      contactPhone: "+44 20 7946 0958",
      adminNotificationEmail: process.env.ADMIN_NOTIFICATION_EMAIL ?? "admin@bramleigh.co.uk",
      currency: "GBP",
      vatRate: 20,
      pricesIncludeVat: true,
      freeShippingOverAmount: 60,
      // Tracking is optional — leave blank until you have real IDs; the storefront simply skips
      // any script whose ID is unset. Set these here or later from /admin/settings → Tracking.
      metaPixelId: process.env.NEXT_PUBLIC_META_PIXEL_ID || null,
      gaMeasurementId: process.env.NEXT_PUBLIC_GA4_ID || null,
      gtmContainerId: process.env.NEXT_PUBLIC_GTM_ID || null,
      whatsappNumber: process.env.WHATSAPP_NUMBER || "+44 7123 456789",
    },
  });

  console.log("Seeding admin user (email: admin@bramleigh.co.uk / password: ChangeMe123!)...");
  await prisma.user.create({
    data: {
      name: "Store Admin",
      email: "admin@bramleigh.co.uk",
      passwordHash: await bcrypt.hash("ChangeMe123!", 10),
      role: "ADMIN",
      isSuperAdmin: true,
    },
  });

  console.log("Seeding delivery zones...");
  await prisma.deliveryZone.createMany({
    data: [
      {
        name: "UK Mainland Standard",
        description: "England, Wales & mainland Scotland",
        charge: 3.99,
        freeOverAmount: 60,
        postcodePrefixes: [],
        estimatedDays: "2-4 working days",
        position: 0,
      },
      {
        name: "UK Mainland Express",
        description: "Next working day, order before 2pm",
        charge: 6.99,
        postcodePrefixes: [],
        estimatedDays: "1 working day",
        position: 1,
      },
      {
        name: "Highlands & Islands",
        description: "Scottish Highlands, Islands & remote postcodes — small surcharge applies",
        charge: 8.99,
        freeOverAmount: 90,
        postcodePrefixes: ["IV", "KW", "ZE", "HS", "PH19", "PH20", "PH21", "PA20", "PA38", "KA27", "KA28"],
        estimatedDays: "3-5 working days",
        position: 2,
      },
      {
        name: "Northern Ireland & Channel Islands",
        description: "BT, GY and JE postcodes",
        charge: 7.99,
        postcodePrefixes: ["BT", "GY", "JE"],
        estimatedDays: "3-5 working days",
        position: 3,
      },
    ],
  });

  console.log("Seeding coupon...");
  await prisma.coupon.create({
    data: { code: "WELCOME10", type: "PERCENT", value: 10, minSubtotal: 25, isActive: true },
  });

  console.log("Seeding categories & brands...");
  const [electronics, home, fashion, beauty] = await Promise.all([
    prisma.category.create({ data: { name: "Electronics", slug: "electronics", position: 0 } }),
    prisma.category.create({ data: { name: "Home & Living", slug: "home-living", position: 1 } }),
    prisma.category.create({ data: { name: "Fashion", slug: "fashion", position: 2 } }),
    prisma.category.create({ data: { name: "Beauty & Care", slug: "beauty-care", position: 3 } }),
  ]);

  const [audioCo, hearth, wearwell, glowLab] = await Promise.all([
    prisma.brand.create({ data: { name: "AudioCo", slug: "audioco" } }),
    prisma.brand.create({ data: { name: "Hearth & Home", slug: "hearth-home" } }),
    prisma.brand.create({ data: { name: "Wearwell", slug: "wearwell" } }),
    prisma.brand.create({ data: { name: "GlowLab", slug: "glowlab" } }),
  ]);

  console.log("Seeding products...");
  const products = [
    {
      name: "Wireless Noise-Cancelling Earbuds",
      slug: "wireless-noise-cancelling-earbuds",
      description:
        "Active noise cancellation, 28-hour total battery life with the case, and IPX5 sweat resistance. Pairs instantly with two devices at once.",
      tags: ["wireless", "audio", "anc"],
      categoryId: electronics.id,
      brandId: audioCo.id,
      basePrice: 59.0,
      compareAtPrice: 79.0,
      costPrice: 21.5,
      variants: [
        { sku: "ANC-EB-BLK", label: "Onyx Black", price: 59.0, compareAtPrice: 79.0, costPrice: 21.5, stock: 46 },
        { sku: "ANC-EB-WHT", label: "Chalk White", price: 61.0, compareAtPrice: 81.0, costPrice: 22.0, stock: 22 },
      ],
    },
    {
      name: "Ceramic Pour-Over Coffee Set",
      slug: "ceramic-pour-over-coffee-set",
      description:
        "Hand-glazed ceramic dripper, matching carafe and reusable stainless filter. Dishwasher safe, holds up to 600ml.",
      tags: ["kitchen", "coffee"],
      categoryId: home.id,
      brandId: hearth.id,
      basePrice: 34.0,
      compareAtPrice: null,
      costPrice: 11.0,
      variants: [{ sku: "POUR-SET-STD", label: "Standard", price: 34.0, compareAtPrice: null, costPrice: 11.0, stock: 31 }],
    },
    {
      name: "Merino Wool Crew Jumper",
      slug: "merino-wool-crew-jumper",
      description:
        "100% extra-fine merino wool, mid-weight, naturally temperature-regulating. Ethically sourced and machine washable on wool cycle.",
      tags: ["knitwear", "wool"],
      categoryId: fashion.id,
      brandId: wearwell.id,
      basePrice: 68.0,
      compareAtPrice: 92.0,
      costPrice: 24.0,
      variants: [
        { sku: "MER-JUMP-S", label: "Forest Green / S", price: 68.0, compareAtPrice: 92.0, costPrice: 24.0, stock: 14 },
        { sku: "MER-JUMP-M", label: "Forest Green / M", price: 68.0, compareAtPrice: 92.0, costPrice: 24.0, stock: 19 },
        { sku: "MER-JUMP-L", label: "Forest Green / L", price: 70.0, compareAtPrice: 94.0, costPrice: 24.5, stock: 9 },
      ],
    },
    {
      name: "Vitamin C Brightening Serum",
      slug: "vitamin-c-brightening-serum",
      description:
        "20% vitamin C with hyaluronic acid, formulated to even skin tone and fade dark spots. Lightweight, fast-absorbing.",
      tags: ["skincare", "serum"],
      categoryId: beauty.id,
      brandId: glowLab.id,
      basePrice: 24.0,
      compareAtPrice: null,
      costPrice: 6.5,
      variants: [
        { sku: "VITC-30", label: "30ml", price: 24.0, compareAtPrice: null, costPrice: 6.5, stock: 58 },
        { sku: "VITC-50", label: "50ml", price: 34.0, compareAtPrice: null, costPrice: 9.5, stock: 27 },
      ],
    },
    {
      name: "Cast Iron 3-Piece Cookware Set",
      slug: "cast-iron-3-piece-cookware-set",
      description:
        "Pre-seasoned cast iron skillet, grill pan and casserole dish. Oven-safe to 260°C, suitable for induction.",
      tags: ["kitchen", "cookware"],
      categoryId: home.id,
      brandId: hearth.id,
      basePrice: 89.0,
      compareAtPrice: 120.0,
      costPrice: 38.0,
      variants: [{ sku: "CAST-3PC", label: "Standard", price: 89.0, compareAtPrice: 120.0, costPrice: 38.0, stock: 12 }],
    },
    {
      name: "Water-Resistant Commuter Backpack",
      slug: "water-resistant-commuter-backpack",
      description:
        "20L, padded 15\" laptop sleeve, YKK zips and a hidden anti-theft back pocket. Recycled ripstop fabric.",
      tags: ["bags", "commuter"],
      categoryId: fashion.id,
      brandId: wearwell.id,
      basePrice: 45.0,
      compareAtPrice: null,
      costPrice: 15.0,
      variants: [{ sku: "BKPK-20L", label: "Slate Grey", price: 45.0, compareAtPrice: null, costPrice: 15.0, stock: 0 }],
    },
  ];

  for (const p of products) {
    const { variants, ...rest } = p;
    const created = await prisma.product.create({
      data: {
        ...rest,
        images: { create: [{ url: "", altText: p.name, position: 0 }] },
        variants: { create: variants },
      },
    });
    await prisma.review.createMany({
      data: [
        {
          productId: created.id,
          customerName: "Olivia P.",
          rating: 5,
          comment: "Exactly as described and arrived faster than expected. Really pleased with the quality.",
          status: "APPROVED",
        },
        {
          productId: created.id,
          customerName: "James T.",
          rating: 4,
          comment: "Good value, would buy again.",
          status: "PENDING",
        },
      ],
    });
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
