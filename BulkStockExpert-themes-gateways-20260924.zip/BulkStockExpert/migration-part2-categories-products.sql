-- BulkStockExpert Ltd (hr.sarvice.top) — part 2: category logo uploads.
-- Run this in phpMyAdmin against sarvicet_bramleigh, IN ADDITION to migration-new-features.sql
-- (run that one first if you haven't already — this one only adds one column).

ALTER TABLE `Category` ADD COLUMN `imageUrl` VARCHAR(191) NULL;

-- No new table is needed for product creation/images — Product and ProductImage already
-- existed in the schema; the admin panel simply gained a UI to use them (create products,
-- attach uploaded image files) that wasn't built before.
