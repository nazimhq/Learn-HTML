# What's new in this update

Everything from the previous version is still here. This update adds a second site design with
an automatic theme changer, five more payment gateways, new admin screens, and fixes a number of
bugs found by running the app against a real database and browser.

Read this file first, then `UPGRADE.md` for the original feature list and deployment notes.

---

## 1. Two site designs, switchable from the admin panel

**Admin → Design & themes** (new page).

| Design | Look |
| --- | --- |
| **Classic** | The original warm, editorial storefront. Unchanged. |
| **NEXAWEB** | Near-black background, electric-purple accent, thin borders, soft glow, Space Grotesk + Inter fonts. |

- Switching the design changes the whole storefront **and** the admin panel.
- The six accent colours (Bright Red, Deep Gold, Burgundy, Warm Yellow, Black, and the new
  **Electric Purple**) still work with either design, so colour customisation is not lost.
- The NEXAWEB design is dark by design, so the visitor light/dark switch hides itself while it
  is active. Classic keeps light/dark exactly as before.
- Each design shows a small live preview in the admin panel before you apply it.

## 2. Automatic theme change (timer)

On the same page, with an **On/Off switch** you control:

- **Every few hours** — cycle through your chosen looks, e.g. every 5 or 6 hours. Presets for
  3h, 5h, 6h, 12h and 24h, or type any number of hours.
- **At set times each day** — for example Classic from 08:00 and NEXAWEB from 18:00, in the time
  zone you choose (e.g. `Asia/Dhaka`, `Europe/London`).
- Each entry in the rotation is a design + accent colour + light/dark, and you can add or remove
  entries freely.
- The admin page tells you which look is live now and when it changes next.
- **No cron job or background worker is needed.** The active look is worked out from the clock,
  so every visitor and every server sees the same thing. Pages that are already open switch
  themselves within a few seconds, and exactly on time at a scheduled change.
- Turning the switch off immediately returns the store to your fixed design.

## 3. Five more payment gateways (real, working integrations)

Added alongside the existing Stripe, PayPal, Klarna, Clearpay, SSLCommerz and cash on delivery:

| Gateway | Countries | What customers can pay with |
| --- | --- | --- |
| **bKash** (direct) | Bangladesh | bKash wallet, tokenized checkout |
| **Mollie** | Europe, UK | iDEAL, Bancontact, SEPA, cards |
| **Razorpay** | India | UPI, cards, netbanking, wallets |
| **Paystack** | Nigeria, Ghana, Kenya, South Africa | Cards, bank transfer, mobile money |
| **Flutterwave** | Nigeria, Ghana, Kenya, South Africa | Cards, mobile money, bank |

Each one works the same safe way as the existing gateways:

1. The customer is sent to the provider's own hosted payment page.
2. When they come back — and again when the provider's webhook arrives — the app asks the
   **provider's API** what really happened.
3. An order is only marked **paid** if the provider says the payment succeeded **and** the amount
   and currency match the order exactly. A mismatch is logged on the order for you to check
   instead of being accepted.
4. Confirming twice (return page + webhook) is harmless; the order is only paid once.

Paystack webhooks are additionally signature-checked with your secret key.

**New countries and currencies** at checkout: Europe (EUR), Australia (AUD), UAE (AED), India
(INR), Nigeria (NGN), Ghana (GHS), Kenya (KES) and South Africa (ZAR), in addition to the
existing UK, US, Canada and Bangladesh.

**Admin → Payments** was rebuilt: on/off switches, clear field names, the countries each gateway
serves, and a copy button for the webhook URL to paste into the provider's dashboard. The 50+
unimplemented "extension slots" from the original registry are still listed, now tucked into a
collapsed section and clearly marked as not active.

## 4. Admin → Currencies (new page)

Prices are entered once in GBP. This page sets the exchange rate for every other currency
(1 GBP = N), so shoppers pay in their own money. A country with no rate simply cannot check out,
so a price is never guessed. Rates can be changed at any time without restarting the app. The
`FX_GBP_*` environment variables still work as a fallback.

## 5. Admin → Coupons (new page)

The database already had coupons and checkout already accepted them, but there was no way to
manage them. You can now create percentage or fixed-amount codes, set a minimum spend and an
expiry date, switch them on and off, and see how many orders used each one. A coupon that has
been used is switched off rather than deleted, so order history stays correct.

## 6. Admin → Customers (new page)

Every registered customer with their join date, order count, total spent (per currency) and last
order, plus a search box and a button to disable or re-enable a login. Their orders are never
touched.

## 7. Product editing: photos, category, options, delete

The product page in the admin panel could only edit text, prices and stock. It can now also:

- **Upload, reorder and delete photos** (the first photo is the main one).
- **Move a product to another category.**
- **Add and remove options/variants** (sizes, colours, packs).
- **Delete a product.** If it appears on past orders it is archived instead, so order history
  stays intact. The same rule applies to options that have been ordered.

## 8. Other improvements

- **Search box in the storefront header** (desktop and mobile). Search now also looks in product
  descriptions, not just names.
- **Admin → Orders** has a search box (order number, email, name or phone).
- **Admin → Team** is reachable at last — see the bug list below.

---

## Bugs found and fixed

These were found by running the application against a real MySQL database and a real browser.

1. **The Team page could never be opened.** The code reads a `User.isSuperAdmin` column through
   raw SQL, but that column was missing from `prisma/schema.prisma`, so it did not exist on any
   fresh database. Every admin was treated as a non-super admin and the Team link never appeared.
   The column is now in the schema, in the migration, and in the seed, and the migration promotes
   your oldest admin account so the page is reachable straight after upgrading.
2. **Checkout bounced shoppers back to the products page.** Opening or refreshing `/checkout`
   directly emptied the basket check before the saved basket had loaded, so a customer with items
   in their basket was redirected away and could not pay.
3. **The cart drawer reopened on every page and blocked the checkout button.** The "drawer is
   open" flag was being saved in the browser alongside the basket, so after adding one item the
   drawer covered the "Place order" button on every page load.
4. **"Add to Basket" was dead on products whose first option was sold out**, even when other
   sizes or colours were in stock. The first *available* option is now selected.
5. **`npm run db:seed` always failed** with "Environment variable not found: DATABASE_URL"
   because the seed script never loaded `.env`. It now runs through Prisma's own seed command.
6. **Payment radio buttons had no value**, so the chosen method was not part of the form data.
7. **A failed product or option save crashed the whole admin page** instead of showing a message.
   Blank or negative prices were also accepted and saved a product at £0.00; both are now
   rejected with a clear message.
8. **An unknown order status in the URL** (`/admin/orders?status=xyz`) threw a database error.
   Invalid values now simply show all orders.
9. **A React deprecation warning** (`useFormState`) on every product page has been removed.
10. **Postcode validation demanded four characters**, which blocked valid addresses in countries
    with short or no postcodes.

## Files added

```
src/lib/site-theme.ts                       Theme rotation logic (pure, unit-tested)
src/lib/site-theme-server.ts                Reads the active look for the server
src/lib/payment-adapters-intl.ts            bKash, Mollie, Razorpay, Paystack, Flutterwave
src/lib/gateway-confirm.ts                  Shared "is this payment really paid?" check
src/app/skins.css                           The NEXAWEB design
src/app/admin/appearance/                   Design & themes page
src/app/admin/currencies/                   Currencies page
src/app/admin/coupons/                      Coupons page
src/app/admin/customers/                    Customers page
src/app/api/payments/[provider]/return/     Where hosted payment pages send customers back
src/app/api/webhooks/{mollie,razorpay,paystack,flutterwave}/
src/app/actions/{site-theme,currency,admin-coupon,admin-customer,admin-product-extra}-actions.ts
src/components/admin/{design-themes-manager,currency-rates-form,coupon-manager,
                      customer-active-toggle,product-extras}.tsx
migration-themes-gateways.sql               The only database change needed
tests/{theme,gateways}.test.ts              New automated tests
```

## Upgrading an existing site

1. Back up the database and the current files.
2. Upload this source, keeping your `.env` and `public/uploads/` folder.
3. Run `migration-themes-gateways.sql` once on the database. It only adds two tables and one
   column, and running it twice is harmless.
4. `npm ci` then `npx prisma generate`, then `npm run build` and restart.
5. In the admin panel: set exchange rates in **Currencies**, add any new gateways in **Payments**,
   and pick your design in **Design & themes**.

## Testing done on this update

- `npm run typecheck`, `npm test` (3 suites) and `npm run build` all pass.
- Run against a real MariaDB database with the app in a real browser: placing a cash-on-delivery
  order, order status changes through to Delivered (which marks a COD order paid and queues the
  invoice email), order tracking with messy input, admin login, saving settings, uploading a
  product photo, adding an option, creating coupons and currency rates, enabling a gateway, and
  the theme rotation actually changing an open page on schedule.
- Payment adapters are covered by automated tests with a stand-in provider API, checking the
  amounts sent (including minor units such as paise and kobo), that payment pages must be on the
  provider's own domain, signature checking, and that a wrong amount or currency is rejected.
- Every storefront and admin page was loaded in both designs with no JavaScript errors, and at
  phone width with no sideways scrolling.

**Not tested here** (needs your accounts): real payments with live or sandbox merchant accounts,
SMTP email delivery, and running on the production host.
