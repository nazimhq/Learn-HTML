# BulkStockExpert regional payment upgrade

This archive contains source code, not a prebuilt deployment. It has not been deployed and no production database or merchant account was accessed.

## Implemented scope

- UK/GBP, US/USD, Canada/CAD and Bangladesh/BDT checkout selection. Catalog and delivery prices remain GBP; merchant-supplied exchange rates convert each unit price server-side. The selected currency is saved with the order. Missing exchange rates disable that region instead of guessing prices.
- Stripe hosted Checkout for cards and supported Apple Pay/Google Pay devices; separate Klarna and Clearpay/Afterpay options through Stripe. Provider eligibility still controls availability.
- PayPal Orders API approval/capture plus verified PayPal callbacks. Pay Later / Pay in 3 is provider-controlled, not guaranteed for every account, country or order.
- SSLCommerz hosted checkout and server-validated transaction callbacks for Bangladesh. Its merchant account determines which local methods, including bKash, Nagad, Rocket, Upay and cards, appear.
- COD works without payment API keys. Application authentication and a working migrated database are still required.
- `/admin/payments`: encrypted credentials, enable/disable controls, sandbox/live setting, masked/write-only inputs and 30-second server-side configuration caching with invalidation on save. Blank fields retain existing credentials.
- The 50+ gateway catalogue is an **extension registry, not 50+ completed integrations**. bKash Direct, Shurjopay, EPS, Razorpay, Paystack, Mollie, Adyen and the other extension slots cannot be enabled until their adapters and verified callback handlers are implemented. Do not advertise them as operational.
- MySQL-compatible tracking queries; normalized customer email; bounded tracking input and structured errors. Guest confirmation details require a signed HttpOnly order cookie or matching signed-in email.
- Review submission with 1–5 integer ratings, private optional email and a 2–2000 character comment. New reviews await moderation. Existing admin edit/approve/delete controls are retained and corrected.
- Transactional stock reservation with conditional decrements; merged duplicate basket lines; random order numbers; checkout request keys; transactional cancellation restock with duplicate-transition protection.
- Delivered COD orders become paid within the status transaction. Prepaid orders must be paid before delivery. Paid/delivery invoices and cancellation messages have persistent retry jobs. SMTP delivery is at-least-once: a crash after SMTP accepts mail can cause a retry duplicate.
- Multi-page PDF invoices with embedded Latin/Bengali fonts, saved currency, shipping address, item breakdown and optional local PNG/JPEG uploaded logo. Site-name wordmark is the fallback for remote/SVG logos.
- Theme CSS variables, immediate admin preview, cross-tab theme updates and storefront polling every 10 seconds/focus; deep gold preset; motion-aware product cards, reveals, route transitions, cart drawer, checkout button and WhatsApp safe-area positioning.
- Seven bundled payment SVG logos with source attribution. Clearpay, bKash and Nagad currently use text badges; replace these with approved brand assets before treating the badge set as final visual branding.
- Dashboard reports filter by currency so different currencies are never summed as GBP.

## Key file paths

All paths are relative to the extracted archive root. Full implementation is in these files.

| Area | Files |
| --- | --- |
| Schema and database changes | `prisma/schema.prisma`, `migration-regional-payments.sql` |
| Registry and adapters | `src/lib/gateway-catalog.ts`, `src/lib/gateway-settings.ts`, `src/lib/payment-adapters.ts`, `src/lib/payments.ts` |
| Secret encryption | `src/lib/payment-crypto.ts`, `scripts/encrypt-legacy-credentials.ts` |
| Payment admin | `src/app/admin/payments/page.tsx`, `src/components/admin/gateway-manager.tsx`, `src/app/actions/gateway-actions.ts` |
| Regional checkout | `src/app/checkout/page.tsx`, `src/app/actions/checkout-actions.ts`, `src/lib/region-pricing.ts`, `src/app/api/payment-methods/route.ts`, `src/lib/delivery.ts` |
| Verified callbacks | `src/app/api/webhooks/stripe/route.ts`, `src/app/api/webhooks/paypal/route.ts`, `src/app/api/webhooks/sslcommerz/route.ts`, `src/app/api/payments/paypal/capture/route.ts` |
| Order workflow | `src/app/actions/admin-order-actions.ts`, `src/components/admin/order-status-controls.tsx`, `src/lib/order-payment.ts` |
| Email retry and invoices | `src/lib/email-jobs.ts`, `src/app/api/internal/email-jobs/route.ts`, `src/lib/invoice-pdf.ts`, `src/lib/invoice.ts`, `src/app/api/invoice/[orderNumber]/route.ts` |
| Tracking and guest access | `src/lib/order-lookup.ts`, `src/lib/order-access.ts`, `src/app/api/track-order/route.ts` |
| Reviews | `src/app/actions/review-actions.ts`, `src/app/api/reviews/route.ts`, `src/components/pdp/review-form.tsx`, `src/components/admin/reviews-manager.tsx` |
| Settings and theme | `src/app/actions/admin-settings-actions.ts`, `src/components/admin/settings-form.tsx`, `src/components/layout/theme-sync.tsx`, `src/app/api/site-theme/route.ts`, `src/app/globals.css` |
| Motion | `src/components/motion/reveal.tsx`, `src/components/motion/hover-card.tsx`, `src/components/cart/cart-drawer.tsx`, `src/app/template.tsx` |
| Logos | `src/components/storefront/payment-badges.tsx`, `public/payments/` |
| Verification | `tests/core.test.ts`, `tests/run.cjs`, `VERIFICATION.md` |

`CHANGED-FILES.txt` lists every changed/new archive path. Existing source was also formatted for consistent readability.

## Local setup

1. Use a supported Node LTS runtime and MySQL. Copy `.env.example` to `.env` and fill local values. Never commit `.env`.
2. Generate independent `NEXTAUTH_SECRET`, `PAYMENT_ENCRYPTION_KEY` and `INTERNAL_JOB_SECRET` values. The encryption key must be exactly 64 hexadecimal characters. Preserve it across deploys and backups; changing it makes existing encrypted credentials unreadable.
3. Run `npm ci`. The postinstall hook runs `prisma generate`. `.npmrc` preserves the legacy peer-resolution mode needed by the supplied NextAuth dependency and patched Nodemailer release.
4. For a **new empty local database only**, run `npx prisma db push`. Seed only a disposable test database after reviewing `prisma/seed.ts`; its sample account settings are not production credentials.
5. For an existing database, use the migration procedure below instead of blindly reseeding.
6. Run `npm run typecheck`, `npm test`, `npm run build`, then `npm run dev` for development or `npm start` for a successful production build.

`npm test` writes a sample invoice to `../qa/invoice.pdf`. Test credentials are random, process-local values; no merchant endpoint is called.

## Existing database migration

1. Back up the current database, source, environment and uploaded files. Make a staging copy.
2. Compare staging schema with `prisma/schema.prisma`. The supplied archive already contained `migration-new-features.sql`, `migration-part2-categories-products.sql`, `migration-part3-payments.sql` and `migration-part4-cms.sql`; confirm which were actually applied. **Do not blindly replay them or the new migration.** Duplicate columns indicate the migration already ran, not that the database should be reset.
3. If staging matches the original supplied Prisma schema, apply `migration-regional-payments.sql` once using your MySQL client. If earlier columns/tables are missing, reconcile those specific missing changes first. This is the underlying cause of many P2022 runtime failures; catching exceptions is not a replacement for migration.
4. Run `npx prisma generate` against the new source and `npx tsx scripts/encrypt-legacy-credentials.ts` with the encryption key configured. The latter converts legacy plaintext credentials without printing their values.
5. Verify `Order.currency`, `Order.checkoutKey`, `Order.stockRestoredAt`, `DeliveryZone.countryCode`, `GatewayConfig`, and `EmailJob` exist. Verify the encrypted credential columns are TEXT.
6. Run the tests below on staging before repeating the reviewed migration on production. There is no Prisma migration history baseline in the original archive, so `prisma migrate deploy` alone does **not** apply this standalone SQL file.

## Merchant and shipping configuration

- Add delivery zones for GB, US, CA and BD in Delivery & Settings. Enter delivery charges/free-shipping thresholds in catalog GBP. Country defaults to GB for existing zones. Without an active zone, checkout clearly reports that delivery is unavailable.
- Set `FX_GBP_USD`, `FX_GBP_CAD`, and `FX_GBP_BDT` to approved rates; they are configuration, not a live FX quote feed. Restart after environment changes.
- Configure gateways in `/admin/payments`; the previous Settings payment editor now links there.
- Stripe: secret key, publishable key and webhook secret. Configure `checkout.session.completed` and `checkout.session.async_payment_succeeded` on `/api/webhooks/stripe`. Enable eligible Klarna/Afterpay methods with Stripe before enabling their store toggles. Wallets depend on browser, device and merchant eligibility.
- PayPal: client ID, client secret and webhook ID. Register `PAYMENT.CAPTURE.COMPLETED` on `/api/webhooks/paypal` for the same sandbox/live app. A browser return alone is not treated as proof of payment.
- SSLCommerz: store ID/password and mode. `/api/webhooks/sslcommerz` validates callbacks by querying SSLCommerz before comparing order, amount and currency. Provider activation controls individual Bangladesh payment methods.
- Set HTTPS `NEXT_PUBLIC_SITE_URL` and `NEXTAUTH_URL` to the real deployment URL, without a trailing slash. The source expects root-path hosting; the inherited optional `NEXT_BASE_PATH` is not covered by this upgrade.
- Set SMTP variables and `EMAIL_FROM`. Configure an external server scheduler to POST `/api/internal/email-jobs` periodically with `Authorization: Bearer <INTERNAL_JOB_SECRET>`. Do not put the secret in a URL. Inline attempts happen after order transitions; the scheduler recovers failures and interrupted attempts. No scheduler was installed by this task.

## Debugging and acceptance tests

1. **COD**: disable online gateways, keep COD on; submit a real in-stock test basket. Verify one order, PENDING payment, matching totals and one stock deduction. Resubmit the same request; verify no duplicate order/stock deduction. Run competing purchases against the final unit and verify stock never becomes negative.
2. **Country/price**: select each region and verify displayed, stored and provider totals/currency match, including multiple quantities and fractional unit conversion. Remove one FX rate and verify that region cannot submit. Verify region-specific shipping and coupon math.
3. **Callbacks**: valid paid callback, duplicate callback, invalid signature, wrong reference, wrong amount/currency, and delayed payment. Only verified settled payments should become PAID. A payment arriving after cancellation requires a merchant refund decision; this implementation does not automatically refund providers.
4. **Status**: progress order through processing/shipped/delivered. COD delivery must atomically set PAID and queue an invoice. Cancel another order twice/concurrently; stock must be restored once. Cancelled orders cannot be reopened. Manual payment status controls are available on each order detail page.
5. **Email**: temporarily break SMTP, deliver/cancel an order, check `EmailJob.lastError` and retry state, restore SMTP, invoke the worker, and verify successful delivery. Inspect the PDF using a long basket and Bengali address. Failed online initiation leaves an explicitly pending saved order; customers should contact support instead of placing duplicates.
6. **Reviews**: submit each integer rating, a short valid review and optional email. Verify pending moderation, private email, clear validation errors and correct approved rating aggregates after editing/deleting.
7. **Tracking**: enter mixed-case email and padded order number; verify lookup. Invalid/missing input should return 400; an unavailable database returns 503 and an internal log. Unauthenticated visitors must not see order details merely by knowing the confirmation URL.
8. **Settings**: save gold/red/yellow/black and light/dark, inspect CSS variables and another open tab. Revisit after restart. Test missing singleton rows and simulated DB errors. Inspect browser/network payloads to ensure saved credentials never appear.
9. **UI**: desktop/mobile and reduced-motion checks; cart keyboard focus/Escape; WhatsApp safe areas; checkout loading state; footer wrapping. These require browser acceptance testing on a working database.

## Deployment and rollback

Deliver this ZIP first. Deploy only after full build and the acceptance checks succeed on the target host. Production database changes and credential configuration were not performed here. Keep uploaded files and environment values outside a source overwrite. Generate Prisma on the target OS; do not copy a Windows Prisma engine to Linux. Include `public/fonts` and `public/payments` in the deployment. Restart the Node service and verify root, product, admin, checkout and tracking routes.

If application smoke tests fail, restore the prior application release while preserving additive database columns. For database rollback, use the verified backup and coordinate any orders created since migration; do not drop new columns blindly. Keep the encryption key available to both releases that need to read encrypted data.

## Provider references

- Stripe hosted Checkout and settled payment status: https://docs.stripe.com/api/checkout/sessions/object
- Stripe Clearpay eligibility: https://docs.stripe.com/payments/afterpay-clearpay/accept-a-payment
- SSLCommerz server validation: https://developer.sslcommerz.com/doc/v4/
- PDFKit embedded fonts: https://pdfkit.org/docs/text.html
- SVG source and license: https://github.com/datatrans/payment-logos

All brand marks belong to their respective owners. The archive includes attribution for bundled assets.
