import type { HeroSlide } from "@/components/home/hero-slider";

/**
 * Homepage hero slider content. Edit this array to change what rotates at
 * the top of the homepage — no database involved, so a change here just
 * needs a normal redeploy (no migration).
 */
export const PROMO_SLIDES: HeroSlide[] = [
  {
    eyebrow: "Genuine returns stock",
    title: "Customer-return pallets, sourced and sold across the UK",
    body: "Electronics, home, clothing and general merchandise — manifested lots at trade prices.",
    ctaLabel: "Shop pallets",
    ctaHref: "/products",
    gradient: ["#5f4d32", "#171310"],
  },
  {
    eyebrow: "Delivery",
    title: "Nationwide UK delivery on every pallet",
    body: "Tracked courier or pallet-network delivery, with buyer protection on every order.",
    ctaLabel: "See delivery zones",
    ctaHref: "/track-order",
    gradient: ["#946f2f", "#241f19"],
  },
  {
    eyebrow: "Electronics returns",
    title: "Mixed electronics, properly graded",
    body: "Phones, audio, smart home and small appliances — customer returns and overstock lots.",
    ctaLabel: "Shop electronics returns",
    ctaHref: "/products?category=electronics-returns",
    gradient: ["#241f19", "#786240"],
  },
  {
    eyebrow: "Home & kitchen",
    title: "Home & kitchen job lots",
    body: "Cookware, small appliances and homeware, sold by the box or the pallet.",
    ctaLabel: "Shop home & kitchen",
    ctaHref: "/products?category=home-kitchen",
    gradient: ["#786240", "#5f4d32"],
  },
  {
    eyebrow: "New stock",
    title: "New manifested stock, added weekly",
    body: "Fresh pallets and job lots arrive regularly — check back for the latest listings.",
    ctaLabel: "See new arrivals",
    ctaHref: "/products?sort=newest",
    gradient: ["#463924", "#171310"],
  },
  {
    eyebrow: "Checkout",
    title: "Secure checkout, every time",
    body: "Card and PayPal supported, with every payment fully encrypted.",
    ctaLabel: "Start shopping",
    ctaHref: "/products",
    gradient: ["#171310", "#946f2f"],
  },
];
