import { Check, Package, Truck, Home, XCircle } from "lucide-react";
import { ORDER_STATUS_LABEL, ORDER_STATUS_SEQUENCE } from "@/lib/constants";

const ICONS: Record<string, typeof Check> = {
  PENDING: Check,
  PROCESSING: Package,
  SHIPPED: Truck,
  DELIVERED: Home,
};

export function OrderTimeline({ status }: { status: string }) {
  if (status === "CANCELLED") {
    return (
      <div className="flex items-center gap-2 rounded-xl bg-red-50 px-4 py-3 text-[13px] font-medium text-red-700">
        <XCircle size={16} /> This order was cancelled.
      </div>
    );
  }

  const currentIndex = ORDER_STATUS_SEQUENCE.indexOf(
    status as (typeof ORDER_STATUS_SEQUENCE)[number],
  );

  return (
    <div className="flex items-center">
      {ORDER_STATUS_SEQUENCE.map((s, i) => {
        const Icon = ICONS[s];
        const done = i <= currentIndex;
        return (
          <div key={s} className="flex flex-1 items-center last:flex-none">
            <div className="flex flex-col items-center gap-1.5">
              <div
                className={`flex h-9 w-9 items-center justify-center rounded-full border-2 ${done ? "border-brand-500 bg-brand-500 text-white" : "border-ink-900/15 text-ink-400 dark:text-ink-50/50 dark:border-ink-50/15"}`}
              >
                <Icon size={15} />
              </div>
              <span
                className={`text-center text-[11px] font-medium ${done ? "text-ink-900 dark:text-ink-50" : "text-ink-400 dark:text-ink-50/50"}`}
              >
                {ORDER_STATUS_LABEL[s]}
              </span>
            </div>
            {i < ORDER_STATUS_SEQUENCE.length - 1 && (
              <div
                className={`mx-1.5 mb-5 h-0.5 flex-1 ${i < currentIndex ? "bg-brand-500" : "bg-ink-900/10 dark:bg-ink-50/10"}`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
