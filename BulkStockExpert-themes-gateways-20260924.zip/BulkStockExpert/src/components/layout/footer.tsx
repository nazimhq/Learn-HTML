import { PaymentBadges } from "@/components/storefront/payment-badges";
import Link from "next/link";
import { Facebook, Instagram, Music2 } from "lucide-react";

export function Footer({
  siteName,
  contactEmail,
  contactPhone,
  facebookUrl,
  instagramUrl,
  tiktokUrl,
}: {
  siteName: string;
  contactEmail?: string | null;
  contactPhone?: string | null;
  facebookUrl?: string | null;
  instagramUrl?: string | null;
  tiktokUrl?: string | null;
}) {
  const socials = [
    { url: facebookUrl, label: "Facebook", Icon: Facebook },
    { url: instagramUrl, label: "Instagram", Icon: Instagram },
    { url: tiktokUrl, label: "TikTok", Icon: Music2 },
  ].filter((s) => s.url);
  return (
    <footer className="mt-20 border-t border-ink-900/10 bg-ink-900 text-ink-100">
      <div className="container-page grid grid-cols-2 gap-10 py-14 sm:grid-cols-4">
        <div className="col-span-2 sm:col-span-1">
          <span className="font-display text-xl text-ink-50">{siteName}</span>
          <p className="mt-3 max-w-[220px] text-[13px] text-ink-100/70">
            Genuine customer-return pallets and job lots — electronics, home,
            clothing and general merchandise, sourced and sold across the UK.
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-[12.5px] font-semibold uppercase tracking-wide text-ink-100/50">
            Shop
          </h4>
          <ul className="flex flex-col gap-2 text-[13px] text-ink-100/80">
            <li>
              <Link href="/products" className="hover:text-ink-50">
                All pallets
              </Link>
            </li>
            <li>
              <Link
                href="/products?category=electronics-returns"
                className="hover:text-ink-50"
              >
                Electronics returns
              </Link>
            </li>
            <li>
              <Link
                href="/products?category=home-kitchen"
                className="hover:text-ink-50"
              >
                Home &amp; kitchen
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-[12.5px] font-semibold uppercase tracking-wide text-ink-100/50">
            Support
          </h4>
          <ul className="flex flex-col gap-2 text-[13px] text-ink-100/80">
            <li>
              <Link href="/track-order" className="hover:text-ink-50">
                Track order
              </Link>
            </li>
            <li>
              <Link href="/pages/returns" className="hover:text-ink-50">
                Delivery &amp; returns
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-ink-50">
                Contact us
              </Link>
            </li>
            <li>
              <Link href="/pages/about" className="hover:text-ink-50">
                About us
              </Link>
            </li>
            <li>
              <Link href="/pages/terms" className="hover:text-ink-50">
                Terms &amp; conditions
              </Link>
            </li>
            <li>
              <Link href="/pages/privacy" className="hover:text-ink-50">
                Privacy policy
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-[12.5px] font-semibold uppercase tracking-wide text-ink-100/50">
            Get in touch
          </h4>
          <ul className="flex flex-col gap-2 text-[13px] text-ink-100/80">
            {contactEmail && <li>{contactEmail}</li>}
            {contactPhone && <li>{contactPhone}</li>}
            <li>United Kingdom</li>
          </ul>
          {socials.length > 0 && (
            <div className="mt-4 flex gap-3">
              {socials.map(({ url, label, Icon }) => (
                <a
                  key={label}
                  href={url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-8 w-8 items-center justify-center rounded-full bg-ink-50/10 text-ink-100/80 transition hover:bg-ink-50/20 hover:text-ink-50"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
      <div className="border-t border-ink-50/10">
        <div className="container-page flex flex-wrap items-center justify-between gap-2 py-4 text-[11.5px] text-ink-100/50">
          <span>
            © {new Date().getFullYear()} {siteName}. All rights reserved.
          </span>
          <span>Prices include VAT where applicable.</span>
        </div>
      </div>
      <div className="container-page">
        <PaymentBadges />
      </div>
    </footer>
  );
}
