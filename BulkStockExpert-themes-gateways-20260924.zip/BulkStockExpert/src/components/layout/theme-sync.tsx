"use client";
import { useEffect } from "react";

interface SiteThemePayload {
  accentTheme: string;
  colorMode: string;
  skin?: string;
  nextChangeAt?: string | null;
}

/**
 * Keeps an open page in step with the admin's theme: saved changes (other tabs, the admin
 * panel) and the automatic design rotation. Polls /api/site-theme every 10 seconds and on
 * focus, and also wakes up exactly when the rotation is due to switch.
 */
export function ThemeSync({
  accent,
  mode,
  skin = "classic",
  nextChangeAt = null,
}: {
  accent: string;
  mode: string;
  skin?: string;
  nextChangeAt?: string | null;
}) {
  useEffect(() => {
    let last = `${skin}:${accent}:${mode}`;
    let switchTimer: number | undefined;
    const root = document.documentElement;
    const apply = (a: string, m: string, s: string, reset = false) => {
      root.dataset.accent = a;
      root.dataset.skin = s;
      if (reset) localStorage.removeItem("bse-theme-mode");
      // The NEXAWEB design is dark-only; otherwise a visitor's own light/dark choice wins.
      root.dataset.mode =
        s === "nexaweb" ? "dark" : localStorage.getItem("bse-theme-mode") || m;
    };
    const scheduleSwitch = (at: string | null | undefined) => {
      window.clearTimeout(switchTimer);
      if (!at) return;
      const wait = new Date(at).getTime() - Date.now() + 1500;
      if (wait > 0 && wait < 2 ** 31 - 1)
        switchTimer = window.setTimeout(() => void refresh(), wait);
    };
    apply(accent, mode, skin);
    scheduleSwitch(nextChangeAt);
    const refresh = async () => {
      try {
        const r = await fetch("/api/site-theme", { cache: "no-store" });
        if (!r.ok) return;
        const s = (await r.json()) as SiteThemePayload;
        const nextSkin = s.skin ?? "classic";
        const version = `${nextSkin}:${s.accentTheme}:${s.colorMode}`;
        if (version !== last) {
          apply(s.accentTheme, s.colorMode, nextSkin, true);
          last = version;
        }
        scheduleSwitch(s.nextChangeAt);
      } catch {}
    };
    const storage = () => {
      void refresh();
    };
    window.addEventListener("storage", storage);
    const id = setInterval(refresh, 10000);
    window.addEventListener("focus", refresh);
    return () => {
      clearInterval(id);
      window.clearTimeout(switchTimer);
      window.removeEventListener("storage", storage);
      window.removeEventListener("focus", refresh);
    };
  }, [accent, mode, skin, nextChangeAt]);
  return null;
}
