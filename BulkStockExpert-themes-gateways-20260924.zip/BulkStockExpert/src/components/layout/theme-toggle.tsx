"use client";

import { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";

const STORAGE_KEY = "bse-theme-mode";

/**
 * Light/dark toggle for any visitor. The site ships with an admin-chosen default (see
 * AppSettings.colorMode, applied server-side in layout.tsx), but each visitor can flip it —
 * their choice is remembered in this browser only (localStorage), never sent to the server.
 * The inline script in layout.tsx applies any stored override before first paint so there's
 * no flash of the wrong theme.
 */
export function ThemeToggle() {
  const [mode, setMode] = useState<"light" | "dark" | null>(null);

  useEffect(() => {
    setMode(
      (document.documentElement.dataset.mode as "light" | "dark") || "light",
    );
  }, []);

  function toggle() {
    const next = mode === "dark" ? "light" : "dark";
    setMode(next);
    document.documentElement.dataset.mode = next;
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // localStorage unavailable (private mode, etc.) — the toggle still works for this view.
    }
  }

  return (
    <button
      onClick={toggle}
      className="theme-toggle rounded-full p-2.5 text-ink-600 hover:bg-ink-900/5 dark:text-ink-50/70 dark:hover:bg-ink-50/10"
      aria-label="Toggle dark mode"
      title="Toggle light / dark"
    >
      {mode === "dark" ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}
