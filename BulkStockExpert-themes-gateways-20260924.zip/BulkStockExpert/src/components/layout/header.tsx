"use client";

import Link from "next/link";
import { useState } from "react";
import { Search, User, ShoppingBag, Menu, X } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { ThemeToggle } from "@/components/layout/theme-toggle";

interface Category {
  id: string;
  name: string;
  slug: string;
}

/** Scrolling top-bar messages — the admin-editable "Tagline" plus the standing offers. */
function NOTICE_ITEMS(tagline?: string | null): string[] {
  return [
    tagline ||
      "Genuine customer-return pallets, sourced and sold across the UK.",
    "Nationwide UK delivery",
    "Buyer protection on every order",
    "Secure checkout — card & PayPal",
  ];
}

export function Header({
  categories,
  siteName,
  tagline,
  logoUrl,
}: {
  categories: Category[];
  siteName: string;
  tagline?: string | null;
  logoUrl?: string | null;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const open = useCartStore((s) => s.open);
  const count = useCartStore((s) => s.lines.reduce((sum, l) => sum + l.qty, 0));

  return (
    <header className="sticky top-0 z-40 border-b border-ink-900/10 bg-surface/90 backdrop-blur dark:border-ink-50/10">
      <div className="overflow-hidden bg-ink-900 text-ink-50">
        <div className="flex whitespace-nowrap py-2 text-[12px]">
          <div className="marquee-track flex flex-shrink-0 items-center gap-10">
            {[0, 1].map((rep) => (
              <div
                key={rep}
                className="flex flex-shrink-0 items-center gap-10 pr-10"
                aria-hidden={rep === 1}
              >
                {NOTICE_ITEMS(tagline).map((msg, i) => (
                  <span key={i} className="flex items-center gap-2">
                    <span className="text-accent-400">✦</span>
                    {msg}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container-page flex items-center gap-6 py-4">
        <button
          className="inline-flex sm:hidden"
          onClick={() => setMenuOpen(true)}
          aria-label="Open menu"
        >
          <Menu size={22} />
        </button>

        <Link
          href="/"
          className="flex items-center font-display text-2xl tracking-tight text-ink-900 dark:text-ink-50"
        >
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={logoUrl}
              alt={siteName}
              className="h-9 w-auto object-contain"
            />
          ) : (
            siteName
          )}
        </Link>

        <nav className="hidden gap-7 sm:flex">
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/products?category=${c.slug}`}
              className="text-[13.5px] font-medium text-ink-600 transition hover:text-ink-900 dark:text-ink-50/70 dark:hover:text-ink-50"
            >
              {c.name}
            </Link>
          ))}
        </nav>

        {/* Product search — the catalogue already supports ?q=, this puts it in reach. */}
        <form action="/products" role="search" className="ml-auto hidden md:block">
          <label className="relative block">
            <span className="sr-only">Search products</span>
            <Search
              size={15}
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-400 dark:text-ink-50/40"
            />
            <input
              type="search"
              name="q"
              placeholder="Search products"
              className="field-input !h-9 !w-52 !rounded-full !pl-8 !text-[13px] lg:!w-64"
            />
          </label>
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-2">
          <ThemeToggle />
          <Link
            href="/track-order"
            className="hidden items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-medium text-ink-600 hover:bg-ink-900/5 dark:text-ink-50/70 dark:hover:bg-ink-50/10 sm:flex"
          >
            <Search size={16} /> Track order
          </Link>
          <Link
            href="/account"
            className="hidden items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-medium text-ink-600 hover:bg-ink-900/5 dark:text-ink-50/70 dark:hover:bg-ink-50/10 sm:flex"
          >
            <User size={16} /> Account
          </Link>
          <button
            onClick={open}
            className="relative rounded-full p-2.5 transition hover:bg-ink-900/5 active:scale-90 dark:hover:bg-ink-50/10"
            aria-label="Open cart"
          >
            <ShoppingBag size={19} className="text-ink-900 dark:text-ink-50" />
            {count > 0 && (
              <span
                key={count}
                className="animate-badge-pop absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent-500 px-1 font-mono text-[10px] font-bold text-accent-fg"
              >
                {count > 9 ? "9+" : count}
              </span>
            )}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/50 sm:hidden"
          onClick={() => setMenuOpen(false)}
        >
          <div
            className="flex h-full w-[80%] max-w-xs flex-col bg-panel p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-6 flex items-center justify-between">
              <span className="font-display text-xl text-ink-900 dark:text-ink-50">
                {siteName}
              </span>
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="Close menu"
                className="text-ink-900 dark:text-ink-50"
              >
                <X size={20} />
              </button>
            </div>
            <form action="/products" role="search" className="mb-3">
              <label className="relative block">
                <span className="sr-only">Search products</span>
                <Search
                  size={15}
                  aria-hidden="true"
                  className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-400 dark:text-ink-50/40"
                />
                <input
                  type="search"
                  name="q"
                  placeholder="Search products"
                  className="field-input !pl-8"
                />
              </label>
            </form>
            <nav className="flex flex-col gap-1">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/products?category=${c.slug}`}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-900 hover:bg-ink-900/5 dark:text-ink-50 dark:hover:bg-ink-50/10"
                >
                  {c.name}
                </Link>
              ))}
              <Link
                href="/track-order"
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-900 hover:bg-ink-900/5 dark:text-ink-50 dark:hover:bg-ink-50/10"
              >
                Track order
              </Link>
              <Link
                href="/account"
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-900 hover:bg-ink-900/5 dark:text-ink-50 dark:hover:bg-ink-50/10"
              >
                My account
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
