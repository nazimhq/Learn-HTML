"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { Star, Minus, Plus } from "lucide-react";
import { formatMoney } from "@/lib/constants";
import { useCartStore } from "@/store/cart-store";

export interface PdpVariant {
  id: string;
  sku: string;
  label: string;
  price: number;
  compareAtPrice: number | null;
  stock: number;
  lowStockAt: number;
  imageUrl: string | null;
}

export function ProductBuyBox({
  productId,
  productName,
  ratingAvg,
  reviewCount,
  variants,
  whatsappNumber,
}: {
  productId: string;
  productName: string;
  ratingAvg: number;
  reviewCount: number;
  variants: PdpVariant[];
  whatsappNumber?: string | null;
}) {
  const router = useRouter();
  // Preselect the first option that's actually in stock, so a sold-out first variant doesn't
  // leave "Add to Basket" disabled while other options are available.
  const [variantId, setVariantId] = useState(
    (variants.find((v) => v.stock > 0) ?? variants[0])?.id,
  );
  const [qty, setQty] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const { addItem } = useCartStore();

  const variant = useMemo(
    () => variants.find((v) => v.id === variantId) ?? variants[0],
    [variantId, variants],
  );
  const off = variant?.compareAtPrice
    ? Math.round(
        ((variant.compareAtPrice - variant.price) / variant.compareAtPrice) *
          100,
      )
    : 0;

  function handleAdd() {
    if (!variant) return;
    addItem(
      {
        productId,
        variantId: variant.id,
        name: productName,
        variantLabel: variants.length > 1 ? variant.label : null,
        price: variant.price,
        imageUrl: variant.imageUrl ?? "",
        maxStock: variant.stock,
      },
      qty,
    );
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1400);
  }

  function handleOrderNow() {
    handleAdd();
    router.push("/checkout");
  }

  if (!variant) return null;

  return (
    <div>
      <div className="flex items-center gap-1.5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        <Star size={13} className="fill-accent-500 text-accent-500" />
        {ratingAvg.toFixed(1)} · {reviewCount} reviews
      </div>

      <div className="mt-3 flex items-baseline gap-3 font-mono">
        <span className="text-[26px] font-semibold text-ink-900 dark:text-ink-50">
          {formatMoney(variant.price)}
        </span>
        {variant.compareAtPrice && (
          <>
            <span className="text-[15px] text-ink-400 dark:text-ink-50/50 line-through">
              {formatMoney(variant.compareAtPrice)}
            </span>
            <span className="rounded-full bg-discount/10 px-2 py-0.5 text-[11px] font-bold text-discount">
              -{off}%
            </span>
          </>
        )}
      </div>

      {variants.length > 1 && (
        <div className="mt-5">
          <p className="mb-2 text-[12px] font-semibold text-ink-400 dark:text-ink-50/50">
            Option
          </p>
          <div className="flex flex-wrap gap-2">
            {variants.map((v) => (
              <button
                key={v.id}
                disabled={v.stock === 0}
                onClick={() => {
                  setVariantId(v.id);
                  setQty(1);
                }}
                className={`rounded-full border px-4 py-1.5 text-[12.5px] font-medium ${
                  v.id === variant.id
                    ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-accent-400"
                    : "border-ink-900/15 text-ink-900 dark:border-ink-50/15 dark:text-ink-50"
                } ${v.stock === 0 ? "cursor-not-allowed opacity-40 line-through" : ""}`}
              >
                {v.label}
                {v.stock === 0 ? " (Out)" : ""}
              </button>
            ))}
          </div>
        </div>
      )}

      <p
        className={`mt-4 text-[12.5px] font-semibold ${variant.stock === 0 ? "text-red-600" : variant.stock <= variant.lowStockAt ? "text-accent-600" : "text-emerald-700"}`}
      >
        {variant.stock === 0
          ? "Out of stock"
          : variant.stock <= variant.lowStockAt
            ? `Only ${variant.stock} left in stock`
            : "In stock"}
      </p>

      <div className="mt-4 flex items-center gap-3">
        <div className="flex items-center rounded-full border border-ink-900/15 dark:border-ink-50/15">
          <button
            className="flex h-9 w-9 items-center justify-center"
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            aria-label="Decrease"
          >
            <Minus size={14} />
          </button>
          <span className="w-8 text-center font-mono text-sm font-semibold">
            {qty}
          </span>
          <button
            className="flex h-9 w-9 items-center justify-center"
            onClick={() => setQty((q) => Math.min(variant.stock, q + 1))}
            disabled={qty >= variant.stock}
            aria-label="Increase"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>

      <div className="mt-5 flex gap-2.5">
        <button
          onClick={handleAdd}
          disabled={variant.stock === 0}
          className={`btn-secondary flex-1 transition ${justAdded ? "animate-pop-in !border-emerald-500 !text-emerald-700 dark:!text-emerald-400" : ""}`}
        >
          {justAdded ? "Added ✓" : "Add to Basket"}
        </button>
        <button
          onClick={handleOrderNow}
          disabled={variant.stock === 0}
          className="btn-primary flex-1 transition active:scale-95"
        >
          Buy Now
        </button>
      </div>

      {whatsappNumber && (
        <a
          href={`https://wa.me/${whatsappNumber.replace(/[^\d]/g, "")}?text=${encodeURIComponent(`Hi, I'd like to order: ${productName} (${variant.label})`)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[#25D366]/40 px-4 py-2 text-[12.5px] font-semibold text-[#128c4a] hover:bg-[#25D366]/10"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.04 2c-5.5 0-10 4.5-10 10 0 1.77.46 3.5 1.34 5.02L2 22l5.13-1.35A9.96 9.96 0 0 0 12.04 22c5.5 0 10-4.5 10-10s-4.5-10-10-10zm5.8 14.2c-.24.68-1.4 1.3-1.94 1.38-.5.08-1.12.11-1.8-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.16-4.94-4.35-.14-.19-1.18-1.57-1.18-3 0-1.42.75-2.12 1.02-2.41.27-.29.58-.36.78-.36h.55c.18 0 .42-.07.65.5.24.58.82 2 .89 2.15.07.15.12.32.02.51-.1.19-.15.31-.3.48-.15.17-.31.38-.44.51-.15.15-.3.31-.13.6.17.29.76 1.25 1.63 2.02 1.12.99 2.06 1.3 2.36 1.45.3.15.48.13.65-.08.18-.21.75-.88.95-1.18.2-.3.4-.25.67-.15.28.1 1.76.83 2.06.98.3.15.5.22.57.35.08.13.08.72-.16 1.4z" />
          </svg>
          Order this via WhatsApp
        </a>
      )}
    </div>
  );
}
