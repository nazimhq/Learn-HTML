"use client";

import { useState, useRef } from "react";

interface Img {
  id: string;
  url: string;
  altText: string;
}

export function ImageGallery({
  images,
  productName,
}: {
  images: Img[];
  productName: string;
}) {
  const [active, setActive] = useState(0);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });
  const [zooming, setZooming] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  function handleMove(e: React.MouseEvent) {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    setZoomPos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  }

  const tint = "linear-gradient(135deg,#463924,#786240)";
  const current = images[active];

  return (
    <div>
      <div
        ref={ref}
        className="relative aspect-square overflow-hidden rounded-2xl bg-ink-100"
        onMouseMove={handleMove}
        onMouseEnter={() => setZooming(true)}
        onMouseLeave={() => setZooming(false)}
      >
        {current?.url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={current.url}
            alt={current.altText || productName}
            className="h-full w-full object-cover transition-transform duration-150"
            style={{
              transform: zooming ? "scale(1.6)" : "scale(1)",
              transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`,
            }}
          />
        ) : (
          <>
            <div
              data-tint=""
              className="h-full w-full transition-transform duration-150"
              style={{
                background: tint,
                transform: zooming ? "scale(1.6)" : "scale(1)",
                transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`,
              }}
            />
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <span className="font-display text-5xl text-ink-50/40">
                {productName.charAt(0)}
              </span>
            </div>
          </>
        )}
      </div>
      {images.length > 1 && (
        <div className="mt-2.5 flex gap-2">
          {images.map((img, i) => (
            <button
              key={img.id}
              onClick={() => setActive(i)}
              className={`h-14 w-14 overflow-hidden rounded-lg border-2 ${active === i ? "border-brand-500" : "border-transparent"}`}
              data-tint={img.url ? undefined : ""}
              style={img.url ? undefined : { background: tint }}
              aria-label={`Image ${i + 1}`}
            >
              {img.url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={img.url}
                  alt={img.altText || ""}
                  className="h-full w-full object-cover"
                />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
