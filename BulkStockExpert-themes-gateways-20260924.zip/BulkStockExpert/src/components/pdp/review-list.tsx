import { Star } from "lucide-react";

export interface PdpReview {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export function ReviewList({ reviews }: { reviews: PdpReview[] }) {
  if (reviews.length === 0) {
    return (
      <p className="text-[13px] text-ink-400 dark:text-ink-50/50">
        No reviews yet — be the first to review this product.
      </p>
    );
  }
  return (
    <div className="flex flex-col divide-y divide-ink-900/5">
      {reviews.map((r) => (
        <div key={r.id} className="py-3">
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-semibold">{r.customerName}</span>
            <span className="text-[11px] text-ink-400 dark:text-ink-50/50">
              {new Date(r.createdAt).toLocaleDateString("en-GB")}
            </span>
          </div>
          <div className="mt-1 flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                size={12}
                className={
                  i < r.rating
                    ? "fill-accent-500 text-accent-500"
                    : "text-ink-100"
                }
              />
            ))}
          </div>
          <p className="mt-1.5 text-[13px] leading-relaxed text-ink-600 dark:text-ink-50/65">
            {r.comment}
          </p>
        </div>
      ))}
    </div>
  );
}
