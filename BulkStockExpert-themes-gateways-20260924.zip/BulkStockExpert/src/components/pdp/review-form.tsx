"use client";

import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { useFormState, useFormStatus } from "react-dom";
import { Star } from "lucide-react";
import {
  submitReview,
  type ReviewFormState,
} from "@/app/actions/review-actions";

const initialState: ReviewFormState = { ok: false, message: "" };
const MIN_COMMENT_LENGTH = 2;

function SubmitBtn({ disabled }: { disabled: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending || disabled}
      className="btn-primary !px-5 !py-2 text-[12.5px]"
    >
      {pending ? "Submitting..." : "Submit Review"}
    </button>
  );
}

export function ReviewForm({
  productId,
  productSlug,
}: {
  productId: string;
  productSlug: string;
}) {
  const [state, formAction] = useActionStateCompat(submitReview, initialState);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");
  const formRef = useRef<HTMLFormElement>(null);

  // Reset the form back to a clean slate after a successful submission, so the star rating
  // and text don't linger looking "already filled in" for the next review someone writes.
  useEffect(() => {
    if (state.ok) {
      setRating(0);
      setName("");
      setComment("");
      formRef.current?.reset();
    }
  }, [state.ok, state.message]);

  const missingRating = rating < 1;
  const commentTooShort = comment.trim().length < MIN_COMMENT_LENGTH;
  const missingName = name.trim().length < 2;
  const canSubmit = !missingRating && !commentTooShort && !missingName;

  return (
    <form ref={formRef} action={formAction} className="flex flex-col gap-2.5">
      <input type="hidden" name="productId" value={productId} />
      <input type="hidden" name="productSlug" value={productSlug} />
      <input type="hidden" name="rating" value={rating || ""} />

      <div>
        <div className="flex gap-1" onMouseLeave={() => setHoverRating(0)}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              type="button"
              key={n}
              onClick={() => setRating(n)}
              onMouseEnter={() => setHoverRating(n)}
              aria-pressed={rating === n}
              aria-label={`${n} star${n > 1 ? "s" : ""}`}
            >
              <Star
                size={20}
                className={
                  n <= (hoverRating || rating)
                    ? "fill-accent-500 text-accent-500"
                    : "text-ink-100"
                }
              />
            </button>
          ))}
        </div>
        {missingRating && (
          <p className="mt-1 text-[11.5px] text-ink-400 dark:text-ink-50/50">
            Tap a star to rate this product.
          </p>
        )}
      </div>
      <input
        name="customerName"
        placeholder="Your name"
        className="field-input"
        value={name}
        onChange={(e) => setName(e.target.value)}
        maxLength={80}
      />
      <input
        type="email"
        name="email"
        placeholder="Email (optional, kept private)"
        className="field-input"
        maxLength={254}
      />
      <textarea
        name="comment"
        rows={3}
        placeholder="Share your experience with this product... (at least 2 characters)"
        className="field-input resize-y"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        maxLength={2000}
      />
      <div className="flex items-center gap-3">
        <SubmitBtn disabled={!canSubmit} />
        {state.message && (
          <span
            role="status"
            className={`text-[12px] ${state.ok ? "text-emerald-700" : "text-red-600"}`}
          >
            {state.message}
          </span>
        )}
      </div>
    </form>
  );
}

// The App Router runs React 19, where useFormState was renamed to React.useActionState (the old
// name logs a deprecation error). Prefer the new hook and fall back for older React versions.
const useActionStateCompat: typeof useFormState =
  (React as unknown as { useActionState?: typeof useFormState })
    .useActionState ?? useFormState;
