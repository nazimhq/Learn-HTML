import { prisma } from "@/lib/prisma";
import {
  publicProductCardSelect,
  type PublicProductCard,
} from "@/lib/queries/product-select";
import { ProductCard } from "@/components/home/product-card";
import type { ProductCardData } from "@/types";
import type { Prisma } from "@prisma/client";

function toCardData(p: PublicProductCard): ProductCardData {
  return {
    id: p.id,
    name: p.name,
    slug: p.slug,
    brand: p.brand?.name ?? null,
    basePrice: Number(p.basePrice),
    compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
    imageUrl: p.images[0]?.url ?? "",
    ratingAvg: p.ratingAvg,
    reviewCount: p.reviewCount,
    inStock: p.variants.some((v) => v.stock > 0),
  };
}

/**
 * Finds 4-6 products to show as "You Might Also Like" below a product's description/reviews.
 * Prefers same-category matches first (most relevant), then tops up with same-tag matches if
 * the category alone doesn't yield enough, always excluding the active product itself.
 * Never throws — an empty/failed lookup just means the section renders nothing, since this is
 * a nice-to-have discovery aid, not a page-blocking feature.
 */
async function getRelatedProducts(params: {
  productId: string;
  categoryId: string;
  tags: unknown;
}): Promise<ProductCardData[]> {
  try {
    const take = 6;
    const sameCategory = await prisma.product.findMany({
      where: {
        id: { not: params.productId },
        status: "ACTIVE",
        categoryId: params.categoryId,
      },
      select: publicProductCardSelect,
      orderBy: { createdAt: "desc" },
      take,
    });

    if (sameCategory.length >= 4) return sameCategory.map(toCardData);

    // Top up with tag matches (Product.tags is a JSON string array — MySQL JSON has no
    // portable "array overlap" operator via Prisma, so we fetch a candidate pool and filter
    // the overlap in JS rather than trying to push it into the WHERE clause).
    const tags = Array.isArray(params.tags)
      ? (params.tags as unknown[]).filter(
          (t): t is string => typeof t === "string",
        )
      : [];
    let topUp: Prisma.ProductGetPayload<{
      select: typeof publicProductCardSelect;
    }>[] = [];
    if (tags.length > 0) {
      const excludeIds = new Set([
        params.productId,
        ...sameCategory.map((p) => p.id),
      ]);
      const candidates = await prisma.product.findMany({
        where: { id: { notIn: Array.from(excludeIds) }, status: "ACTIVE" },
        select: publicProductCardSelect,
        orderBy: { createdAt: "desc" },
        take: 40,
      });
      topUp = candidates
        .filter((c) => {
          const cTags = Array.isArray(c.tags)
            ? (c.tags as unknown[]).filter(
                (t): t is string => typeof t === "string",
              )
            : [];
          return cTags.some((t) => tags.includes(t));
        })
        .slice(0, take - sameCategory.length);
    }

    return [...sameCategory, ...topUp].map(toCardData);
  } catch {
    return [];
  }
}

export async function RelatedProducts({
  productId,
  categoryId,
  tags,
}: {
  productId: string;
  categoryId: string;
  tags: unknown;
}) {
  const products = await getRelatedProducts({ productId, categoryId, tags });
  if (products.length === 0) return null;

  return (
    <div className="mx-auto mt-14 max-w-6xl border-t border-ink-900/10 pt-8">
      <h2 className="mb-4 font-display text-lg">You Might Also Like</h2>
      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-6">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
