"use client";

import { signOut } from "next-auth/react";
import { LogOut } from "lucide-react";

export function SignOutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/" })}
      className="btn-secondary !px-4 !py-2 text-[12.5px]"
    >
      <LogOut size={14} /> Sign out
    </button>
  );
}
