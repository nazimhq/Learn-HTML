"use client";

import { useCartStore } from "@/store/cart-store";

/** Cart is client-only (Zustand + localStorage), so this reads it live in the browser rather
 * than trying to source it from the server-rendered dashboard around it. */
export function CartSummary() {
  const open = useCartStore((s) => s.open);
  const count = useCartStore((s) => s.lines.reduce((sum, l) => sum + l.qty, 0));

  return (
    <button
      onClick={open}
      className="rounded-2xl border border-ink-900/10 bg-white p-4 text-left transition hover:border-brand-500/40 dark:border-ink-50/10 dark:bg-panel"
    >
      <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
        In basket now
      </p>
      <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
        {count}
      </p>
    </button>
  );
}
