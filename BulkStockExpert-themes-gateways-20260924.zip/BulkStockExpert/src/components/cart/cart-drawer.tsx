"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { formatMoney } from "@/lib/constants";

export function CartDrawer() {
  const { lines, isOpen, close, changeQty, removeItem, subtotal } =
    useCartStore();

  const reduced = useReducedMotion();
  const panel = useRef<HTMLElement>(null);
  useEffect(() => {
    if (panel.current) panel.current.inert = !isOpen;
    if (!isOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panel.current?.querySelector<HTMLElement>("button")?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key !== "Tab") return;
      const nodes = panel.current?.querySelectorAll<HTMLElement>(
        "button:not([disabled]),a[href],input:not([disabled])",
      );
      if (!nodes?.length) return;
      const first = nodes[0],
        last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [isOpen, close]);
  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-ink-900/45 backdrop-blur-sm transition-opacity ${isOpen ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onClick={close}
      />
      <motion.aside
        ref={panel}
        role="dialog"
        aria-modal={isOpen}
        initial={false}
        animate={{ x: isOpen ? 0 : "100%" }}
        transition={{
          type: "spring",
          stiffness: 320,
          damping: 32,
          duration: reduced ? 0 : undefined,
        }}
        aria-hidden={!isOpen}
        className={`fixed right-0 top-0 z-[61] flex h-full w-full max-w-[400px] flex-col bg-panel shadow-2xl ${isOpen ? "" : "pointer-events-none"}`}
        aria-label="Shopping cart"
      >
        <div className="flex items-center justify-between border-b border-ink-900/10 px-5 py-4 dark:border-ink-50/10">
          <h3 className="flex items-center gap-2 font-display text-base">
            <ShoppingBag size={17} /> Your basket ({lines.length})
          </h3>
          <button onClick={close} aria-label="Close cart">
            <X size={19} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center text-ink-400 dark:text-ink-50/50">
              <ShoppingBag size={36} className="opacity-40" />
              <p className="text-sm">Your basket is empty</p>
              <button
                onClick={close}
                className="btn-primary mt-1 !px-5 !py-2 text-[13px]"
              >
                Continue shopping
              </button>
            </div>
          ) : (
            lines.map((l) => (
              <div
                key={l.variantId}
                className="flex gap-3 border-b border-ink-900/5 py-3.5 last:border-none dark:border-ink-50/10"
              >
                <div
                  className="h-14 w-14 flex-shrink-0 rounded-lg"
                  data-tint=""
style={{
                    background: "linear-gradient(135deg,#463924,#786240)",
                  }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium">{l.name}</p>
                  {l.variantLabel && (
                    <p className="text-[11.5px] text-ink-400 dark:text-ink-50/50">
                      {l.variantLabel}
                    </p>
                  )}
                  <div className="mt-2 flex items-center justify-between">
                    <div className="flex items-center rounded-full border border-ink-900/15 dark:border-ink-50/15">
                      <button
                        className="flex h-6 w-6 items-center justify-center"
                        onClick={() => changeQty(l.variantId, -1)}
                        aria-label="Decrease"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="w-6 text-center font-mono text-[12px] font-semibold">
                        {l.qty}
                      </span>
                      <button
                        className="flex h-6 w-6 items-center justify-center"
                        onClick={() => changeQty(l.variantId, 1)}
                        disabled={l.qty >= l.maxStock}
                        aria-label="Increase"
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                    <span className="font-mono text-[13px] font-semibold">
                      {formatMoney(l.price * l.qty)}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => removeItem(l.variantId)}
                  aria-label="Remove item"
                  className="self-start text-ink-400 dark:text-ink-50/50 hover:text-red-600"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))
          )}
        </div>

        {lines.length > 0 && (
          <div className="border-t border-ink-900/10 px-5 py-4 dark:border-ink-50/10">
            <div className="mb-3 flex items-center justify-between font-mono text-[13px] text-ink-400 dark:text-ink-50/50">
              <span>Subtotal</span>
              <span>{formatMoney(subtotal())}</span>
            </div>
            <p className="mb-3 text-[11.5px] text-ink-400 dark:text-ink-50/50">
              Delivery &amp; VAT calculated at checkout.
            </p>
            <Link
              href="/checkout"
              onClick={close}
              className="btn-primary w-full"
            >
              Checkout
            </Link>
          </div>
        )}
      </motion.aside>
    </>
  );
}
