"use client";

import { useState } from "react";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { SlidersHorizontal, X } from "lucide-react";

interface Option {
  id: string;
  name: string;
  slug: string;
}

export function ProductFilters({
  categories,
  brands,
}: {
  categories: Option[];
  brands: Option[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [mobileOpen, setMobileOpen] = useState(false);

  function setParam(key: string, value: string | null) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    router.push(`${pathname}?${params.toString()}`);
  }

  function clearAll() {
    router.push(pathname);
  }

  const body = (
    <>
      <div className="mb-5">
        <h4 className="mb-2 text-[12px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Category
        </h4>
        <label className="flex items-center gap-2 py-1 text-[13px]">
          <input
            type="radio"
            name="fcat"
            checked={!searchParams.get("category")}
            onChange={() => setParam("category", null)}
          />
          All categories
        </label>
        {categories.map((c) => (
          <label
            key={c.id}
            className="flex items-center gap-2 py-1 text-[13px]"
          >
            <input
              type="radio"
              name="fcat"
              checked={searchParams.get("category") === c.slug}
              onChange={() => setParam("category", c.slug)}
            />
            {c.name}
          </label>
        ))}
      </div>
      <div className="mb-5">
        <h4 className="mb-2 text-[12px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Brand
        </h4>
        <label className="flex items-center gap-2 py-1 text-[13px]">
          <input
            type="radio"
            name="fbrand"
            checked={!searchParams.get("brand")}
            onChange={() => setParam("brand", null)}
          />
          All brands
        </label>
        {brands.map((b) => (
          <label
            key={b.id}
            className="flex items-center gap-2 py-1 text-[13px]"
          >
            <input
              type="radio"
              name="fbrand"
              checked={searchParams.get("brand") === b.slug}
              onChange={() => setParam("brand", b.slug)}
            />
            {b.name}
          </label>
        ))}
      </div>
      <div className="mb-5">
        <h4 className="mb-2 text-[12px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Price (£)
        </h4>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="Min"
            defaultValue={searchParams.get("min") ?? ""}
            onBlur={(e) => setParam("min", e.target.value || null)}
            className="field-input !py-1.5 !text-[12.5px]"
          />
          <span className="text-ink-400 dark:text-ink-50/50">–</span>
          <input
            type="number"
            placeholder="Max"
            defaultValue={searchParams.get("max") ?? ""}
            onBlur={(e) => setParam("max", e.target.value || null)}
            className="field-input !py-1.5 !text-[12.5px]"
          />
        </div>
      </div>
      <label className="mb-5 flex items-center gap-2 text-[13px]">
        <input
          type="checkbox"
          checked={searchParams.get("inStock") === "1"}
          onChange={(e) => setParam("inStock", e.target.checked ? "1" : null)}
        />
        In stock only
      </label>
      <button
        onClick={clearAll}
        className="w-full rounded-lg border border-ink-900/15 py-2 text-[12px] font-semibold text-ink-400 dark:text-ink-50/50 hover:border-brand-500 hover:text-brand-600"
      >
        Clear filters
      </button>
    </>
  );

  return (
    <>
      <button
        className="mb-4 inline-flex items-center gap-2 rounded-full border border-ink-900/15 px-4 py-2 text-[12.5px] font-semibold lg:hidden"
        onClick={() => setMobileOpen(true)}
      >
        <SlidersHorizontal size={14} /> Filters
      </button>
      <aside className="hidden w-[220px] flex-shrink-0 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4 lg:block">
        {body}
      </aside>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-[60] bg-ink-900/45 lg:hidden"
          onClick={() => setMobileOpen(false)}
        >
          <div
            className="ml-auto flex h-full w-[82%] max-w-xs flex-col overflow-y-auto bg-panel p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <span className="font-semibold">Filters</span>
              <button onClick={() => setMobileOpen(false)}>
                <X size={18} />
              </button>
            </div>
            {body}
          </div>
        </div>
      )}
    </>
  );
}
