"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";

export interface HeroSlide {
  eyebrow: string;
  title: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  gradient: [string, string];
}

const AUTO_ADVANCE_MS = 4500;

export function HeroSlider({ slides }: { slides: HeroSlide[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const go = useCallback(
    (i: number) => {
      setIndex(((i % slides.length) + slides.length) % slides.length);
    },
    [slides.length],
  );

  useEffect(() => {
    if (paused || slides.length <= 1) return;
    timerRef.current = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length);
    }, AUTO_ADVANCE_MS);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [paused, slides.length]);

  if (slides.length === 0) return null;
  const slide = slides[index];

  return (
    <div
      className="relative h-full w-full overflow-hidden rounded-2xl border border-ink-50/10"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div
        key={index}
        className="hero-slide-active flex h-full min-h-[280px] w-full flex-col justify-end p-7 sm:min-h-[340px]"
        data-tint=""
style={{
          background: `linear-gradient(150deg, ${slide.gradient[0]}, ${slide.gradient[1]})`,
        }}
      >
        <span className="mb-2 font-mono text-[11px] uppercase tracking-[0.16em] text-ink-50/70">
          {slide.eyebrow}
        </span>
        <h3 className="font-display text-2xl leading-tight text-ink-50 sm:text-[28px]">
          {slide.title}
        </h3>
        <p className="mt-2 max-w-xs text-[13px] text-ink-50/75">{slide.body}</p>
        <Link
          href={slide.ctaHref}
          className="mt-4 inline-flex w-fit items-center gap-1.5 rounded-full bg-ink-50 px-4 py-2 text-[12.5px] font-semibold text-ink-900 transition hover:bg-accent-400"
        >
          {slide.ctaLabel} →
        </Link>
      </div>

      {slides.length > 1 && (
        <div className="absolute bottom-4 right-5 flex gap-1.5">
          {slides.map((_, i) => (
            <button
              key={i}
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => go(i)}
              className={`h-1.5 rounded-full transition-all ${i === index ? "w-6 bg-ink-50" : "w-1.5 bg-ink-50/40"}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
