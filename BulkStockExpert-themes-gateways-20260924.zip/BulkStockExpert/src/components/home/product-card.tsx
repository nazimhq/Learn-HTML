import { HoverCard } from "@/components/motion/hover-card";
import Link from "next/link";
import { Star } from "lucide-react";
import { formatMoney } from "@/lib/constants";
import type { ProductCardData } from "@/types";

// ProductCardData carries an optional `imageUrl` (see src/app/products/page.tsx, which reads
// `p.images[0]?.url`). Render it when the admin has uploaded a real photo; otherwise fall back
// to the gradient+initial placeholder every product used to always show, regardless of whether
// it actually had photos.

export function ProductCard({ product }: { product: ProductCardData }) {
  const off = product.compareAtPrice
    ? Math.round(
        ((product.compareAtPrice - product.basePrice) /
          product.compareAtPrice) *
          100,
      )
    : 0;

  return (
    <HoverCard>
      <Link
        href={`/products/${product.slug}`}
        className="skin-card group flex flex-col overflow-hidden rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-ink-900/5"
      >
        <div className="relative aspect-square overflow-hidden bg-ink-100">
          {product.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={product.imageUrl}
              alt={product.name}
              className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            />
          ) : (
            <div
              className="flex h-full w-full items-center justify-center text-ink-50/90 transition duration-500 group-hover:scale-105"
              data-tint=""
              style={{ background: "linear-gradient(135deg,#463924,#786240)" }}
            >
              <span className="font-display text-3xl opacity-40">
                {product.name.charAt(0)}
              </span>
            </div>
          )}
          {off > 0 && (
            <span className="absolute left-2.5 top-2.5 rounded-full bg-discount px-2.5 py-1 text-[10.5px] font-bold text-white">
              -{off}%
            </span>
          )}
          {!product.inStock && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/55 backdrop-blur-[1px]">
              <span className="rounded-full bg-white px-3 py-1 text-[11.5px] font-semibold shadow">
                Out of stock
              </span>
            </div>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-1 p-3.5">
          {product.brand && (
            <span className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              {product.brand}
            </span>
          )}
          <p className="line-clamp-2 text-[13.5px] font-medium leading-snug text-ink-900 dark:text-ink-50">
            {product.name}
          </p>
          <div className="flex items-center gap-1 text-[11.5px] text-ink-400 dark:text-ink-50/50">
            <Star size={12} className="fill-accent-500 text-accent-500" />
            {product.ratingAvg.toFixed(1)} ({product.reviewCount})
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-[15px] font-semibold text-ink-900 dark:text-ink-50">
              {formatMoney(product.basePrice)}
            </span>
            {product.compareAtPrice && (
              <span className="text-[11.5px] text-ink-400 dark:text-ink-50/50 line-through">
                {formatMoney(product.compareAtPrice)}
              </span>
            )}
          </div>
        </div>
      </Link>
    </HoverCard>
  );
}
