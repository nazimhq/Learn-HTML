"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { SlidersHorizontal, X, ArrowRight } from "lucide-react";
import { formatMoney } from "@/lib/constants";
import type { ProductCardData } from "@/types";
import { Reveal } from "@/components/motion/reveal";
import {
  CATEGORY_LOOK,
  FALLBACK_CATEGORY_LOOK,
} from "@/components/home/category-circles";

export interface BrowserCategory {
  id: string;
  name: string;
  slug: string;
  imageUrl?: string | null;
  /** Live count of active products in this category, used for the "140+ lots" style badge. */
  count: number;
}

type SortKey = "featured" | "price-asc" | "price-desc" | "newest";

const SORT_LABEL: Record<SortKey, string> = {
  featured: "Featured",
  "price-asc": "Price: low to high",
  "price-desc": "Price: high to low",
  newest: "Newest manifests",
};

const INITIAL_VISIBLE = 16;
const NEW_MANIFEST_WINDOW_DAYS = 21;

/** Derives the "Popular" / "New Manifest" pill for a card — an explicit admin-set tag wins,
 *  otherwise falls back to a simple recency/rating heuristic so the shelf never looks bare
 *  on a freshly-seeded catalogue. */
function deriveTag(
  p: ProductCardData,
): { label: string; className: string } | null {
  const explicit = (p.tags ?? []).map((t) => t.toLowerCase());
  if (explicit.some((t) => t.includes("popular")))
    return { label: "Popular", className: "bg-cta text-white" };
  if (explicit.some((t) => t.includes("new")))
    return { label: "New Manifest", className: "bg-combo text-white" };

  if (p.createdAt) {
    const ageDays = (Date.now() - new Date(p.createdAt).getTime()) / 86_400_000;
    if (ageDays <= NEW_MANIFEST_WINDOW_DAYS)
      return { label: "New Manifest", className: "bg-combo text-white" };
  }
  if (p.ratingAvg >= 4.3 && p.reviewCount >= 2)
    return { label: "Popular", className: "bg-cta text-white" };
  return null;
}

function formatLotCount(count: number): string {
  if (count <= 0) return "Coming soon";
  // Round down to the nearest 10 for the "140+ lots" style badge once a category has real
  // depth; small/seed catalogues just show the exact count so it never overstates stock.
  if (count >= 20) return `${Math.floor(count / 10) * 10}+ lots`;
  return `${count} lot${count === 1 ? "" : "s"}`;
}

function PalletCard({ product }: { product: ProductCardData }) {
  const tag = deriveTag(product);
  const hasSavings =
    product.compareAtPrice != null &&
    product.compareAtPrice > product.basePrice;
  const savingsPct = hasSavings
    ? Math.round(
        ((product.compareAtPrice! - product.basePrice) /
          product.compareAtPrice!) *
          100,
      )
    : 0;

  return (
    <Link
      href={`/products/${product.slug}`}
      className="skin-card group flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-[#161616] transition duration-300 hover:-translate-y-1 hover:border-cta/40 hover:shadow-lg hover:shadow-black/40"
    >
      <div className="relative aspect-square overflow-hidden bg-[#1f1f1f]">
        {product.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.imageUrl}
            alt={product.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#2a2a2a] to-[#161616] text-white/20">
            <span className="font-display text-3xl">
              {product.name.charAt(0)}
            </span>
          </div>
        )}
        {tag && (
          <span
            className={`absolute left-2.5 top-2.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wide ${tag.className}`}
          >
            {tag.label}
          </span>
        )}
        {hasSavings && (
          <span className="absolute right-2.5 top-2.5 rounded-full bg-discount px-2.5 py-1 text-[10.5px] font-bold text-white">
            Save {savingsPct}%
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <p className="line-clamp-2 text-[13.5px] font-medium leading-snug text-white/90">
          {product.name}
        </p>
        <div className="mt-auto flex items-baseline gap-2 font-mono">
          <span className="text-[16px] font-semibold text-white">
            {formatMoney(product.basePrice)}
          </span>
          {hasSavings && (
            <span className="text-[11.5px] text-white/40 line-through">
              MSRP {formatMoney(product.compareAtPrice!)}
            </span>
          )}
        </div>
        <span className="mt-1 inline-flex w-fit items-center gap-1.5 rounded-full bg-cta px-4 py-2 text-[12.5px] font-semibold text-white transition group-hover:bg-cta-600">
          View Details <ArrowRight size={13} />
        </span>
      </div>
    </Link>
  );
}

export function ProductBrowser({
  categories,
  products,
}: {
  categories: BrowserCategory[];
  products: ProductCardData[];
}) {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedFilterSlugs, setSelectedFilterSlugs] = useState<string[]>([]);
  const [sort, setSort] = useState<SortKey>("featured");

  const filtered = useMemo(() => {
    let rows = products;
    const activeFilters =
      selectedFilterSlugs.length > 0
        ? selectedFilterSlugs
        : activeCategory
          ? [activeCategory]
          : [];
    if (activeFilters.length > 0) {
      rows = rows.filter(
        (p) => p.categorySlug && activeFilters.includes(p.categorySlug),
      );
    }
    const sorted = [...rows];
    if (sort === "price-asc") sorted.sort((a, b) => a.basePrice - b.basePrice);
    else if (sort === "price-desc")
      sorted.sort((a, b) => b.basePrice - a.basePrice);
    else if (sort === "newest") {
      sorted.sort(
        (a, b) =>
          new Date(b.createdAt ?? 0).getTime() -
          new Date(a.createdAt ?? 0).getTime(),
      );
    }
    return sorted;
  }, [products, activeCategory, selectedFilterSlugs, sort]);

  const visible = expanded ? filtered : filtered.slice(0, INITIAL_VISIBLE);
  const remaining = filtered.length - visible.length;

  function toggleCategory(slug: string) {
    setActiveCategory((cur) => (cur === slug ? null : slug));
    setSelectedFilterSlugs([]);
  }

  function toggleFilterSlug(slug: string) {
    setSelectedFilterSlugs((cur) =>
      cur.includes(slug) ? cur.filter((s) => s !== slug) : [...cur, slug],
    );
    setActiveCategory(null);
  }

  function handleSeeMore() {
    setExpanded(true);
    setSidebarOpen(true);
  }

  if (categories.length === 0 && products.length === 0) return null;

  return (
    <section className="container-page py-10">
      {/* Circular category row */}
      {categories.length > 0 && (
        <div className="mb-10 flex gap-6 overflow-x-auto pb-2 sm:grid sm:grid-cols-4 sm:gap-6 md:grid-cols-7 md:overflow-visible">
          {categories.map((c, i) => {
            const look = CATEGORY_LOOK[c.slug] ?? FALLBACK_CATEGORY_LOOK;
            const Icon = look.icon;
            const isActive = activeCategory === c.slug;
            return (
              <Reveal key={c.id} delay={i * 60} className="flex-shrink-0">
                <button
                  type="button"
                  onClick={() => toggleCategory(c.slug)}
                  className="group flex flex-shrink-0 flex-col items-center gap-2.5 text-center"
                >
                  <span
                    className={`flex h-20 w-20 items-center justify-center overflow-hidden rounded-full text-white shadow-sm ring-2 transition duration-300 group-hover:-translate-y-1 group-hover:scale-105 group-hover:shadow-md sm:h-24 sm:w-24 ${
                      isActive
                        ? "ring-cta"
                        : "ring-transparent group-hover:ring-cta/50"
                    }`}
                  >
                    {c.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={c.imageUrl}
                        alt={c.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span
                        className="flex h-full w-full items-center justify-center"
                        style={{
                          background: `linear-gradient(135deg,${look.gradient[0]},${look.gradient[1]})`,
                        }}
                      >
                        <Icon size={30} strokeWidth={1.5} />
                      </span>
                    )}
                  </span>
                  <span
                    className={`w-24 text-[12.5px] font-semibold leading-tight ${isActive ? "text-cta" : "text-ink-900 dark:text-ink-50"}`}
                  >
                    {c.name}
                  </span>
                  <span className="text-[11px] text-ink-400 dark:text-ink-50/50">
                    {formatLotCount(c.count)}
                  </span>
                </button>
              </Reveal>
            );
          })}
        </div>
      )}

      {/* Product grid */}
      {visible.length === 0 ? (
        <p className="text-sm text-ink-400 dark:text-ink-50/50">
          No pallets in this category yet — check back soon.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {visible.map((p, i) => (
            <Reveal key={p.id} delay={(i % 8) * 50}>
              <PalletCard product={p} />
            </Reveal>
          ))}
        </div>
      )}

      {/* See more */}
      {!expanded && remaining > 0 && (
        <div className="mt-9 flex justify-center">
          <button
            type="button"
            onClick={handleSeeMore}
            className="btn-primary !bg-cta !px-8 hover:!bg-cta-600"
          >
            See More Products
          </button>
        </div>
      )}
      {expanded && (
        <div className="mt-9 flex justify-center">
          <button
            type="button"
            onClick={() => setSidebarOpen(true)}
            className="inline-flex items-center gap-2 rounded-full border border-ink-900/15 px-5 py-2.5 text-[13px] font-semibold text-ink-900 transition hover:border-cta/50 hover:text-cta dark:border-ink-50/20 dark:text-ink-50"
          >
            <SlidersHorizontal size={15} /> Filter &amp; sort all pallets
          </button>
        </div>
      )}

      {/* Sidebar filter overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <button
            type="button"
            aria-label="Close filters"
            onClick={() => setSidebarOpen(false)}
            className="absolute inset-0 bg-black/60 backdrop-blur-[1px]"
          />
          <div className="relative flex h-full w-full max-w-sm flex-col overflow-y-auto bg-[#161616] p-6 shadow-2xl animate-[fade-up-in_0.25s_ease]">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="font-display text-lg text-white">
                Filter &amp; sort
              </h3>
              <button
                type="button"
                onClick={() => setSidebarOpen(false)}
                className="rounded-full p-1.5 text-white/60 transition hover:bg-white/10 hover:text-white"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>

            <p className="mb-2 text-[11.5px] font-semibold uppercase tracking-wide text-white/40">
              Sort by
            </p>
            <div className="mb-6 flex flex-col gap-1.5">
              {(Object.keys(SORT_LABEL) as SortKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSort(key)}
                  className={`rounded-lg px-3 py-2 text-left text-[13px] font-medium transition ${
                    sort === key
                      ? "bg-cta text-white"
                      : "text-white/70 hover:bg-white/5"
                  }`}
                >
                  {SORT_LABEL[key]}
                </button>
              ))}
            </div>

            <p className="mb-2 text-[11.5px] font-semibold uppercase tracking-wide text-white/40">
              Categories
            </p>
            <div className="mb-6 flex flex-col gap-1">
              {categories.map((c) => {
                const checked = selectedFilterSlugs.includes(c.slug);
                return (
                  <label
                    key={c.id}
                    className="flex cursor-pointer items-center justify-between rounded-lg px-3 py-2 text-[13px] text-white/80 transition hover:bg-white/5"
                  >
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleFilterSlug(c.slug)}
                        className="h-4 w-4 rounded border-white/30 bg-transparent text-cta accent-cta"
                      />
                      {c.name}
                    </span>
                    <span className="text-[11px] text-white/35">{c.count}</span>
                  </label>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedFilterSlugs([]);
                setActiveCategory(null);
                setSort("featured");
              }}
              className="mb-3 text-[12.5px] font-medium text-white/50 underline-offset-2 hover:text-white hover:underline"
            >
              Clear all filters
            </button>
            <button
              type="button"
              onClick={() => setSidebarOpen(false)}
              className="btn-primary !bg-cta w-full hover:!bg-cta-600"
            >
              Show {filtered.length} pallet{filtered.length === 1 ? "" : "s"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
