import Link from "next/link";
import {
  Cpu,
  UtensilsCrossed,
  Shirt,
  Gamepad2,
  PackageOpen,
  Plug,
} from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export interface CategoryTile {
  id: string;
  name: string;
  slug: string;
  /** Admin-uploaded logo (Admin → Categories) — falls back to the gradient+icon look below. */
  imageUrl?: string | null;
}

/**
 * Icon + gradient per known category slug, with a sensible fallback for any future one.
 * Exported so other homepage sections (e.g. the pallet browser's own category row) can
 * reuse the exact same look without duplicating the map.
 */
export const CATEGORY_LOOK: Record<
  string,
  { icon: typeof Cpu; gradient: [string, string] }
> = {
  "electronics-returns": { icon: Cpu, gradient: ["#463924", "#786240"] },
  "home-kitchen": { icon: UtensilsCrossed, gradient: ["#5f4d32", "#241f19"] },
  "clothing-fashion": { icon: Shirt, gradient: ["#786240", "#463924"] },
  "toys-games": { icon: Gamepad2, gradient: ["#946f2f", "#171310"] },
  "mixed-general": { icon: PackageOpen, gradient: ["#241f19", "#5f4d32"] },
  "small-appliances": { icon: Plug, gradient: ["#171310", "#786240"] },
};
export const FALLBACK_CATEGORY_LOOK = {
  icon: PackageOpen,
  gradient: ["#463924", "#171310"] as [string, string],
};

/** Homepage category row — circular icon tiles linking into the filtered catalogue. */
export function CategoryCircles({
  categories,
}: {
  categories: CategoryTile[];
}) {
  if (categories.length === 0) return null;

  return (
    <section className="container-page py-10">
      <div className="flex gap-6 overflow-x-auto sm:grid sm:grid-cols-3 sm:gap-6 md:grid-cols-6 md:overflow-visible">
        {categories.map((c, i) => {
          const look = CATEGORY_LOOK[c.slug] ?? FALLBACK_CATEGORY_LOOK;
          const Icon = look.icon;
          return (
            <Reveal key={c.id} delay={i * 60} className="flex-shrink-0">
              <Link
                href={`/products?category=${c.slug}`}
                className="group flex flex-shrink-0 flex-col items-center gap-2.5 text-center"
              >
                {c.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={c.imageUrl}
                    alt={c.name}
                    className="h-20 w-20 rounded-full object-cover shadow-sm transition duration-300 group-hover:-translate-y-1 group-hover:scale-105 group-hover:shadow-md sm:h-24 sm:w-24"
                  />
                ) : (
                  <span
                    className="flex h-20 w-20 items-center justify-center rounded-full text-ink-50 shadow-sm transition duration-300 group-hover:-translate-y-1 group-hover:scale-105 group-hover:shadow-md sm:h-24 sm:w-24"
                    data-tint=""
style={{
                      background: `linear-gradient(135deg,${look.gradient[0]},${look.gradient[1]})`,
                    }}
                  >
                    <Icon size={30} strokeWidth={1.5} />
                  </span>
                )}
                <span className="w-24 text-[12.5px] font-semibold leading-tight text-ink-900 dark:text-ink-50">
                  {c.name}
                </span>
              </Link>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}
