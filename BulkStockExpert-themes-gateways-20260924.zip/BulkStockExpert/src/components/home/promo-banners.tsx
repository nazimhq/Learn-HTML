import Link from "next/link";
import { Reveal } from "@/components/motion/reveal";

export interface PromoBanner {
  eyebrow: string;
  title: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  gradient: [string, string];
  /** Which fixed semantic color badges the eyebrow pill — "deal" (amber) for offers/sales,
   *  "combo" (cyan/blue) for informational or bundle-style callouts. Defaults to "deal". */
  tag?: "deal" | "combo";
}

const TAG_CLASS: Record<"deal" | "combo", string> = {
  deal: "bg-deal text-ink-900",
  combo: "bg-combo text-white",
};

/** Two-tile promo strip, sits below the category row on the homepage. */
export function PromoBanners({ banners }: { banners: PromoBanner[] }) {
  return (
    <section className="container-page grid gap-5 pb-12 sm:grid-cols-2">
      {banners.map((b, i) => (
        <Reveal key={b.title} delay={i * 120}>
          <Link
            href={b.ctaHref}
            className="group relative flex min-h-[220px] flex-col justify-center overflow-hidden rounded-2xl p-8 transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-ink-900/10"
            data-tint=""
style={{
              background: `linear-gradient(135deg,${b.gradient[0]},${b.gradient[1]})`,
            }}
          >
            <div
              className="pointer-events-none absolute inset-0 opacity-20 transition duration-500 group-hover:scale-110 group-hover:opacity-30"
              style={{
                backgroundImage:
                  "repeating-linear-gradient(115deg, rgba(255,255,255,0.5) 0 1px, transparent 1px 48px)",
              }}
            />
            <span
              className={`relative mb-3 inline-block w-fit rounded-full px-3 py-1 font-mono text-[11px] font-bold uppercase tracking-[0.14em] ${TAG_CLASS[b.tag ?? "deal"]}`}
            >
              {b.eyebrow}
            </span>
            <h3 className="relative font-display text-[26px] leading-[1.1] text-ink-50 sm:text-[30px]">
              {b.title}
            </h3>
            <p className="relative mt-2 max-w-xs text-[13.5px] text-ink-50/75">
              {b.body}
            </p>
            <span className="btn-primary relative mt-5 w-fit !bg-white !text-ink-900 transition group-hover:!bg-accent-400 group-hover:!scale-105">
              {b.ctaLabel}
            </span>
          </Link>
        </Reveal>
      ))}
    </section>
  );
}
