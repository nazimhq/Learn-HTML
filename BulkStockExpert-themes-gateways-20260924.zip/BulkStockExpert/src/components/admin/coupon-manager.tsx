"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Pencil, Plus, TicketPercent, Trash2 } from "lucide-react";
import { deleteCoupon, saveCoupon } from "@/app/actions/admin-coupon-actions";
import { formatMoney } from "@/lib/constants";

interface Coupon {
  id: string;
  code: string;
  type: "PERCENT" | "FIXED";
  value: number;
  minSubtotal: number | null;
  expiresAt: string | null;
  isActive: boolean;
  uses: number;
}

const blank = { code: "", type: "PERCENT" as const, value: "10", minSubtotal: "", expiresAt: "", isActive: true };

export function CouponManager({ coupons }: { coupons: Coupon[] }) {
  const router = useRouter();
  const [form, setForm] = useState<{ id?: string; code: string; type: "PERCENT" | "FIXED"; value: string; minSubtotal: string; expiresAt: string; isActive: boolean }>(blank);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  const today = new Date().toISOString().slice(0, 10);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);
    start(async () => {
      const r = await saveCoupon({
        id: form.id,
        code: form.code,
        type: form.type,
        value: Number(form.value),
        minSubtotal: form.minSubtotal.trim() === "" ? null : Number(form.minSubtotal),
        expiresAt: form.expiresAt || null,
        isActive: form.isActive,
      });
      setMessage({ ok: r.ok, text: r.message });
      if (r.ok) {
        setForm(blank);
        router.refresh();
      }
    });
  }

  const card = "rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel";

  return (
    <div className="max-w-5xl">
      <h1 className="flex items-center gap-2 font-display text-2xl">
        <TicketPercent size={22} /> Coupons
      </h1>
      <p className="my-3 text-[13.5px] text-ink-400 dark:text-ink-50/60">
        Discount codes shoppers enter at checkout. Fixed amounts and minimum spends are in GBP and
        converted for other currencies.
      </p>
      {message && (
        <p role={message.ok ? "status" : "alert"} className={`mb-4 rounded-xl px-4 py-2.5 text-[13px] ${message.ok ? "bg-emerald-600/10 text-emerald-700 dark:text-emerald-300" : "bg-red-600/10 text-red-700 dark:text-red-300"}`}>
          {message.text}
        </p>
      )}

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <section className={card}>
          {coupons.length === 0 ? (
            <p className="py-8 text-center text-[13px] text-ink-400">No coupons yet. Create one on the right.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[520px] text-left text-[13px]">
                <thead className="text-[11.5px] uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
                  <tr>
                    <th className="py-2 pr-3">Code</th>
                    <th className="py-2 pr-3">Discount</th>
                    <th className="py-2 pr-3">Rules</th>
                    <th className="py-2 pr-3">Status</th>
                    <th className="py-2 text-right">Uses</th>
                    <th className="py-2"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-900/5 dark:divide-ink-50/10">
                  {coupons.map((c) => {
                    const expired = c.expiresAt !== null && c.expiresAt < today;
                    return (
                      <tr key={c.id}>
                        <td className="py-2.5 pr-3 font-mono font-semibold">{c.code}</td>
                        <td className="py-2.5 pr-3">{c.type === "PERCENT" ? `${c.value}% off` : `${formatMoney(c.value, "GBP")} off`}</td>
                        <td className="py-2.5 pr-3 text-[12px] text-ink-400 dark:text-ink-50/60">
                          {c.minSubtotal ? `Min ${formatMoney(c.minSubtotal, "GBP")}` : "No minimum"}
                          {c.expiresAt ? ` · until ${c.expiresAt}` : ""}
                        </td>
                        <td className="py-2.5 pr-3">
                          <span className={`rounded-full px-2 py-0.5 text-[11.5px] ${!c.isActive ? "bg-ink-900/5 text-ink-400 dark:bg-ink-50/10" : expired ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-emerald-600/10 text-emerald-700 dark:text-emerald-300"}`}>
                            {!c.isActive ? "Off" : expired ? "Expired" : "Active"}
                          </span>
                        </td>
                        <td className="py-2.5 text-right">{c.uses}</td>
                        <td className="py-2.5 text-right">
                          <button
                            type="button"
                            className="rounded-full p-1.5 hover:bg-ink-900/5 dark:hover:bg-ink-50/10"
                            aria-label={`Edit ${c.code}`}
                            onClick={() =>
                              setForm({
                                id: c.id,
                                code: c.code,
                                type: c.type,
                                value: String(c.value),
                                minSubtotal: c.minSubtotal == null ? "" : String(c.minSubtotal),
                                expiresAt: c.expiresAt ?? "",
                                isActive: c.isActive,
                              })
                            }
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            type="button"
                            className="rounded-full p-1.5 text-red-600 hover:bg-red-500/10"
                            aria-label={`Delete ${c.code}`}
                            onClick={() => {
                              if (!confirm(`Delete coupon ${c.code}?`)) return;
                              start(async () => {
                                const r = await deleteCoupon(c.id);
                                setMessage({ ok: r.ok, text: r.message });
                                router.refresh();
                              });
                            }}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <form onSubmit={submit} className={`${card} h-fit`}>
          <h2 className="mb-3 flex items-center gap-2 font-display text-base">
            {form.id ? <Pencil size={15} /> : <Plus size={15} />} {form.id ? `Edit ${form.code}` : "New coupon"}
          </h2>
          <label className="field-label" htmlFor="c-code">Code</label>
          <input id="c-code" className="field-input font-mono uppercase" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="WELCOME10" required />
          <div className="mt-3 grid grid-cols-2 gap-2">
            <div>
              <label className="field-label" htmlFor="c-type">Type</label>
              <select id="c-type" className="field-input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "PERCENT" | "FIXED" })}>
                <option value="PERCENT">% off</option>
                <option value="FIXED">£ off</option>
              </select>
            </div>
            <div>
              <label className="field-label" htmlFor="c-value">Amount</label>
              <input id="c-value" inputMode="decimal" className="field-input" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} required />
            </div>
          </div>
          <label className="field-label mt-3" htmlFor="c-min">Minimum spend (£, optional)</label>
          <input id="c-min" inputMode="decimal" className="field-input" value={form.minSubtotal} onChange={(e) => setForm({ ...form, minSubtotal: e.target.value })} />
          <label className="field-label mt-3" htmlFor="c-exp">Expires (optional)</label>
          <input id="c-exp" type="date" className="field-input" value={form.expiresAt} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} />
          <label className="mt-3 flex items-center gap-2 text-[13px]">
            <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> Active
          </label>
          <div className="mt-4 flex gap-2">
            <button className="btn-primary" disabled={pending}>{pending ? "Saving…" : form.id ? "Save changes" : "Create coupon"}</button>
            {form.id && (
              <button type="button" className="btn-secondary" onClick={() => setForm(blank)}>Cancel</button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
