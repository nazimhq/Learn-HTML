"use client";

import { useState, useTransition } from "react";
import { setCustomerActive } from "@/app/actions/admin-customer-actions";

export function CustomerActiveToggle({ id, isActive }: { id: string; isActive: boolean }) {
  const [active, setActive] = useState(isActive);
  const [pending, start] = useTransition();
  const [error, setError] = useState("");
  return (
    <div>
      <button
        type="button"
        disabled={pending}
        onClick={() =>
          start(async () => {
            const r = await setCustomerActive(id, !active);
            if (r.ok) setActive(!active);
            setError(r.ok ? "" : r.message);
          })
        }
        className={`rounded-full px-3 py-1 text-[12px] font-medium ${
          active
            ? "bg-emerald-600/10 text-emerald-700 hover:bg-emerald-600/20 dark:text-emerald-300"
            : "bg-red-600/10 text-red-700 hover:bg-red-600/20 dark:text-red-300"
        }`}
        title={active ? "Click to disable this login" : "Click to enable this login"}
      >
        {pending ? "…" : active ? "Enabled" : "Disabled"}
      </button>
      {error && <p role="alert" className="mt-1 text-[11.5px] text-red-600">{error}</p>}
    </div>
  );
}
