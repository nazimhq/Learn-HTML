"use client";
import { useEffect, useState } from "react";
import { Check, ChevronDown, Copy, Globe2, ShieldCheck } from "lucide-react";
import { GATEWAYS, GATEWAY_WEBHOOKS, REGION_NAMES, type Region } from "@/lib/gateway-catalog";
import { saveGateway } from "@/app/actions/gateway-actions";

const FIELD_LABELS: Record<string, string> = {
  publishableKey: "Publishable key",
  secretKey: "Secret key",
  webhookSecret: "Webhook signing secret",
  clientId: "Client ID",
  clientSecret: "Client secret",
  webhookId: "Webhook ID",
  storeId: "Store ID",
  storePassword: "Store password",
  apiKey: "API key",
  keyId: "Key ID",
  keySecret: "Key secret",
  username: "Username",
  password: "Password",
  appKey: "App key",
  appSecret: "App secret",
  merchantId: "Merchant ID",
  publicKey: "Public key",
};

const NOTES: Record<string, string> = {
  stripe: "Cards, Apple Pay and Google Pay. Needed for Klarna and Clearpay too.",
  klarna: "Uses your Stripe account. Enable Klarna in the Stripe dashboard first.",
  clearpay: "Uses your Stripe account. Enable Afterpay/Clearpay in Stripe first.",
  sslcommerz: "Bangladesh cards and wallets (bKash, Nagad, Rocket, Upay) through one account.",
  bkash: "Direct bKash merchant account (tokenized checkout). Sandbox and live credentials come from bKash.",
  mollie: "Use a test_ key in sandbox and a live_ key for real payments. The key decides the mode.",
  razorpay: "India: UPI, cards, netbanking and wallets via Razorpay payment links.",
  paystack: "Nigeria, Ghana, Kenya, South Africa. Webhook signature is checked with your secret key.",
  flutterwave: "Nigeria, Ghana, Kenya, South Africa and more. Each payment is re-verified with Flutterwave.",
  cod: "No API keys needed.",
};

function CopyUrl({ path }: { path: string }) {
  const [copied, setCopied] = useState(false);
  // Filled in after mount so server and client render the same markup.
  const [origin, setOrigin] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  const url = `${origin}${path}`;
  return (
    <div className="mt-3 flex items-center gap-2 rounded-lg bg-ink-900/5 px-3 py-2 text-[12px] dark:bg-ink-50/5">
      <span className="shrink-0 font-semibold">Webhook URL</span>
      <code className="min-w-0 flex-1 truncate font-mono" title={url}>
        {url}
      </code>
      <button
        type="button"
        className="shrink-0 rounded p-1 hover:bg-ink-900/10 dark:hover:bg-ink-50/10"
        aria-label="Copy webhook URL"
        onClick={() => {
          navigator.clipboard?.writeText(url).then(
            () => {
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            },
            () => {},
          );
        }}
      >
        {copied ? <Check size={14} /> : <Copy size={14} />}
      </button>
    </div>
  );
}

export function GatewayManager({
  initial,
}: {
  initial: { id: string; enabled: boolean; mode: string }[];
}) {
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [enabled, setEnabled] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(
      GATEWAYS.map((g) => [g.id, initial.find((r) => r.id === g.id)?.enabled ?? g.id === "cod"]),
    ),
  );
  const ready = GATEWAYS.filter((g) => g.ready);
  const slots = GATEWAYS.filter((g) => !g.ready);

  return (
    <div className="max-w-6xl">
      <h1 className="flex items-center gap-2 font-display text-2xl">
        <ShieldCheck size={22} /> Payment gateways
      </h1>
      <p className="my-3 max-w-3xl text-[13.5px] text-ink-400 dark:text-ink-50/60">
        Credentials are encrypted at rest and never shown again. Leave a field blank to keep the
        saved value. Each gateway only appears at checkout for its countries, and only once it is
        enabled with all its keys. Exchange rates for non-GBP countries are set in{" "}
        <a className="underline" href="/admin/currencies">
          Currencies
        </a>
        .
      </p>
      {message && (
        <p
          role={message.ok ? "status" : "alert"}
          className={`mb-4 rounded-xl px-4 py-2.5 text-[13px] ${
            message.ok
              ? "bg-emerald-600/10 text-emerald-700 dark:text-emerald-300"
              : "bg-red-600/10 text-red-700 dark:text-red-300"
          }`}
        >
          {message.text}
        </p>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        {ready.map((g) => {
          const saved = initial.find((r) => r.id === g.id);
          const on = enabled[g.id];
          return (
            <form
              key={g.id}
              className={`rounded-2xl border bg-white p-5 dark:bg-panel ${
                on ? "border-accent-500/50" : "border-ink-900/10 dark:border-ink-50/10"
              }`}
              onSubmit={async (e) => {
                e.preventDefault();
                setBusy(g.id);
                setMessage(null);
                const f = new FormData(e.currentTarget);
                try {
                  const r = await saveGateway({
                    id: g.id,
                    enabled: f.get("enabled") === "on",
                    mode: f.get("mode") ?? "sandbox",
                    credentials: Object.fromEntries(g.fields.map((k) => [k, String(f.get(k) ?? "")])),
                  });
                  setMessage({ ok: r.ok, text: `${g.name}: ${r.message}` });
                } catch {
                  setMessage({ ok: false, text: "Unable to save. Please retry." });
                } finally {
                  setBusy(null);
                }
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{g.name}</h2>
                  {NOTES[g.id] && (
                    <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">{NOTES[g.id]}</p>
                  )}
                </div>
                <label className="inline-flex shrink-0 cursor-pointer items-center gap-2 text-[12.5px] font-semibold">
                  <span className="relative inline-flex">
                    <input
                      type="checkbox"
                      role="switch"
                      name="enabled"
                      className="peer sr-only"
                      checked={on}
                      onChange={(e) => setEnabled((s) => ({ ...s, [g.id]: e.target.checked }))}
                    />
                    <span className="h-6 w-11 rounded-full bg-ink-900/15 transition peer-checked:bg-accent-500 peer-focus-visible:ring-2 peer-focus-visible:ring-accent-500/40 dark:bg-ink-50/20" />
                    <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
                  </span>
                  {on ? "Enabled" : "Off"}
                </label>
              </div>

              <p className="mt-3 flex flex-wrap items-center gap-1.5 text-[11.5px]">
                <Globe2 size={13} aria-hidden="true" className="text-ink-400" />
                {g.regions.map((r) => (
                  <span key={r} className="rounded-full border border-ink-900/10 px-2 py-0.5 dark:border-ink-50/15">
                    {REGION_NAMES[r as Region] ?? r}
                  </span>
                ))}
              </p>

              {g.id !== "cod" && (
                <label className="mt-3 block text-[12.5px] font-medium">
                  Mode
                  <select name="mode" className="field-input mt-1" defaultValue={saved?.mode ?? "sandbox"}>
                    <option value="sandbox">Sandbox / test</option>
                    <option value="live">Live</option>
                  </select>
                </label>
              )}
              {g.fields.map((field) => (
                <label className="mt-3 block text-[12.5px] font-medium" key={field}>
                  {FIELD_LABELS[field] ?? field}
                  <input
                    className="field-input mt-1"
                    name={field}
                    type="password"
                    autoComplete="new-password"
                    placeholder={saved ? "Saved. Leave blank to keep" : "Not set"}
                  />
                </label>
              ))}
              {GATEWAY_WEBHOOKS[g.id] && <CopyUrl path={GATEWAY_WEBHOOKS[g.id]} />}
              <button className="btn-primary mt-4 !px-5 !py-2.5" disabled={busy !== null}>
                {busy === g.id ? "Saving…" : "Save"}
              </button>
            </form>
          );
        })}
      </div>

      <details className="group mt-8 rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel">
        <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-semibold">
          <span>
            Extension slots ({slots.length}){" "}
            <span className="font-normal text-ink-400 dark:text-ink-50/50">
              · reserved for future integrations, not active
            </span>
          </span>
          <ChevronDown size={18} className="transition group-open:rotate-180" />
        </summary>
        <p className="mt-3 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          These providers need a developer to build and test their adapter and verified callback
          before they can be switched on. They are listed so nothing is lost from the original
          registry.
        </p>
        <ul className="mt-3 flex flex-wrap gap-1.5">
          {slots.map((g) => (
            <li
              key={g.id}
              className="rounded-full border border-ink-900/10 px-2.5 py-1 font-mono text-[11.5px] dark:border-ink-50/15"
            >
              {g.id}
            </li>
          ))}
        </ul>
      </details>
    </div>
  );
}
