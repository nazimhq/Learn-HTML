"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Tags,
  Truck,
  Users,
  LogOut,
  ExternalLink,
  ShieldCheck,
  FileText,
  Star,
  Palette,
  Coins,
  TicketPercent,
  UserRound,
} from "lucide-react";
import { NotificationBell } from "@/components/admin/notification-bell";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/categories", label: "Categories", icon: Tags },
  { href: "/admin/reviews", label: "Reviews", icon: Star },
  { href: "/admin/customers", label: "Customers", icon: UserRound },
  { href: "/admin/coupons", label: "Coupons", icon: TicketPercent },
  { href: "/admin/leads", label: "Leads", icon: Users },
  { href: "/admin/content", label: "Content pages", icon: FileText },
  { href: "/admin/payments", label: "Payments", icon: ShieldCheck },
  { href: "/admin/currencies", label: "Currencies", icon: Coins },
  { href: "/admin/settings", label: "Delivery & Settings", icon: Truck },
  { href: "/admin/appearance", label: "Design & themes", icon: Palette },
];

export function AdminSidebar({
  userName,
  isSuperAdmin,
  siteName,
}: {
  userName: string;
  isSuperAdmin?: boolean;
  siteName?: string;
}) {
  const pathname = usePathname();
  const nav = isSuperAdmin
    ? [...NAV, { href: "/admin/team", label: "Team", icon: ShieldCheck }]
    : NAV;

  return (
    <aside className="flex w-[220px] flex-shrink-0 flex-col border-r border-ink-900/10 bg-ink-900 text-ink-100">
      <div className="flex items-start justify-between border-b border-ink-50/10 px-5 py-5">
        <div>
          <span className="font-display text-lg text-ink-50">
            {siteName || "BulkStockExpert Ltd"}
          </span>
          <p className="text-[11px] text-ink-100/50">Admin panel</p>
        </div>
        <NotificationBell />
      </div>
      <nav className="flex flex-1 flex-col gap-0.5 p-3">
        {nav.map((item) => {
          const active =
            pathname === item.href ||
            (item.href !== "/admin" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-medium ${
                active
                  ? "bg-ink-50/10 text-ink-50"
                  : "text-ink-100/70 hover:bg-ink-50/5 hover:text-ink-50"
              }`}
            >
              <item.icon size={16} /> {item.label}
            </Link>
          );
        })}
        <Link
          href="/"
          target="_blank"
          className="mt-3 flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-medium text-ink-100/70 hover:bg-ink-50/5 hover:text-ink-50"
        >
          <ExternalLink size={16} /> View store
        </Link>
      </nav>
      <div className="border-t border-ink-50/10 p-3">
        <p className="truncate px-3 py-1 text-[11.5px] text-ink-100/50">
          {userName}
        </p>
        <button
          onClick={() => signOut({ callbackUrl: "/admin/login" })}
          className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-[13px] font-medium text-ink-100/70 hover:bg-ink-50/5 hover:text-ink-50"
        >
          <LogOut size={16} /> Sign out
        </button>
      </div>
    </aside>
  );
}
