"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import { Clock, ExternalLink, Palette, Plus, RefreshCw, Trash2 } from "lucide-react";
import { saveSiteTheme } from "@/app/actions/site-theme-actions";
import {
  ACCENTS,
  SKINS,
  resolveTheme,
  type AccentId,
  type ColorMode,
  type ResolvedTheme,
  type SkinId,
  type ThemeSlot,
} from "@/lib/site-theme";

interface State {
  skin: SkinId;
  accent: AccentId;
  mode: ColorMode;
  rotationEnabled: boolean;
  rotationMode: "interval" | "schedule";
  rotationHours: number;
  timezone: string;
  slots: ThemeSlot[];
}

const HOUR_PRESETS = [3, 5, 6, 12, 24];
const COMMON_ZONES = [
  "UTC",
  "Europe/London",
  "Europe/Paris",
  "America/New_York",
  "America/Chicago",
  "America/Los_Angeles",
  "America/Toronto",
  "Asia/Dhaka",
  "Asia/Kolkata",
  "Asia/Dubai",
  "Asia/Singapore",
  "Australia/Sydney",
  "Africa/Lagos",
];

const skinLabel = (id: string) => SKINS.find((s) => s.id === id)?.label ?? id;
const accentOf = (id: string) => ACCENTS.find((a) => a.id === id);

function lookLabel(l: { skin: string; accent: string; mode: string }) {
  return `${skinLabel(l.skin)} · ${accentOf(l.accent)?.label ?? l.accent} · ${l.skin === "nexaweb" ? "dark" : l.mode}`;
}

function formatWhen(iso: string | null) {
  if (!iso) return null;
  return new Date(iso).toLocaleString(undefined, {
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Tiny visual preview of a design + accent + mode. */
function LookPreview({ skin, accent, mode }: { skin: string; accent: string; mode: string }) {
  const color = accentOf(accent)?.swatch ?? "#8b5cf6";
  const dark = skin === "nexaweb" || mode === "dark";
  const bg = skin === "nexaweb" ? "#0b0b0e" : dark ? "#121212" : "#ffffff";
  const line = dark ? "rgba(255,255,255,0.14)" : "rgba(23,19,16,0.12)";
  const text = dark ? "rgba(255,255,255,0.85)" : "#171310";
  return (
    <div
      aria-hidden="true"
      className="relative h-24 w-full overflow-hidden rounded-lg border"
      style={{ background: bg, borderColor: line }}
    >
      {skin === "nexaweb" && (
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(70% 80% at 85% 0%, ${color}55, transparent 70%)`,
          }}
        />
      )}
      <div className="relative flex h-full flex-col justify-between p-3">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-sm" style={{ background: color }} />
          <span
            className="h-1.5 w-12 rounded-full"
            style={{ background: text, opacity: 0.7 }}
          />
        </div>
        <div>
          <div
            className={`text-[13px] leading-tight ${skin === "nexaweb" ? "font-grotesk font-semibold" : "font-display"}`}
            style={{ color: text }}
          >
            Your store
          </div>
          <span
            className="mt-1.5 inline-block rounded-full px-2.5 py-0.5 text-[10px] font-semibold text-white"
            style={{
              background: color,
              boxShadow: skin === "nexaweb" ? `0 0 14px ${color}aa` : undefined,
            }}
          >
            Shop now
          </span>
        </div>
      </div>
    </div>
  );
}

export function DesignThemesManager({
  initial,
  active,
  migrated,
}: {
  initial: State;
  active: ResolvedTheme;
  migrated: boolean;
}) {
  const [state, setState] = useState<State>(initial);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [isPending, startTransition] = useTransition();
  const [now, setNow] = useState(() => new Date());
  const [zones, setZones] = useState<string[]>(COMMON_ZONES);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30_000);
    try {
      const all = (Intl as unknown as { supportedValuesOf?: (k: string) => string[] })
        .supportedValuesOf?.("timeZone");
      if (all?.length) setZones(Array.from(new Set([...COMMON_ZONES, ...all])));
    } catch {}
    return () => clearInterval(id);
  }, []);

  // Live preview of what the rotation would show with the unsaved settings.
  const preview = useMemo(
    () =>
      resolveTheme(
        { skin: state.skin, accent: state.accent, mode: state.mode },
        {
          skin: state.skin,
          rotationEnabled: state.rotationEnabled,
          rotationMode: state.rotationMode,
          rotationHours: state.rotationHours,
          timezone: state.timezone,
          slots: state.slots,
        },
        now,
      ),
    [state, now],
  );

  const set = <K extends keyof State>(key: K, value: State[K]) =>
    setState((s) => ({ ...s, [key]: value }));
  const setSlot = (i: number, patch: Partial<ThemeSlot>) =>
    setState((s) => ({
      ...s,
      slots: s.slots.map((slot, j) => (j === i ? { ...slot, ...patch } : slot)),
    }));

  function save() {
    setMessage(null);
    startTransition(async () => {
      const res = await saveSiteTheme({
        ...state,
        slots: state.slots.map((s) =>
          state.rotationMode === "schedule" ? s : { skin: s.skin, accent: s.accent, mode: s.mode },
        ),
      });
      setMessage({ ok: res.ok, text: res.message });
    });
  }

  const card =
    "rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel";
  const muted = "text-[12.5px] text-ink-400 dark:text-ink-50/50";

  return (
    <div className="flex max-w-5xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 font-display text-2xl">
            <Palette size={22} /> Design &amp; themes
          </h1>
          <p className={`mt-1 ${muted}`}>
            Choose the storefront design, its colour, and optionally let the look change
            automatically on a timer.
          </p>
        </div>
        <a href="/" target="_blank" rel="noopener" className="btn-secondary !px-4 !py-2 text-[12.5px]">
          View storefront <ExternalLink size={14} />
        </a>
      </div>

      {!migrated && (
        <p role="alert" className="rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-[13px]">
          The design settings table isn&apos;t in the database yet. Run
          <code className="mx-1 font-mono">migration-themes-gateways.sql</code>
          once, then reload this page. The storefront keeps using the Classic design until then.
        </p>
      )}

      <section className={card} aria-labelledby="live-now">
        <h2 id="live-now" className="mb-3 font-display text-base">
          Live on the storefront now
        </h2>
        <div className="grid gap-4 sm:grid-cols-[180px_1fr] sm:items-center">
          <LookPreview skin={active.skin} accent={active.accent} mode={active.mode} />
          <div className="text-[13.5px]">
            <p className="font-semibold">{lookLabel(active)}</p>
            <p className={`mt-1 ${muted}`}>
              {active.source === "rotation"
                ? `Chosen by the automatic rotation. Next change: ${formatWhen(active.nextChangeAt)}.`
                : "Your fixed design. Automatic rotation is off."}
            </p>
          </div>
        </div>
      </section>

      <section className={card} aria-labelledby="design-heading">
        <h2 id="design-heading" className="mb-1 font-display text-base">
          Design
        </h2>
        <p className={`mb-4 ${muted}`}>
          The overall look of the store: fonts, backgrounds, cards and buttons. Used whenever
          automatic rotation is off.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          {SKINS.map((s) => {
            const selected = state.skin === s.id;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() =>
                  setState((prev) => ({
                    ...prev,
                    skin: s.id,
                    // NEXAWEB is designed around electric purple on dark; start there.
                    ...(s.id === "nexaweb" && prev.skin !== "nexaweb"
                      ? { accent: "purple" as AccentId, mode: "dark" as ColorMode }
                      : {}),
                  }))
                }
                aria-pressed={selected}
                className={`rounded-xl border-2 p-3 text-left transition ${
                  selected
                    ? "border-accent-500 ring-2 ring-accent-500/20"
                    : "border-ink-900/10 hover:border-ink-900/25 dark:border-ink-50/10 dark:hover:border-ink-50/30"
                }`}
              >
                <LookPreview
                  skin={s.id}
                  accent={selected ? state.accent : s.id === "nexaweb" ? "purple" : state.accent}
                  mode={s.id === "nexaweb" ? "dark" : state.mode}
                />
                <p className="mt-2.5 text-[13.5px] font-semibold">{s.label}</p>
                <p className={muted}>{s.description}</p>
              </button>
            );
          })}
        </div>

        <p className="mb-2 mt-5 text-[12px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Accent colour
        </p>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => set("accent", a.id)}
              aria-pressed={state.accent === a.id}
              className={`flex items-center gap-2.5 rounded-xl border-2 px-3 py-2.5 text-left text-[12.5px] font-medium transition ${
                state.accent === a.id
                  ? "border-brand-500 bg-brand-50 dark:bg-brand-900/30"
                  : "border-ink-900/10 hover:border-ink-900/25 dark:border-ink-50/10 dark:hover:border-ink-50/30"
              }`}
            >
              <span
                className="h-6 w-6 flex-shrink-0 rounded-full border border-black/10"
                style={{ backgroundColor: a.swatch }}
              />
              {a.label}
            </button>
          ))}
        </div>

        <p className="mb-2 mt-5 text-[12px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Default appearance
        </p>
        <div className="flex flex-wrap items-center gap-2.5">
          {(["light", "dark"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => set("mode", m)}
              disabled={state.skin === "nexaweb"}
              aria-pressed={state.mode === m}
              className={`rounded-full border-2 px-4 py-1.5 text-[12.5px] font-medium capitalize transition disabled:opacity-40 ${
                state.mode === m
                  ? "border-brand-500 bg-brand-50 dark:bg-brand-900/30"
                  : "border-ink-900/10 hover:border-ink-900/25 dark:border-ink-50/10"
              }`}
            >
              {m}
            </button>
          ))}
          {state.skin === "nexaweb" && (
            <span className={muted}>The NEXAWEB design is always dark.</span>
          )}
        </div>
      </section>

      <section className={card} aria-labelledby="rotation-heading">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 id="rotation-heading" className="flex items-center gap-2 font-display text-base">
              <RefreshCw size={16} /> Automatic theme change
            </h2>
            <p className={`mt-1 ${muted}`}>
              Switch between looks on a timer, for example every 6 hours, or at set times each
              day. Turn it off any time to go back to the design above.
            </p>
          </div>
          <label className="inline-flex cursor-pointer items-center gap-2.5 text-[13px] font-semibold">
            <span>{state.rotationEnabled ? "On" : "Off"}</span>
            <span className="relative inline-flex">
              <input
                type="checkbox"
                role="switch"
                className="peer sr-only"
                checked={state.rotationEnabled}
                onChange={(e) => set("rotationEnabled", e.target.checked)}
              />
              <span className="h-6 w-11 rounded-full bg-ink-900/15 transition peer-checked:bg-accent-500 peer-focus-visible:ring-2 peer-focus-visible:ring-accent-500/40 dark:bg-ink-50/20" />
              <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
            </span>
          </label>
        </div>

        <fieldset
          disabled={!state.rotationEnabled}
          className={`mt-5 flex flex-col gap-5 transition ${state.rotationEnabled ? "" : "opacity-50"}`}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            {(
              [
                ["interval", "Every few hours", "Cycle through the looks below in order."],
                ["schedule", "At set times each day", "Each look starts at its own time."],
              ] as const
            ).map(([value, title, help]) => (
              <label
                key={value}
                className={`flex cursor-pointer gap-3 rounded-xl border-2 p-3.5 ${
                  state.rotationMode === value
                    ? "border-accent-500"
                    : "border-ink-900/10 dark:border-ink-50/10"
                }`}
              >
                <input
                  type="radio"
                  name="rotationMode"
                  className="mt-1"
                  checked={state.rotationMode === value}
                  onChange={() => set("rotationMode", value)}
                />
                <span>
                  <span className="block text-[13.5px] font-semibold">{title}</span>
                  <span className={muted}>{help}</span>
                </span>
              </label>
            ))}
          </div>

          {state.rotationMode === "interval" ? (
            <div>
              <label className="field-label" htmlFor="rotationHours">
                Change every
              </label>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  id="rotationHours"
                  type="number"
                  min={1}
                  max={720}
                  className="field-input !w-24"
                  value={state.rotationHours}
                  onChange={(e) =>
                    set("rotationHours", Math.max(1, Math.min(720, Number(e.target.value) || 1)))
                  }
                />
                <span className="text-[13px]">hours</span>
                <span className="mx-1 h-5 w-px bg-ink-900/10 dark:bg-ink-50/15" />
                {HOUR_PRESETS.map((h) => (
                  <button
                    key={h}
                    type="button"
                    onClick={() => set("rotationHours", h)}
                    className={`rounded-full border px-3 py-1 text-[12px] font-medium ${
                      state.rotationHours === h
                        ? "border-accent-500 bg-accent-500/10"
                        : "border-ink-900/15 dark:border-ink-50/15"
                    }`}
                  >
                    {h}h
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-sm">
              <label className="field-label" htmlFor="timezone">
                Time zone for the switch times
              </label>
              <input
                id="timezone"
                list="tz-list"
                className="field-input"
                value={state.timezone}
                onChange={(e) => set("timezone", e.target.value)}
              />
              <datalist id="tz-list">
                {zones.map((z) => (
                  <option key={z} value={z} />
                ))}
              </datalist>
            </div>
          )}

          <div>
            <p className="field-label">Looks to rotate between</p>
            <ol className="flex flex-col gap-2.5">
              {state.slots.map((slot, i) => (
                <li
                  key={i}
                  className={`grid items-center gap-2.5 rounded-xl border p-3 sm:grid-cols-[120px_1fr_1fr_1fr_auto_auto] ${
                    preview.source === "rotation" && preview.slotIndex === i
                      ? "border-accent-500"
                      : "border-ink-900/10 dark:border-ink-50/10"
                  }`}
                >
                  <LookPreview skin={slot.skin} accent={slot.accent} mode={slot.mode} />
                  <label className="text-[12px]">
                    <span className="sr-only">Design</span>
                    <select
                      className="field-input"
                      value={slot.skin}
                      onChange={(e) =>
                        setSlot(i, {
                          skin: e.target.value as SkinId,
                          ...(e.target.value === "nexaweb" ? { mode: "dark" as ColorMode } : {}),
                        })
                      }
                    >
                      {SKINS.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="text-[12px]">
                    <span className="sr-only">Accent colour</span>
                    <select
                      className="field-input"
                      value={slot.accent}
                      onChange={(e) => setSlot(i, { accent: e.target.value as AccentId })}
                    >
                      {ACCENTS.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="text-[12px]">
                    <span className="sr-only">Light or dark</span>
                    <select
                      className="field-input"
                      value={slot.skin === "nexaweb" ? "dark" : slot.mode}
                      disabled={slot.skin === "nexaweb"}
                      onChange={(e) => setSlot(i, { mode: e.target.value as ColorMode })}
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                    </select>
                  </label>
                  {state.rotationMode === "schedule" ? (
                    <label className="flex items-center gap-1.5 text-[12px]">
                      <Clock size={14} aria-hidden="true" />
                      <span className="sr-only">Starts at</span>
                      <input
                        type="time"
                        className="field-input !w-[9rem]"
                        value={slot.at ?? ""}
                        onChange={(e) => setSlot(i, { at: e.target.value || undefined })}
                      />
                    </label>
                  ) : (
                    <span className={`${muted} whitespace-nowrap`}>Step {i + 1}</span>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      setState((s) => ({ ...s, slots: s.slots.filter((_, j) => j !== i) }))
                    }
                    className="justify-self-end rounded-full p-2 text-ink-400 hover:bg-red-500/10 hover:text-red-600"
                    aria-label={`Remove look ${i + 1}`}
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ol>
            <button
              type="button"
              disabled={state.slots.length >= 24}
              onClick={() =>
                setState((s) => ({
                  ...s,
                  slots: [
                    ...s.slots,
                    {
                      skin: s.skin,
                      accent: s.accent,
                      mode: s.mode,
                      ...(s.rotationMode === "schedule" ? { at: "12:00" } : {}),
                    },
                  ],
                }))
              }
              className="btn-secondary mt-3 !px-4 !py-2 text-[12.5px]"
            >
              <Plus size={14} /> Add look
            </button>
          </div>

          {state.rotationEnabled && (
            <p className="rounded-xl bg-accent-500/10 px-4 py-3 text-[13px]">
              With these settings the store would show <strong>{lookLabel(preview)}</strong> right
              now
              {preview.nextChangeAt ? `, changing next at ${formatWhen(preview.nextChangeAt)}` : ""}.
            </p>
          )}
        </fieldset>
      </section>

      <div className="sticky bottom-4 z-10 flex flex-wrap items-center justify-end gap-3">
        {message && (
          <p
            role={message.ok ? "status" : "alert"}
            className={`rounded-full px-4 py-2 text-[13px] ${
              message.ok ? "bg-emerald-600/15 text-emerald-700 dark:text-emerald-300" : "bg-red-600/15 text-red-700 dark:text-red-300"
            }`}
          >
            {message.text}
          </p>
        )}
        <button type="button" onClick={save} disabled={isPending} className="btn-primary">
          {isPending ? "Saving…" : "Save design settings"}
        </button>
      </div>
    </div>
  );
}
