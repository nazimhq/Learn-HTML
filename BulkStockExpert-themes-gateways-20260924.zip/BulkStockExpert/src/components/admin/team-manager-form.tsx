"use client";

import { useState, useTransition } from "react";
import { UserPlus, ShieldCheck, Shield, Ban, RotateCcw } from "lucide-react";
import {
  createAdminUser,
  setAdminSuperStatus,
  setAdminActive,
} from "@/app/actions/admin-team-actions";
import type { AdminAccount } from "@/app/actions/admin-team-actions";

function RoleBadge({ isSuperAdmin }: { isSuperAdmin: boolean }) {
  return isSuperAdmin ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-1 text-[11px] font-medium text-amber-700 dark:text-amber-400">
      <ShieldCheck size={12} /> Super Admin
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-ink-900/5 px-2.5 py-1 text-[11px] font-medium text-ink-600 dark:bg-ink-50/10 dark:text-ink-100/70">
      <Shield size={12} /> Admin
    </span>
  );
}

function AdminRow({
  admin,
  onChanged,
}: {
  admin: AdminAccount;
  onChanged: () => void;
}) {
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  function toggleSuper() {
    startTransition(async () => {
      const res = await setAdminSuperStatus(admin.id, !admin.isSuperAdmin);
      setMessage(res.ok ? "" : (res.message ?? "Something went wrong."));
      if (res.ok) onChanged();
    });
  }

  function toggleActive() {
    startTransition(async () => {
      const res = await setAdminActive(admin.id, !admin.isActive);
      setMessage(res.ok ? "" : (res.message ?? "Something went wrong."));
      if (res.ok) onChanged();
    });
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-900/10 p-4 dark:border-ink-50/10">
      <div className="min-w-0">
        <p className="truncate text-[13.5px] font-medium text-ink-900 dark:text-ink-50">
          {admin.name}
        </p>
        <p className="truncate text-[12px] text-ink-400 dark:text-ink-50/50">
          {admin.email}
        </p>
      </div>
      <div className="flex flex-shrink-0 items-center gap-2">
        <RoleBadge isSuperAdmin={admin.isSuperAdmin} />
        {!admin.isActive && (
          <span className="rounded-full bg-red-500/10 px-2.5 py-1 text-[11px] font-medium text-red-600 dark:text-red-400">
            Deactivated
          </span>
        )}
        <button
          disabled={isPending}
          onClick={toggleSuper}
          className="rounded-lg border border-ink-900/10 px-2.5 py-1.5 text-[11.5px] font-medium text-ink-600 hover:bg-ink-900/5 disabled:opacity-50 dark:border-ink-50/10 dark:text-ink-100/70 dark:hover:bg-ink-50/5"
        >
          {admin.isSuperAdmin ? "Make Admin" : "Make Super Admin"}
        </button>
        <button
          disabled={isPending}
          onClick={toggleActive}
          className="flex items-center gap-1 rounded-lg border border-ink-900/10 px-2.5 py-1.5 text-[11.5px] font-medium text-ink-600 hover:bg-ink-900/5 disabled:opacity-50 dark:border-ink-50/10 dark:text-ink-100/70 dark:hover:bg-ink-50/5"
        >
          {admin.isActive ? (
            <>
              <Ban size={12} /> Deactivate
            </>
          ) : (
            <>
              <RotateCcw size={12} /> Reactivate
            </>
          )}
        </button>
      </div>
      {message && (
        <p className="w-full text-[11.5px] text-red-600 dark:text-red-400">
          {message}
        </p>
      )}
    </div>
  );
}

export function TeamManagerForm({
  initialAdmins,
}: {
  initialAdmins: AdminAccount[];
}) {
  const admins = initialAdmins;
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  function refresh() {
    // Server actions revalidate the path; a full reload keeps this simple component in sync.
    window.location.reload();
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage("");
    startTransition(async () => {
      const res = await createAdminUser({
        name,
        email,
        password,
        isSuperAdmin,
      });
      if (!res.ok) {
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      setName("");
      setEmail("");
      setPassword("");
      setIsSuperAdmin(false);
      refresh();
    });
  }

  return (
    <div className="space-y-6">
      <form
        onSubmit={submit}
        className="space-y-3 rounded-xl border border-ink-900/10 p-4 dark:border-ink-50/10"
      >
        <p className="flex items-center gap-1.5 text-[13.5px] font-medium text-ink-900 dark:text-ink-50">
          <UserPlus size={15} /> Add an admin
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <input
            required
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="rounded-lg border border-ink-900/15 bg-transparent px-3 py-2 text-[13px] outline-none focus:border-ink-900/40 dark:border-ink-50/15"
          />
          <input
            required
            type="email"
            placeholder="Gmail address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded-lg border border-ink-900/15 bg-transparent px-3 py-2 text-[13px] outline-none focus:border-ink-900/40 dark:border-ink-50/15"
          />
        </div>
        <input
          required
          type="text"
          placeholder="Temporary password (min. 8 characters) — share it with them directly"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded-lg border border-ink-900/15 bg-transparent px-3 py-2 text-[13px] outline-none focus:border-ink-900/40 dark:border-ink-50/15"
        />
        <label className="flex items-center gap-2 text-[12.5px] text-ink-600 dark:text-ink-100/70">
          <input
            type="checkbox"
            checked={isSuperAdmin}
            onChange={(e) => setIsSuperAdmin(e.target.checked)}
          />
          Make this account a Super Admin (can manage other admins on this page)
        </label>
        {message && (
          <p className="text-[12px] text-red-600 dark:text-red-400">
            {message}
          </p>
        )}
        <button
          type="submit"
          disabled={isPending}
          className="rounded-lg bg-ink-900 px-4 py-2 text-[12.5px] font-medium text-ink-50 disabled:opacity-50 dark:bg-ink-50 dark:text-ink-900"
        >
          {isPending ? "Adding…" : "Add admin"}
        </button>
      </form>

      <div className="space-y-2">
        {admins.map((admin) => (
          <AdminRow key={admin.id} admin={admin} onChanged={refresh} />
        ))}
      </div>
    </div>
  );
}
