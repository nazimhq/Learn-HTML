"use client";

import { useState, useTransition } from "react";
import {
  updateOrderStatus,
  updateOrderTracking,
  updatePaymentStatus,
} from "@/app/actions/admin-order-actions";
import { ORDER_STATUS_LABEL } from "@/lib/constants";

const STATUSES = ["PENDING", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"];
const PAYMENT_STATUSES = ["PENDING", "PAID", "FAILED", "REFUNDED"];

export function OrderStatusControls({
  orderId,
  currentStatus,
  currentPaymentStatus,
  trackingCarrier,
  trackingNumber,
}: {
  orderId: string;
  currentStatus: string;
  currentPaymentStatus: string;
  trackingCarrier: string | null;
  trackingNumber: string | null;
}) {
  const [isPending, startTransition] = useTransition();
  const [status, setStatus] = useState(currentStatus);
  const [note, setNote] = useState("");
  const [carrier, setCarrier] = useState(trackingCarrier ?? "");
  const [tracking, setTracking] = useState(trackingNumber ?? "");
  const [message, setMessage] = useState("");

  function applyStatus() {
    startTransition(async () => {
      try {
        await updateOrderStatus(orderId, status, note);
      } catch (e) {
        setMessage(e instanceof Error ? e.message : "Unable to update status");
        return;
      }
      setNote("");
      setMessage(
        "Status saved. Email delivery depends on your mail configuration.",
      );
    });
  }

  function applyTracking() {
    if (!carrier || !tracking) return;
    startTransition(async () => {
      try {
        await updateOrderTracking(orderId, carrier, tracking);
      } catch {
        setMessage("Unable to save tracking.");
        return;
      }
      setMessage("Tracking details saved.");
    });
  }

  function applyPayment(next: string) {
    startTransition(async () => {
      try {
        await updatePaymentStatus(orderId, next);
      } catch {
        setMessage("Unable to save payment status.");
        return;
      }
      setMessage("Payment status updated.");
    });
  }

  return (
    <div className="flex flex-col gap-5">
      <div>
        <label className="field-label">Order status</label>
        <div className="flex flex-wrap gap-2">
          {STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`rounded-full border px-3.5 py-1.5 text-[12.5px] font-medium ${status === s ? "border-brand-500 bg-brand-50 text-brand-700" : "border-ink-900/15"}`}
            >
              {ORDER_STATUS_LABEL[s]}
            </button>
          ))}
        </div>
        <input
          className="field-input mt-2"
          placeholder="Optional note to include in the customer email"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        <button
          onClick={applyStatus}
          disabled={isPending || status === currentStatus}
          className="btn-primary mt-2 !px-4 !py-2 text-[12.5px]"
        >
          Update status &amp; notify customer
        </button>
      </div>

      <div>
        <label className="field-label">Tracking</label>
        <div className="flex gap-2">
          <input
            className="field-input"
            placeholder="Carrier (e.g. Royal Mail)"
            value={carrier}
            onChange={(e) => setCarrier(e.target.value)}
          />
          <input
            className="field-input"
            placeholder="Tracking number"
            value={tracking}
            onChange={(e) => setTracking(e.target.value)}
          />
        </div>
        <button
          onClick={applyTracking}
          disabled={isPending}
          className="btn-secondary mt-2 !px-4 !py-2 text-[12.5px]"
        >
          Save tracking
        </button>
      </div>

      <div>
        <label className="field-label">Payment status</label>
        <div className="flex flex-wrap gap-2">
          {PAYMENT_STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => applyPayment(s)}
              disabled={isPending}
              className={`rounded-full border px-3.5 py-1.5 text-[12.5px] font-medium ${currentPaymentStatus === s ? "border-brand-500 bg-brand-50 text-brand-700" : "border-ink-900/15"}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {message && <p className="text-[12.5px] text-emerald-700">{message}</p>}
    </div>
  );
}
