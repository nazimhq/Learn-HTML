"use client";

import { useState, useTransition } from "react";
import { Coins } from "lucide-react";
import { saveCurrencyRates } from "@/app/actions/currency-actions";

interface Row {
  code: string;
  countries: string;
  saved: string;
  updatedAt: string | null;
  envRate: number | null;
}

export function CurrencyRatesForm({ currencies, migrated }: { currencies: Row[]; migrated: boolean }) {
  const [values, setValues] = useState<Record<string, string>>(
    Object.fromEntries(currencies.map((c) => [c.code, c.saved])),
  );
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();

  return (
    <div className="max-w-4xl">
      <h1 className="flex items-center gap-2 font-display text-2xl">
        <Coins size={22} /> Currencies
      </h1>
      <p className="my-3 text-[13.5px] text-ink-400 dark:text-ink-50/60">
        Product and delivery prices are entered in GBP. Shoppers in other countries pay in their own
        currency, converted with the rates below. A country can&apos;t check out until its rate is set,
        so prices are never guessed.
      </p>
      {!migrated && (
        <p role="alert" className="mb-4 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-[13px]">
          Run <code className="font-mono">migration-themes-gateways.sql</code> to save rates here. Until
          then the FX_GBP_* environment variables are used.
        </p>
      )}
      <form
        className="rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel"
        onSubmit={(e) => {
          e.preventDefault();
          setMessage(null);
          start(async () => {
            const r = await saveCurrencyRates(values);
            setMessage({ ok: r.ok, text: r.message });
          });
        }}
      >
        <div className="table-wrap overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-[13px]">
            <thead className="text-[11.5px] uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              <tr>
                <th className="py-2 pr-3 font-semibold">Currency</th>
                <th className="py-2 pr-3 font-semibold">Countries</th>
                <th className="py-2 pr-3 font-semibold">1 GBP =</th>
                <th className="py-2 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-900/5 dark:divide-ink-50/10">
              {currencies.map((c) => {
                const active = values[c.code]?.trim() || c.envRate;
                return (
                  <tr key={c.code}>
                    <td className="py-2.5 pr-3 font-mono font-semibold">{c.code}</td>
                    <td className="py-2.5 pr-3">{c.countries}</td>
                    <td className="py-2.5 pr-3">
                      <label className="sr-only" htmlFor={`rate-${c.code}`}>
                        Rate for {c.code}
                      </label>
                      <input
                        id={`rate-${c.code}`}
                        inputMode="decimal"
                        className="field-input !w-36 font-mono"
                        placeholder={c.envRate ? `${c.envRate} (env)` : "Not set"}
                        value={values[c.code] ?? ""}
                        onChange={(e) => setValues((v) => ({ ...v, [c.code]: e.target.value }))}
                      />
                    </td>
                    <td className="py-2.5 text-[12.5px]">
                      {active ? (
                        <span className="rounded-full bg-emerald-600/10 px-2.5 py-1 text-emerald-700 dark:text-emerald-300">
                          Checkout open
                        </span>
                      ) : (
                        <span className="rounded-full bg-ink-900/5 px-2.5 py-1 text-ink-400 dark:bg-ink-50/10">
                          Needs a rate
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button className="btn-primary" disabled={pending}>
            {pending ? "Saving…" : "Save rates"}
          </button>
          {message && (
            <p role={message.ok ? "status" : "alert"} className="text-[13px]">
              {message.text}
            </p>
          )}
        </div>
      </form>
    </div>
  );
}
