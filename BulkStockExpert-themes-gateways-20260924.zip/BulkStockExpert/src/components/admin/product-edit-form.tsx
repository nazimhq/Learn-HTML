"use client";

import { useState, useTransition } from "react";
import {
  updateProduct,
  updateVariant,
} from "@/app/actions/admin-product-actions";

interface Variant {
  id: string;
  sku: string;
  label: string;
  price: string;
  compareAtPrice: string | null;
  costPrice: string | null;
  stock: number;
  lowStockAt: number;
}

export function ProductEditForm({
  productId,
  initial,
  variants,
}: {
  productId: string;
  initial: {
    name: string;
    description: string;
    basePrice: string;
    compareAtPrice: string | null;
    costPrice: string | null;
    status: string;
  };
  variants: Variant[];
}) {
  const [form, setForm] = useState(initial);
  const [rows, setRows] = useState(variants);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  function saveProduct() {
    startTransition(async () => {
      try {
      await updateProduct(productId, {
        name: form.name,
        description: form.description,
        basePrice: Number(form.basePrice),
        compareAtPrice: form.compareAtPrice
          ? Number(form.compareAtPrice)
          : null,
        costPrice: form.costPrice ? Number(form.costPrice) : null,
        status: form.status as "ACTIVE" | "DRAFT" | "ARCHIVED",
      });
      setMessage("Product details saved.");
      } catch {
        // Previously an error here crashed the whole page; show it instead.
        setMessage("Could not save the product details. Check the values and try again.");
      }
    });
  }

  function saveVariant(v: Variant) {
    startTransition(async () => {
      try {
      await updateVariant(v.id, {
        label: v.label,
        price: Number(v.price),
        compareAtPrice: v.compareAtPrice ? Number(v.compareAtPrice) : null,
        costPrice: v.costPrice ? Number(v.costPrice) : null,
        stock: v.stock,
        lowStockAt: v.lowStockAt,
      });
      setMessage(`"${v.label}" saved.`);
      } catch {
        setMessage(`Could not save "${v.label}". Check the values and try again.`);
      }
    });
  }

  function updateRow(id: string, field: keyof Variant, value: string | number) {
    setRows((rs) =>
      rs.map((r) => (r.id === id ? { ...r, [field]: value } : r)),
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {message && (
        <p className="rounded-lg bg-emerald-50 px-3.5 py-2 text-[12.5px] text-emerald-700">
          {message}
        </p>
      )}

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-4 font-display text-base">Product details</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="field-label">Name</label>
            <input
              className="field-input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="field-label">Description</label>
            <textarea
              className="field-input"
              rows={3}
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">Base price (£)</label>
            <input
              className="field-input"
              type="number"
              step="0.01"
              value={form.basePrice}
              onChange={(e) => setForm({ ...form, basePrice: e.target.value })}
            />
          </div>
          <div>
            <label className="field-label">
              Compare-at price (£, optional)
            </label>
            <input
              className="field-input"
              type="number"
              step="0.01"
              value={form.compareAtPrice ?? ""}
              onChange={(e) =>
                setForm({ ...form, compareAtPrice: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">Cost price (£, admin-only)</label>
            <input
              className="field-input"
              type="number"
              step="0.01"
              value={form.costPrice ?? ""}
              onChange={(e) => setForm({ ...form, costPrice: e.target.value })}
            />
          </div>
          <div>
            <label className="field-label">Status</label>
            <select
              className="field-input"
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
            >
              <option value="ACTIVE">Active</option>
              <option value="DRAFT">Draft</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </div>
        </div>
        <button
          onClick={saveProduct}
          disabled={isPending}
          className="btn-primary mt-4 !px-5 !py-2 text-[12.5px]"
        >
          Save product
        </button>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-4 font-display text-base">
          Variants, stock &amp; pricing
        </h2>
        <div className="flex flex-col gap-3">
          {rows.map((v) => (
            <div
              key={v.id}
              className="rounded-xl border border-ink-900/10 p-3.5"
            >
              <div className="grid gap-2 sm:grid-cols-3">
                <input
                  className="field-input"
                  value={v.label}
                  onChange={(e) => updateRow(v.id, "label", e.target.value)}
                  placeholder="Label"
                />
                <input
                  className="field-input font-mono text-[11px] text-ink-400 dark:text-ink-50/50"
                  value={v.sku}
                  disabled
                />
                <input
                  className="field-input"
                  type="number"
                  value={v.stock}
                  onChange={(e) =>
                    updateRow(v.id, "stock", Number(e.target.value))
                  }
                  placeholder="Stock"
                />
                <input
                  className="field-input"
                  type="number"
                  step="0.01"
                  value={v.price}
                  onChange={(e) => updateRow(v.id, "price", e.target.value)}
                  placeholder="Price (£)"
                />
                <input
                  className="field-input"
                  type="number"
                  step="0.01"
                  value={v.compareAtPrice ?? ""}
                  onChange={(e) =>
                    updateRow(v.id, "compareAtPrice", e.target.value)
                  }
                  placeholder="Compare-at (£)"
                />
                <input
                  className="field-input"
                  type="number"
                  step="0.01"
                  value={v.costPrice ?? ""}
                  onChange={(e) => updateRow(v.id, "costPrice", e.target.value)}
                  placeholder="Cost price (£)"
                />
              </div>
              <button
                onClick={() => saveVariant(v)}
                disabled={isPending}
                className="btn-secondary mt-2.5 !px-4 !py-1.5 text-[12px]"
              >
                Save variant
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
