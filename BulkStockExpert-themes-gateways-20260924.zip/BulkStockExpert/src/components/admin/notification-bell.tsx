"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Bell } from "lucide-react";
import {
  getNotifications,
  markAllNotificationsRead,
  type AdminNotification,
} from "@/app/actions/admin-notification-actions";

/** Polls for new-order alerts every 20s and shows them as a dropdown — the in-admin-panel
 *  half of order notifications (the other half is the email sent by sendAdminOrderAlertEmail). */
export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [recent, setRecent] = useState<AdminNotification[]>([]);
  const [ringing, setRinging] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const prevCountRef = useRef(0);

  async function refresh() {
    const res = await getNotifications();
    if (res.unreadCount > prevCountRef.current) {
      setRinging(true);
      window.setTimeout(() => setRinging(false), 650);
    }
    prevCountRef.current = res.unreadCount;
    setUnreadCount(res.unreadCount);
    setRecent(res.recent);
  }

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 20000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node))
        setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  async function handleOpen() {
    const next = !open;
    setOpen(next);
    if (next && unreadCount > 0) {
      await markAllNotificationsRead();
      setUnreadCount(0);
    }
  }

  return (
    <div ref={boxRef} className="relative">
      <button
        onClick={handleOpen}
        aria-label="Notifications"
        className="relative rounded-full p-2 text-ink-100/80 transition hover:bg-ink-50/10 hover:text-ink-50"
      >
        <Bell size={17} className={ringing ? "animate-bell-ring" : ""} />
        {unreadCount > 0 && (
          <span
            key={unreadCount}
            className="animate-badge-pop absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 font-mono text-[10px] font-bold text-white"
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="animate-pop-in absolute left-0 top-full z-50 mt-2 w-80 origin-top-left rounded-xl border border-ink-900/10 bg-white p-2 text-ink-900 shadow-xl dark:border-ink-50/10 dark:bg-panel dark:text-ink-50">
          <p className="px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Recent orders
          </p>
          <div className="max-h-80 overflow-y-auto">
            {recent.length === 0 ? (
              <p className="px-2 py-4 text-center text-[12.5px] text-ink-400 dark:text-ink-50/50">
                No notifications yet.
              </p>
            ) : (
              recent.map((n) => (
                <div
                  key={n.id}
                  className="rounded-lg px-2 py-2 text-[12.5px] hover:bg-ink-50 dark:hover:bg-ink-50/5"
                >
                  <p className="leading-snug">{n.message}</p>
                  <p className="mt-0.5 text-[11px] text-ink-400 dark:text-ink-50/50">
                    {new Date(n.createdAt).toLocaleString("en-GB")}
                  </p>
                </div>
              ))
            )}
          </div>
          <Link
            href="/admin/orders"
            onClick={() => setOpen(false)}
            className="mt-1 block rounded-lg px-2 py-2 text-center text-[12.5px] font-semibold text-brand-600 hover:bg-ink-50 dark:hover:bg-ink-50/5"
          >
            View all orders →
          </Link>
        </div>
      )}
    </div>
  );
}
