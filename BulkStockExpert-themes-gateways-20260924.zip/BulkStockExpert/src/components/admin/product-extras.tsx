"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ArrowDown, ArrowUp, ImagePlus, Plus, Trash2 } from "lucide-react";
import { uploadImage } from "@/app/actions/upload-actions";
import {
  addProductImage,
  addVariant,
  deleteProduct,
  deleteVariant,
  moveProductImage,
  removeProductImage,
  setProductCategory,
} from "@/app/actions/admin-product-extra-actions";

interface Props {
  productId: string;
  productSlug: string;
  categoryId: string;
  categories: { id: string; name: string }[];
  images: { id: string; url: string; altText: string }[];
  variants: { id: string; label: string; sku: string; stock: number }[];
}

/** Photos, category, adding/removing options and deleting — added alongside the original edit form. */
export function ProductExtras({ productId, productSlug, categoryId, categories, images, variants }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [category, setCategory] = useState(categoryId);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [nv, setNv] = useState({ label: "", sku: `${productSlug}-${variants.length + 1}`.toUpperCase().slice(0, 60), price: "", stock: "0" });

  const run = (fn: () => Promise<{ ok: boolean; message: string }>) =>
    start(async () => {
      try {
        const r = await fn();
        if (r.message) setMessage({ ok: r.ok, text: r.message });
        if (r.ok) router.refresh();
      } catch {
        setMessage({ ok: false, text: "Something went wrong. Please try again." });
      }
    });

  async function onFiles(files: FileList) {
    setUploading(true);
    setMessage(null);
    for (const file of Array.from(files)) {
      const fd = new FormData();
      fd.append("file", file);
      const up = await uploadImage(fd, "products");
      if (!up.ok || !up.url) {
        setMessage({ ok: false, text: up.message ?? "Upload failed." });
        continue;
      }
      const r = await addProductImage(productId, up.url);
      if (!r.ok) setMessage({ ok: false, text: r.message });
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
    router.refresh();
  }

  const card = "rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel";

  return (
    <div className="mt-6 flex flex-col gap-6">
      {message && (
        <p role={message.ok ? "status" : "alert"} className={`rounded-lg px-3.5 py-2 text-[12.5px] ${message.ok ? "bg-emerald-600/10 text-emerald-700 dark:text-emerald-300" : "bg-red-600/10 text-red-700 dark:text-red-300"}`}>
          {message.text}
        </p>
      )}

      <section className={card}>
        <h2 className="mb-1 font-display text-base">Photos</h2>
        <p className="mb-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">The first photo is the main one on the shop. JPG, PNG, WEBP or GIF up to 5 MB.</p>
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {images.map((img, i) => (
            <li key={img.id} className="overflow-hidden rounded-xl border border-ink-900/10 dark:border-ink-50/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={img.url} alt={img.altText || `Photo ${i + 1}`} className="aspect-square w-full object-cover" />
              <div className="flex items-center justify-between px-2 py-1.5 text-[11.5px]">
                <span>{i === 0 ? "Main" : `#${i + 1}`}</span>
                <span className="flex gap-0.5">
                  <button type="button" disabled={pending || i === 0} onClick={() => run(() => moveProductImage(img.id, -1))} className="rounded p-1 hover:bg-ink-900/5 disabled:opacity-30 dark:hover:bg-ink-50/10" aria-label="Move earlier"><ArrowUp size={13} /></button>
                  <button type="button" disabled={pending || i === images.length - 1} onClick={() => run(() => moveProductImage(img.id, 1))} className="rounded p-1 hover:bg-ink-900/5 disabled:opacity-30 dark:hover:bg-ink-50/10" aria-label="Move later"><ArrowDown size={13} /></button>
                  <button type="button" disabled={pending} onClick={() => run(() => removeProductImage(img.id))} className="rounded p-1 text-red-600 hover:bg-red-500/10" aria-label="Remove photo"><Trash2 size={13} /></button>
                </span>
              </div>
            </li>
          ))}
          <li>
            <label className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-ink-900/15 text-[12px] text-ink-400 hover:border-accent-500 dark:border-ink-50/20">
              <ImagePlus size={20} />
              {uploading ? "Uploading…" : "Add photos"}
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple className="sr-only" disabled={uploading} onChange={(e) => e.target.files?.length && onFiles(e.target.files)} />
            </label>
          </li>
        </ul>
      </section>

      <section className={card}>
        <h2 className="mb-3 font-display text-base">Category</h2>
        <div className="flex flex-wrap gap-2">
          <label className="sr-only" htmlFor="product-category">Category</label>
          <select id="product-category" className="field-input !w-64" value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button type="button" className="btn-secondary !px-4 !py-2" disabled={pending || category === categoryId} onClick={() => run(() => setProductCategory(productId, category))}>Save category</button>
        </div>
      </section>

      <section className={card}>
        <h2 className="mb-1 font-display text-base">Options (variants)</h2>
        <p className="mb-3 text-[12.5px] text-ink-400 dark:text-ink-50/50">Edit prices and stock above. Add a new size, colour or pack here, or remove one you no longer sell.</p>
        <ul className="mb-4 divide-y divide-ink-900/5 text-[13px] dark:divide-ink-50/10">
          {variants.map((v) => (
            <li key={v.id} className="flex items-center justify-between gap-3 py-2">
              <span><strong>{v.label}</strong> <span className="font-mono text-[11.5px] text-ink-400">{v.sku}</span> · {v.stock} in stock</span>
              <button type="button" disabled={pending || variants.length <= 1} onClick={() => confirm(`Remove option "${v.label}"?`) && run(() => deleteVariant(v.id))} className="rounded-full p-1.5 text-red-600 hover:bg-red-500/10 disabled:opacity-30" aria-label={`Remove ${v.label}`}><Trash2 size={14} /></button>
            </li>
          ))}
        </ul>
        <form
          className="grid gap-2 sm:grid-cols-[1.4fr_1fr_0.8fr_0.7fr_auto] sm:items-end"
          onSubmit={(e) => {
            e.preventDefault();
            run(async () => {
              const r = await addVariant(productId, { label: nv.label, sku: nv.sku, price: Number(nv.price), stock: Number(nv.stock), lowStockAt: 5 });
              if (r.ok) setNv({ label: "", sku: `${productSlug}-${variants.length + 2}`.toUpperCase().slice(0, 60), price: "", stock: "0" });
              return r;
            });
          }}
        >
          <label className="text-[12px]">Option name<input className="field-input mt-1" value={nv.label} onChange={(e) => setNv({ ...nv, label: e.target.value })} placeholder="Black / Large" required /></label>
          <label className="text-[12px]">SKU<input className="field-input mt-1 font-mono uppercase" value={nv.sku} onChange={(e) => setNv({ ...nv, sku: e.target.value })} required /></label>
          <label className="text-[12px]">Price (£)<input className="field-input mt-1" inputMode="decimal" value={nv.price} onChange={(e) => setNv({ ...nv, price: e.target.value })} required /></label>
          <label className="text-[12px]">Stock<input className="field-input mt-1" type="number" min={0} value={nv.stock} onChange={(e) => setNv({ ...nv, stock: e.target.value })} /></label>
          <button className="btn-primary !px-4 !py-2.5" disabled={pending}><Plus size={14} /> Add</button>
        </form>
      </section>

      <section className={`${card} border-red-500/30`}>
        <h2 className="mb-1 font-display text-base text-red-700 dark:text-red-300">Delete product</h2>
        <p className="mb-3 text-[12.5px] text-ink-400 dark:text-ink-50/50">Products that appear on past orders are archived (hidden from the shop) instead, so order history stays intact.</p>
        <button
          type="button"
          disabled={pending}
          className="rounded-full border border-red-500/40 px-4 py-2 text-[12.5px] font-semibold text-red-700 hover:bg-red-500/10 dark:text-red-300"
          onClick={() => {
            if (!confirm("Delete this product? This cannot be undone.")) return;
            start(async () => {
              const r = await deleteProduct(productId);
              setMessage({ ok: r.ok, text: r.message });
              if (r.ok && r.message === "Product deleted.") router.push("/admin/products");
              else router.refresh();
            });
          }}
        >
          Delete product
        </button>
      </section>
    </div>
  );
}
