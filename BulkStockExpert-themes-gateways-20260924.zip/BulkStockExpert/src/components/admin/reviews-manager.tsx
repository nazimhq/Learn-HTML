"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { Star, Pencil, Trash2, Check, EyeOff, X } from "lucide-react";
import {
  type AdminReviewRow,
  updateReview,
  setReviewStatus,
  deleteReview,
} from "@/app/actions/admin-review-actions";

const STATUS_STYLES: Record<string, string> = {
  APPROVED: "bg-emerald-100 text-emerald-700",
  PENDING: "bg-amber-100 text-amber-700",
  REJECTED: "bg-red-100 text-red-700",
};

function StatusPill({ status }: { status: string }) {
  return (
    <span
      className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${STATUS_STYLES[status] ?? ""}`}
    >
      {status}
    </span>
  );
}

function StarInput({
  value,
  onChange,
}: {
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          type="button"
          key={n}
          onClick={() => onChange(n)}
          aria-label={`${n} star`}
        >
          <Star
            size={16}
            className={
              n <= value ? "fill-accent-500 text-accent-500" : "text-ink-100"
            }
          />
        </button>
      ))}
    </div>
  );
}

function EditRow({
  review,
  onDone,
}: {
  review: AdminReviewRow;
  onDone: (patch: Partial<AdminReviewRow> | null, message?: string) => void;
}) {
  const [name, setName] = useState(review.customerName);
  const [rating, setRating] = useState(review.rating);
  const [comment, setComment] = useState(review.comment);
  const [isPending, startTransition] = useTransition();

  function save() {
    startTransition(async () => {
      const res = await updateReview(review.id, {
        customerName: name,
        rating,
        comment,
      });
      if (res.ok) {
        onDone({ customerName: name, rating, comment }, "Review updated.");
      } else {
        onDone(null, res.message);
      }
    });
  }

  return (
    <div className="flex flex-col gap-2.5 rounded-xl border border-brand-500/30 bg-brand-50/40 p-4 dark:bg-brand-900/10">
      <div className="grid gap-2.5 sm:grid-cols-2">
        <div>
          <label className="field-label">Reviewer name</label>
          <input
            className="field-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <label className="field-label">Rating</label>
          <StarInput value={rating} onChange={setRating} />
        </div>
      </div>
      <div>
        <label className="field-label">Review text</label>
        <textarea
          className="field-input resize-y"
          rows={3}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
      </div>
      <div className="flex gap-2">
        <button
          onClick={save}
          disabled={isPending}
          className="btn-primary !px-4 !py-1.5 text-[12px]"
        >
          <Check size={13} /> Save
        </button>
        <button
          onClick={() => onDone(null)}
          disabled={isPending}
          className="btn-secondary !px-4 !py-1.5 text-[12px]"
        >
          <X size={13} /> Cancel
        </button>
      </div>
    </div>
  );
}

export function ReviewsManager({
  initialReviews,
}: {
  initialReviews: AdminReviewRow[];
}) {
  const [reviews, setReviews] = useState(initialReviews);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<
    "ALL" | "PENDING" | "APPROVED" | "REJECTED"
  >("ALL");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  const visible =
    filter === "ALL" ? reviews : reviews.filter((r) => r.status === filter);

  function refreshLocal(id: string, patch: Partial<AdminReviewRow>) {
    setReviews((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function toggleStatus(
    review: AdminReviewRow,
    status: "PENDING" | "APPROVED" | "REJECTED",
  ) {
    startTransition(async () => {
      const res = await setReviewStatus(review.id, status);
      if (res.ok) {
        refreshLocal(review.id, { status });
        setMessage(
          `Review ${status === "APPROVED" ? "approved" : status === "REJECTED" ? "rejected" : "unpublished"}.`,
        );
      } else {
        setMessage(res.message ?? "Something went wrong.");
      }
    });
  }

  function remove(review: AdminReviewRow) {
    startTransition(async () => {
      const res = await deleteReview(review.id);
      if (res.ok) {
        setReviews((rs) => rs.filter((r) => r.id !== review.id));
        setMessage("Review deleted.");
      } else {
        setMessage(res.message ?? "Something went wrong.");
      }
    });
  }

  return (
    <div className="flex flex-col gap-4">
      {message && (
        <p className="rounded-lg bg-emerald-50 px-3.5 py-2 text-[12.5px] text-emerald-700">
          {message}
        </p>
      )}

      <div className="flex flex-wrap gap-2">
        {(["ALL", "APPROVED", "PENDING", "REJECTED"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full border px-3.5 py-1.5 text-[12.5px] font-medium ${
              filter === f
                ? "border-brand-500 bg-brand-50 text-brand-700"
                : "border-ink-900/15 dark:border-ink-50/15"
            }`}
          >
            {f === "ALL" ? "All" : f.charAt(0) + f.slice(1).toLowerCase()} (
            {f === "ALL"
              ? reviews.length
              : reviews.filter((r) => r.status === f).length}
            )
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3">
        {visible.length === 0 && (
          <p className="rounded-2xl border border-dashed border-ink-900/15 p-8 text-center text-[13px] text-ink-400 dark:border-ink-50/15 dark:text-ink-50/50">
            No reviews here.
          </p>
        )}
        {visible.map((r) =>
          editingId === r.id ? (
            <EditRow
              key={r.id}
              review={r}
              onDone={(patch, msg) => {
                setEditingId(null);
                if (msg) setMessage(msg);
                if (patch) refreshLocal(r.id, patch);
              }}
            />
          ) : (
            <div
              key={r.id}
              className="rounded-2xl border border-ink-900/10 bg-white p-4 dark:border-ink-50/10 dark:bg-panel"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] font-semibold">
                      {r.customerName}
                    </span>
                    <StatusPill status={r.status} />
                  </div>
                  <Link
                    href={`/products/${r.productSlug}`}
                    target="_blank"
                    className="text-[11.5px] text-brand-600 hover:underline"
                  >
                    {r.productName}
                  </Link>
                  <div className="mt-1 flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={13}
                        className={
                          i < r.rating
                            ? "fill-accent-500 text-accent-500"
                            : "text-ink-100"
                        }
                      />
                    ))}
                  </div>
                </div>
                <span className="text-[11px] text-ink-400 dark:text-ink-50/50">
                  {new Date(r.createdAt).toLocaleString("en-GB")}
                </span>
              </div>
              <p className="mt-2.5 text-[13px] leading-relaxed text-ink-600 dark:text-ink-50/65">
                {r.comment}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  onClick={() => setEditingId(r.id)}
                  className="btn-secondary !px-3.5 !py-1.5 text-[11.5px]"
                >
                  <Pencil size={13} /> Edit
                </button>
                {r.status !== "APPROVED" && (
                  <button
                    onClick={() => toggleStatus(r, "APPROVED")}
                    disabled={isPending}
                    className="btn-secondary !px-3.5 !py-1.5 text-[11.5px] !text-emerald-700"
                  >
                    <Check size={13} /> Approve
                  </button>
                )}
                {r.status !== "REJECTED" && r.status !== "PENDING" && (
                  <button
                    onClick={() => toggleStatus(r, "PENDING")}
                    disabled={isPending}
                    className="btn-secondary !px-3.5 !py-1.5 text-[11.5px]"
                  >
                    <EyeOff size={13} /> Unpublish
                  </button>
                )}
                <button
                  onClick={() => remove(r)}
                  disabled={isPending}
                  className="rounded-full border border-red-200 px-3.5 py-1.5 text-[11.5px] font-semibold text-red-600 hover:bg-red-50"
                >
                  <Trash2 size={13} className="inline" /> Delete
                </button>
              </div>
            </div>
          ),
        )}
      </div>
    </div>
  );
}
