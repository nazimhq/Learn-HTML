"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, X, Plus } from "lucide-react";
import { createProduct } from "@/app/actions/admin-product-actions";
import { uploadImage } from "@/app/actions/upload-actions";

interface Category {
  id: string;
  name: string;
}

const EMPTY_FORM = {
  name: "",
  slug: "",
  description: "",
  categoryId: "",
  brandName: "",
  basePrice: "",
  compareAtPrice: "",
  costPrice: "",
  status: "ACTIVE" as "ACTIVE" | "DRAFT" | "ARCHIVED",
  stock: "10",
  lowStockAt: "5",
};

export function ProductCreateForm({ categories }: { categories: Category[] }) {
  const router = useRouter();
  const [form, setForm] = useState(EMPTY_FORM);
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleFiles(files: FileList) {
    setUploading(true);
    setError("");
    const uploaded: string[] = [];
    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append("file", file);
      const result = await uploadImage(formData, "products");
      if (result.ok && result.url) {
        uploaded.push(result.url);
      } else {
        setError(result.message ?? "One of those images failed to upload.");
      }
    }
    setImages((imgs) => [...imgs, ...uploaded]);
    setUploading(false);
  }

  function removeImage(url: string) {
    setImages((imgs) => imgs.filter((i) => i !== url));
  }

  function submit() {
    setError("");
    setMessage("");
    if (!form.name.trim()) return setError("Enter a product name.");
    if (!form.categoryId) return setError("Choose a category.");
    if (!form.basePrice || Number(form.basePrice) <= 0)
      return setError("Enter a valid price.");

    startTransition(async () => {
      const res = await createProduct({
        name: form.name,
        slug: form.slug || undefined,
        description: form.description,
        categoryId: form.categoryId,
        brandName: form.brandName || undefined,
        basePrice: Number(form.basePrice),
        compareAtPrice: form.compareAtPrice
          ? Number(form.compareAtPrice)
          : null,
        costPrice: form.costPrice ? Number(form.costPrice) : null,
        status: form.status,
        stock: Number(form.stock) || 0,
        lowStockAt: Number(form.lowStockAt) || 5,
        imageUrls: images,
      });
      if (!res.ok) {
        setError(res.message ?? "Something went wrong — please try again.");
        return;
      }
      setMessage("Product created.");
      router.push(`/admin/products/${res.productId}`);
    });
  }

  return (
    <div className="max-w-3xl rounded-2xl border border-ink-900/10 bg-panel p-5 dark:border-ink-50/10">
      {error && (
        <p className="mb-4 rounded-lg bg-discount/10 px-3.5 py-2 text-[12.5px] text-discount">
          {error}
        </p>
      )}
      {message && (
        <p className="mb-4 rounded-lg bg-success/10 px-3.5 py-2 text-[12.5px] text-success">
          {message}
        </p>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="field-label">Product name</label>
          <input
            className="field-input"
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            placeholder="e.g. Mixed Electronics Returns Pallet (1.2m)"
          />
        </div>
        <div>
          <label className="field-label">
            Slug (optional — auto from name)
          </label>
          <input
            className="field-input"
            value={form.slug}
            onChange={(e) => set("slug", e.target.value)}
            placeholder="mixed-electronics-pallet"
          />
        </div>
        <div>
          <label className="field-label">Category</label>
          <select
            className="field-input"
            value={form.categoryId}
            onChange={(e) => set("categoryId", e.target.value)}
          >
            <option value="">Choose a category…</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="field-label">Description</label>
          <textarea
            className="field-input min-h-[90px]"
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            placeholder="Manifest summary, condition notes, what's included…"
          />
        </div>
        <div>
          <label className="field-label">Brand (optional)</label>
          <input
            className="field-input"
            value={form.brandName}
            onChange={(e) => set("brandName", e.target.value)}
            placeholder="e.g. Generic / Mixed"
          />
        </div>
        <div>
          <label className="field-label">Status</label>
          <select
            className="field-input"
            value={form.status}
            onChange={(e) =>
              set("status", e.target.value as typeof form.status)
            }
          >
            <option value="ACTIVE">Active — visible in store</option>
            <option value="DRAFT">Draft — hidden</option>
            <option value="ARCHIVED">Archived</option>
          </select>
        </div>
        <div>
          <label className="field-label">Sale price (£)</label>
          <input
            className="field-input"
            type="number"
            step="0.01"
            value={form.basePrice}
            onChange={(e) => set("basePrice", e.target.value)}
            placeholder="249.00"
          />
        </div>
        <div>
          <label className="field-label">Compare-at price (optional)</label>
          <input
            className="field-input"
            type="number"
            step="0.01"
            value={form.compareAtPrice}
            onChange={(e) => set("compareAtPrice", e.target.value)}
            placeholder="349.00"
          />
        </div>
        <div>
          <label className="field-label">
            Cost price (optional, admin-only)
          </label>
          <input
            className="field-input"
            type="number"
            step="0.01"
            value={form.costPrice}
            onChange={(e) => set("costPrice", e.target.value)}
            placeholder="140.00"
          />
        </div>
        <div>
          <label className="field-label">Starting stock</label>
          <input
            className="field-input"
            type="number"
            value={form.stock}
            onChange={(e) => set("stock", e.target.value)}
          />
        </div>
        <div>
          <label className="field-label">Low-stock alert at</label>
          <input
            className="field-input"
            type="number"
            value={form.lowStockAt}
            onChange={(e) => set("lowStockAt", e.target.value)}
          />
        </div>
      </div>

      <div className="mt-5">
        <label className="field-label">Photos</label>
        <div className="flex flex-wrap gap-3">
          {images.map((url) => (
            <div
              key={url}
              className="group relative h-24 w-24 overflow-hidden rounded-lg border border-ink-900/10 dark:border-ink-50/10"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => removeImage(url)}
                className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-ink-900/70 text-white opacity-0 transition group-hover:opacity-100"
              >
                <X size={12} />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="flex h-24 w-24 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-ink-900/20 text-ink-400 transition hover:border-cta hover:text-cta dark:border-ink-50/20 dark:text-ink-50/50"
          >
            <ImagePlus size={18} />
            <span className="text-[10.5px] font-semibold">
              {uploading ? "Uploading…" : "Add photos"}
            </span>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.length) handleFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </div>
        <p className="mt-1.5 text-[11.5px] text-ink-400 dark:text-ink-50/50">
          JPG, PNG, WEBP or GIF, up to 5MB each. The first photo becomes the
          main listing image.
        </p>
      </div>

      <button
        onClick={submit}
        disabled={isPending}
        className="btn-primary mt-6"
      >
        <Plus size={15} /> {isPending ? "Creating…" : "Create product"}
      </button>
    </div>
  );
}
