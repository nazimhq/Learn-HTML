"use client";

import { REGION_CODES } from "@/lib/gateway-catalog";

import { useRef, useState, useTransition } from "react";
import { Trash2, Plus, ImagePlus } from "lucide-react";
import {
  updateSiteSettings,
  updateTrackingSettings,
  updateThemeSettings,
  updatePaymentSettings,
  updateBrandingSettings,
  upsertDeliveryZone,
  deleteDeliveryZone,
} from "@/app/actions/admin-settings-actions";
import { uploadImage } from "@/app/actions/upload-actions";
import { formatMoney } from "@/lib/constants";

interface Settings {
  siteName: string;
  tagline: string;
  contactEmail: string;
  contactPhone: string;
  adminNotificationEmail: string;
  vatRate: string;
  pricesIncludeVat: boolean;
  freeShippingOverAmount: string | null;
}

interface Tracking {
  metaPixelId: string;
  gaMeasurementId: string;
  gtmContainerId: string;
  whatsappNumber: string;
}

interface ThemeSettings {
  accentTheme: "red" | "maroon" | "gold" | "yellow" | "black" | "purple";
  colorMode: "light" | "dark";
}

const ACCENT_SWATCHES: {
  value: ThemeSettings["accentTheme"];
  label: string;
  swatch: string;
}[] = [
  { value: "red", label: "Bright Red", swatch: "#c8382d" },
  { value: "gold", label: "Deep Gold", swatch: "#a87d28" },
  { value: "maroon", label: "Deep / Burgundy Red", swatch: "#7a1e26" },
  { value: "yellow", label: "Warm Yellow", swatch: "#d6a50a" },
  { value: "black", label: "Black / Charcoal", swatch: "#171310" },
  { value: "purple", label: "Electric Purple", swatch: "#8b5cf6" },
];

interface PaymentSettings {
  codEnabled: boolean;
  cardEnabled: boolean;
  stripePublishableKey: string;
  stripeSecretKey: string;
  stripeWebhookSecret: string;
  paypalEnabled: boolean;
  paypalClientId: string;
  paypalClientSecret: string;
  paypalMode: "sandbox" | "live";
}

interface Branding {
  logoUrl: string | null;
  facebookUrl: string;
  instagramUrl: string;
  tiktokUrl: string;
}

interface Zone {
  countryCode?: string;
  id: string;
  name: string;
  description: string;
  charge: string;
  freeOverAmount: string | null;
  postcodePrefixes: string[];
  estimatedDays: string;
  isActive: boolean;
}

const emptyZone: Omit<Zone, "id"> = {
  name: "",
  description: "",
  charge: "0",
  freeOverAmount: null,
  postcodePrefixes: [],
  estimatedDays: "2-4 working days",
  isActive: true,
};

export function SettingsForm({
  initialSettings,
  initialTracking,
  initialTheme,
  initialZones,
  initialPayments,
  initialBranding,
}: {
  initialSettings: Settings;
  initialTracking: Tracking;
  initialTheme: ThemeSettings;
  initialZones: Zone[];
  initialPayments: PaymentSettings;
  initialBranding: Branding;
}) {
  const [settings, setSettings] = useState(initialSettings);
  const [tracking, setTracking] = useState(initialTracking);
  const [theme, setTheme] = useState(initialTheme);
  const [zones, setZones] = useState(initialZones);
  const [payments, setPayments] = useState(initialPayments);
  const [branding, setBranding] = useState(initialBranding);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [newZone, setNewZone] = useState<Omit<Zone, "id">>(emptyZone);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  async function handleLogoFile(file: File) {
    setUploadingLogo(true);
    const formData = new FormData();
    formData.append("file", file);
    const result = await uploadImage(formData, "branding");
    setUploadingLogo(false);
    if (!result.ok || !result.url) {
      setMessage(result.message ?? "Logo upload failed.");
      return;
    }
    const next = { ...branding, logoUrl: result.url };
    setBranding(next);
    startTransition(async () => {
      await updateBrandingSettings(next);
      setMessage("Logo saved.");
    });
  }

  function saveBranding() {
    startTransition(async () => {
      const res = await updateBrandingSettings(branding);
      setMessage(
        res.ok ? "Branding saved." : (res.message ?? "Something went wrong."),
      );
    });
  }

  function saveTracking() {
    startTransition(async () => {
      const res = await updateTrackingSettings({
        metaPixelId: tracking.metaPixelId || null,
        gaMeasurementId: tracking.gaMeasurementId || null,
        gtmContainerId: tracking.gtmContainerId || null,
        whatsappNumber: tracking.whatsappNumber || null,
      });
      if (!res.ok) {
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      setMessage(
        tracking.metaPixelId || tracking.gaMeasurementId
          ? "Tracking saved — Pixel/GA4 now fire on every storefront page."
          : "Tracking settings saved.",
      );
    });
  }

  function saveTheme(next: ThemeSettings) {
    const previous = theme;
    setTheme(next);
    startTransition(async () => {
      const res = await updateThemeSettings(next);
      if (!res.ok) {
        setTheme(previous);
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      document.documentElement.dataset.accent = next.accentTheme;
      document.documentElement.dataset.mode = next.colorMode;
      localStorage.removeItem("bse-theme-mode");
      localStorage.setItem("bse-admin-theme", JSON.stringify(next));
      setMessage(
        "Theme saved and applied. Other storefront tabs update automatically.",
      );
    });
  }

  function savePayments() {
    startTransition(async () => {
      const res = await updatePaymentSettings({
        codEnabled: payments.codEnabled,
        cardEnabled: payments.cardEnabled,
        stripePublishableKey: payments.stripePublishableKey || null,
        stripeSecretKey: payments.stripeSecretKey || null,
        stripeWebhookSecret: payments.stripeWebhookSecret || null,
        paypalEnabled: payments.paypalEnabled,
        paypalClientId: payments.paypalClientId || null,
        paypalClientSecret: payments.paypalClientSecret || null,
        paypalMode: payments.paypalMode,
      });
      setMessage(
        res.ok
          ? "Payment settings saved."
          : (res.message ?? "Something went wrong."),
      );
    });
  }

  function saveSettings() {
    startTransition(async () => {
      const res = await updateSiteSettings({
        siteName: settings.siteName,
        tagline: settings.tagline,
        contactEmail: settings.contactEmail,
        contactPhone: settings.contactPhone,
        adminNotificationEmail: settings.adminNotificationEmail,
        vatRate: Number(settings.vatRate),
        pricesIncludeVat: settings.pricesIncludeVat,
        freeShippingOverAmount: settings.freeShippingOverAmount
          ? Number(settings.freeShippingOverAmount)
          : null,
      });
      setMessage(
        res.ok
          ? "Site settings saved."
          : (res.message ?? "Something went wrong."),
      );
    });
  }

  function saveZone(zone: Zone | Omit<Zone, "id">) {
    startTransition(async () => {
      const res = await upsertDeliveryZone({
        id: "id" in zone ? zone.id : undefined,
        name: zone.name,
        countryCode: zone.countryCode ?? "GB",
        description: zone.description,
        charge: Number(zone.charge),
        freeOverAmount: zone.freeOverAmount
          ? Number(zone.freeOverAmount)
          : null,
        postcodePrefixes: zone.postcodePrefixes,
        estimatedDays: zone.estimatedDays,
        isActive: zone.isActive,
      });
      if (!res.ok) {
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      setMessage("Delivery zone saved.");
      if (!("id" in zone)) setNewZone(emptyZone);
    });
  }

  function removeZone(id: string) {
    startTransition(async () => {
      const res = await deleteDeliveryZone(id);
      if (!res.ok) {
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      setZones((z) => z.filter((x) => x.id !== id));
      setMessage("Delivery zone removed.");
    });
  }

  function updateZoneField(
    id: string,
    field: keyof Zone,
    value: string | boolean | string[],
  ) {
    setZones((zs) =>
      zs.map((z) => (z.id === id ? { ...z, [field]: value } : z)),
    );
  }

  return (
    <div className="flex flex-col gap-8">
      {message && (
        <p className="rounded-lg bg-emerald-50 px-3.5 py-2 text-[12.5px] text-emerald-700">
          {message}
        </p>
      )}

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-1 font-display text-base">Theme</h2>
        <p className="mb-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Pick the accent colour used for buttons, badges and highlights across
          the storefront, and whether new visitors see the site in light or dark
          mode by default (anyone can still flip it themselves — see the
          sun/moon icon in the header).
        </p>

        <p className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Accent colour
        </p>
        <div className="mb-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {ACCENT_SWATCHES.map((a) => (
            <button
              key={a.value}
              type="button"
              onClick={() => saveTheme({ ...theme, accentTheme: a.value })}
              disabled={isPending}
              className={`flex items-center gap-2.5 rounded-xl border-2 px-3 py-2.5 text-left text-[12.5px] font-medium transition ${
                theme.accentTheme === a.value
                  ? "border-brand-500 bg-brand-50 dark:bg-brand-900/30"
                  : "border-ink-900/10 hover:border-ink-900/25 dark:border-ink-50/10 dark:hover:border-ink-50/30"
              }`}
            >
              <span
                className="h-6 w-6 flex-shrink-0 rounded-full border border-black/10"
                style={{ backgroundColor: a.swatch }}
              />
              {a.label}
            </button>
          ))}
        </div>

        <p className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Default appearance
        </p>
        <div className="flex gap-2.5">
          {(["light", "dark"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => saveTheme({ ...theme, colorMode: m })}
              disabled={isPending}
              className={`rounded-full border-2 px-4 py-1.5 text-[12.5px] font-medium capitalize transition ${
                theme.colorMode === m
                  ? "border-brand-500 bg-brand-50 dark:bg-brand-900/30"
                  : "border-ink-900/10 hover:border-ink-900/25 dark:border-ink-50/10 dark:hover:border-ink-50/30"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-1 font-display text-base">Branding</h2>
        <p className="mb-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Upload a logo to replace the text site name in the header, and link
          your social profiles (shown as icons in the footer).
        </p>
        <div className="mb-5 flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-lg border border-dashed border-ink-900/20 bg-ink-900/5 dark:border-ink-50/20">
            {branding.logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={branding.logoUrl}
                alt="Logo"
                className="h-full w-full object-contain"
              />
            ) : (
              <ImagePlus
                size={18}
                className="text-ink-400 dark:text-ink-50/40"
              />
            )}
          </div>
          <div>
            <button
              type="button"
              onClick={() => logoInputRef.current?.click()}
              disabled={uploadingLogo}
              className="btn-secondary !px-4 !py-1.5 text-[12.5px]"
            >
              {uploadingLogo
                ? "Uploading…"
                : branding.logoUrl
                  ? "Replace logo"
                  : "Upload logo"}
            </button>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.[0]) handleLogoFile(e.target.files[0]);
                e.target.value = "";
              }}
            />
            <p className="mt-1 text-[11px] text-ink-400 dark:text-ink-50/50">
              PNG or SVG-style logo works best, up to 5MB.
            </p>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="field-label">Facebook URL</label>
            <input
              className="field-input"
              value={branding.facebookUrl}
              onChange={(e) =>
                setBranding({ ...branding, facebookUrl: e.target.value })
              }
              placeholder="https://facebook.com/…"
            />
          </div>
          <div>
            <label className="field-label">Instagram URL</label>
            <input
              className="field-input"
              value={branding.instagramUrl}
              onChange={(e) =>
                setBranding({ ...branding, instagramUrl: e.target.value })
              }
              placeholder="https://instagram.com/…"
            />
          </div>
          <div>
            <label className="field-label">TikTok URL</label>
            <input
              className="field-input"
              value={branding.tiktokUrl}
              onChange={(e) =>
                setBranding({ ...branding, tiktokUrl: e.target.value })
              }
              placeholder="https://tiktok.com/@…"
            />
          </div>
        </div>
        <button
          onClick={saveBranding}
          disabled={isPending}
          className="btn-primary mt-4 !px-5 !py-2 text-[12.5px]"
        >
          Save branding
        </button>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-4 font-display text-base">Site settings</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="field-label">Site name</label>
            <input
              className="field-input"
              value={settings.siteName}
              onChange={(e) =>
                setSettings({ ...settings, siteName: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">
              Tagline / scrolling notice bar text
            </label>
            <input
              className="field-input"
              value={settings.tagline}
              onChange={(e) =>
                setSettings({ ...settings, tagline: e.target.value })
              }
              placeholder="e.g. Autumn sale — 20% off all electronics this week"
            />
          </div>
          <div>
            <label className="field-label">
              Contact email (shown in footer)
            </label>
            <input
              className="field-input"
              value={settings.contactEmail}
              onChange={(e) =>
                setSettings({ ...settings, contactEmail: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">Contact phone</label>
            <input
              className="field-input"
              value={settings.contactPhone}
              onChange={(e) =>
                setSettings({ ...settings, contactPhone: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">
              Admin notification email (new-order alerts)
            </label>
            <input
              className="field-input"
              value={settings.adminNotificationEmail}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  adminNotificationEmail: e.target.value,
                })
              }
            />
          </div>
          <div>
            <label className="field-label">VAT rate (%)</label>
            <input
              className="field-input"
              type="number"
              value={settings.vatRate}
              onChange={(e) =>
                setSettings({ ...settings, vatRate: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">
              Free delivery over (£, blank = off)
            </label>
            <input
              className="field-input"
              type="number"
              value={settings.freeShippingOverAmount ?? ""}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  freeShippingOverAmount: e.target.value,
                })
              }
            />
          </div>
          <label className="mt-6 flex items-center gap-2 text-[13px]">
            <input
              type="checkbox"
              checked={settings.pricesIncludeVat}
              onChange={(e) =>
                setSettings({ ...settings, pricesIncludeVat: e.target.checked })
              }
            />
            Prices shown include VAT
          </label>
        </div>
        <button
          onClick={saveSettings}
          disabled={isPending}
          className="btn-primary mt-4 !px-5 !py-2 text-[12.5px]"
        >
          Save settings
        </button>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-1 font-display text-base">Payments</h2>
        <a href="/admin/payments" className="btn-primary">
          Manage payment gateways and credentials
        </a>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-1 font-display text-base">Tracking</h2>
        <p className="mb-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Wire these up once and every page — storefront and checkout — fires
          them automatically (see{" "}
          <code>src/components/storefront/tracking-scripts.tsx</code>).
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="field-label">Meta (Facebook) Pixel ID</label>
            <input
              className="field-input"
              placeholder="1234567890123456"
              value={tracking.metaPixelId}
              onChange={(e) =>
                setTracking({ ...tracking, metaPixelId: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">
              Google Analytics 4 Measurement ID
            </label>
            <input
              className="field-input"
              placeholder="G-XXXXXXXXXX"
              value={tracking.gaMeasurementId}
              onChange={(e) =>
                setTracking({ ...tracking, gaMeasurementId: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">
              Google Tag Manager container ID (optional)
            </label>
            <input
              className="field-input"
              placeholder="GTM-XXXXXXX"
              value={tracking.gtmContainerId}
              onChange={(e) =>
                setTracking({ ...tracking, gtmContainerId: e.target.value })
              }
            />
          </div>
          <div>
            <label className="field-label">WhatsApp quick-order number</label>
            <input
              className="field-input"
              placeholder="+44 7123 456789"
              value={tracking.whatsappNumber}
              onChange={(e) =>
                setTracking({ ...tracking, whatsappNumber: e.target.value })
              }
            />
          </div>
        </div>
        <button
          onClick={saveTracking}
          disabled={isPending}
          className="btn-primary mt-4 !px-5 !py-2 text-[12.5px]"
        >
          Save tracking settings
        </button>
      </section>

      <section className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-1 font-display text-base">
          Delivery zones &amp; charges
        </h2>
        <p className="mb-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Matched automatically at checkout by UK postcode prefix (e.g. IV, KW,
          ZE, HS for Highlands &amp; Islands). Leave prefixes blank for the
          default/fallback zone.
        </p>

        <div className="flex flex-col gap-3">
          {zones.map((z) => (
            <div key={z.id} className="rounded-xl border border-ink-900/10 p-4">
              <div className="grid gap-2.5 sm:grid-cols-2">
                <input
                  className="field-input"
                  value={z.name}
                  onChange={(e) =>
                    updateZoneField(z.id, "name", e.target.value)
                  }
                  placeholder="Zone name"
                />
                <input
                  className="field-input"
                  value={z.estimatedDays}
                  onChange={(e) =>
                    updateZoneField(z.id, "estimatedDays", e.target.value)
                  }
                  placeholder="Estimated days"
                />
                <input
                  className="field-input sm:col-span-2"
                  value={z.description}
                  onChange={(e) =>
                    updateZoneField(z.id, "description", e.target.value)
                  }
                  placeholder="Description"
                />
                <input
                  className="field-input"
                  type="number"
                  step="0.01"
                  value={z.charge}
                  onChange={(e) =>
                    updateZoneField(z.id, "charge", e.target.value)
                  }
                  placeholder="Charge (£)"
                />
                <input
                  className="field-input"
                  type="number"
                  step="0.01"
                  value={z.freeOverAmount ?? ""}
                  onChange={(e) =>
                    updateZoneField(z.id, "freeOverAmount", e.target.value)
                  }
                  placeholder="Free over (£, optional)"
                />
                <input
                  className="field-input sm:col-span-2"
                  value={z.postcodePrefixes.join(", ")}
                  onChange={(e) =>
                    updateZoneField(
                      z.id,
                      "postcodePrefixes",
                      e.target.value
                        .split(",")
                        .map((s) => s.trim().toUpperCase())
                        .filter(Boolean),
                    )
                  }
                  placeholder="Postcode prefixes, comma-separated (blank = default zone)"
                />
              </div>
              <div className="mt-3 flex items-center justify-between">
                <label className="flex items-center gap-2 text-[12.5px]">
                  <input
                    type="checkbox"
                    checked={z.isActive}
                    onChange={(e) =>
                      updateZoneField(z.id, "isActive", e.target.checked)
                    }
                  />{" "}
                  Active
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => saveZone(z)}
                    disabled={isPending}
                    className="btn-secondary !px-4 !py-1.5 text-[12px]"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => removeZone(z.id)}
                    disabled={isPending}
                    className="rounded-full border border-red-200 p-2 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <p className="mt-2 text-[11.5px] text-ink-400 dark:text-ink-50/50">
                Current: {formatMoney(z.charge)}
                {z.freeOverAmount
                  ? `, free over ${formatMoney(z.freeOverAmount)}`
                  : ""}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-xl border border-dashed border-ink-900/20 p-4">
          <p className="mb-3 text-[12.5px] font-semibold">Add a new zone</p>
          <div className="grid gap-2.5 sm:grid-cols-2">
            <select
              aria-label="Delivery country"
              className="field-input"
              value={newZone.countryCode ?? "GB"}
              onChange={(e) =>
                setNewZone({ ...newZone, countryCode: e.target.value })
              }
            >
              {REGION_CODES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <input
              className="field-input"
              value={newZone.name}
              onChange={(e) => setNewZone({ ...newZone, name: e.target.value })}
              placeholder="Zone name"
            />
            <input
              className="field-input"
              value={newZone.estimatedDays}
              onChange={(e) =>
                setNewZone({ ...newZone, estimatedDays: e.target.value })
              }
              placeholder="Estimated days"
            />
            <input
              className="field-input sm:col-span-2"
              value={newZone.description}
              onChange={(e) =>
                setNewZone({ ...newZone, description: e.target.value })
              }
              placeholder="Description"
            />
            <input
              className="field-input"
              type="number"
              step="0.01"
              value={newZone.charge}
              onChange={(e) =>
                setNewZone({ ...newZone, charge: e.target.value })
              }
              placeholder="Charge (£)"
            />
            <input
              className="field-input"
              type="number"
              step="0.01"
              value={newZone.freeOverAmount ?? ""}
              onChange={(e) =>
                setNewZone({ ...newZone, freeOverAmount: e.target.value })
              }
              placeholder="Free over (£, optional)"
            />
            <input
              className="field-input sm:col-span-2"
              value={newZone.postcodePrefixes.join(", ")}
              onChange={(e) =>
                setNewZone({
                  ...newZone,
                  postcodePrefixes: e.target.value
                    .split(",")
                    .map((s) => s.trim().toUpperCase())
                    .filter(Boolean),
                })
              }
              placeholder="Postcode prefixes, comma-separated"
            />
          </div>
          <button
            onClick={() => saveZone(newZone)}
            disabled={isPending || !newZone.name}
            className="btn-primary mt-3 !px-4 !py-2 text-[12.5px]"
          >
            <Plus size={14} /> Add zone
          </button>
        </div>
      </section>
    </div>
  );
}
