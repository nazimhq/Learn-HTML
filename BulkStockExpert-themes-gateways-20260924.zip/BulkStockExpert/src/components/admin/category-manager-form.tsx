"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, Trash2, Plus } from "lucide-react";
import {
  createCategory,
  updateCategory,
  deleteCategory,
} from "@/app/actions/admin-category-actions";
import { uploadImage } from "@/app/actions/upload-actions";

interface Category {
  id: string;
  name: string;
  slug: string;
  position: number;
  imageUrl: string | null;
  productCount: number;
}

function LogoPreview({
  imageUrl,
  name,
  size = 56,
}: {
  imageUrl: string | null;
  name: string;
  size?: number;
}) {
  if (imageUrl) {
    // eslint-disable-next-line @next/next/no-img-element
    return (
      <img
        src={imageUrl}
        alt={name}
        className="rounded-full object-cover"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      className="flex flex-shrink-0 items-center justify-center rounded-full font-display text-lg text-ink-50"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(135deg,#463924,#786240)",
      }}
    >
      {name.charAt(0).toUpperCase() || "?"}
    </div>
  );
}

function CategoryRow({
  category,
  onChanged,
}: {
  category: Category;
  onChanged: () => void;
}) {
  const [name, setName] = useState(category.name);
  const [slug, setSlug] = useState(category.slug);
  const [position, setPosition] = useState(category.position);
  const [imageUrl, setImageUrl] = useState(category.imageUrl);
  const [isPending, startTransition] = useTransition();
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFile(file: File) {
    setUploading(true);
    setMessage("");
    const formData = new FormData();
    formData.append("file", file);
    const result = await uploadImage(formData, "categories");
    setUploading(false);
    if (!result.ok || !result.url) {
      setMessage(result.message ?? "Upload failed.");
      return;
    }
    setImageUrl(result.url);
    startTransition(async () => {
      const res = await updateCategory(category.id, {
        name,
        slug,
        position,
        imageUrl: result.url,
      });
      setMessage(
        res.ok ? "Logo updated." : (res.message ?? "Something went wrong."),
      );
      onChanged();
    });
  }

  function save() {
    startTransition(async () => {
      const res = await updateCategory(category.id, {
        name,
        slug,
        position,
        imageUrl,
      });
      setMessage(res.ok ? "Saved." : (res.message ?? "Something went wrong."));
      if (res.ok) onChanged();
    });
  }

  function remove() {
    startTransition(async () => {
      const res = await deleteCategory(category.id);
      setMessage(
        res.ok ? "Deleted." : (res.message ?? "Couldn't delete this category."),
      );
      if (res.ok) onChanged();
    });
  }

  return (
    <div className="rounded-xl border border-ink-900/10 p-4 dark:border-ink-50/10">
      <div className="flex flex-wrap items-start gap-4">
        <div className="flex flex-col items-center gap-1.5">
          <LogoPreview imageUrl={imageUrl} name={name} />
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1 text-[11px] font-semibold text-brand-600 hover:underline"
          >
            <ImagePlus size={12} />{" "}
            {uploading ? "Uploading..." : imageUrl ? "Change logo" : "Add logo"}
          </button>
        </div>

        <div className="grid flex-1 gap-2.5 sm:grid-cols-3">
          <div>
            <label className="field-label">Name</label>
            <input
              className="field-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label className="field-label">Slug</label>
            <input
              className="field-input"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
          </div>
          <div>
            <label className="field-label">Position</label>
            <input
              className="field-input"
              type="number"
              value={position}
              onChange={(e) => setPosition(Number(e.target.value))}
            />
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <p className="text-[12px] text-ink-400 dark:text-ink-50/50">
          {category.productCount} product
          {category.productCount === 1 ? "" : "s"}
          {message && (
            <span className="ml-2 text-ink-600 dark:text-ink-50/70">
              {message}
            </span>
          )}
        </p>
        <div className="flex gap-2">
          <button
            onClick={save}
            disabled={isPending}
            className="btn-secondary !px-4 !py-1.5 text-[12px]"
          >
            Save
          </button>
          <button
            onClick={remove}
            disabled={isPending || category.productCount > 0}
            title={
              category.productCount > 0
                ? "Move or delete its products first"
                : "Delete category"
            }
            className="rounded-full border border-red-200 p-2 text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-30"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

export function CategoryManagerForm({
  initialCategories,
}: {
  initialCategories: Category[];
}) {
  const router = useRouter();
  const [categories, setCategories] = useState(initialCategories);
  const [newName, setNewName] = useState("");
  const [newSlug, setNewSlug] = useState("");
  const [newImageUrl, setNewImageUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");
  const newFileRef = useRef<HTMLInputElement>(null);

  function refresh() {
    // Server actions already revalidatePath("/admin/categories") — pull the freshly
    // revalidated server data back into this page (ids, exact slugs, etc).
    router.refresh();
  }

  async function handleNewFile(file: File) {
    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);
    const result = await uploadImage(formData, "categories");
    setUploading(false);
    if (!result.ok || !result.url) {
      setMessage(result.message ?? "Upload failed.");
      return;
    }
    setNewImageUrl(result.url);
  }

  function addCategory() {
    startTransition(async () => {
      const res = await createCategory({
        name: newName,
        slug: newSlug || undefined,
        imageUrl: newImageUrl,
      });
      if (!res.ok) {
        setMessage(res.message ?? "Something went wrong.");
        return;
      }
      setMessage("Category added.");
      setCategories((cs) => [
        ...cs,
        {
          id: `temp-${Date.now()}`,
          name: newName.trim(),
          slug: (newSlug || newName).toLowerCase().replace(/[^a-z0-9]+/g, "-"),
          position: cs.length,
          imageUrl: newImageUrl,
          productCount: 0,
        },
      ]);
      setNewName("");
      setNewSlug("");
      setNewImageUrl(null);
      refresh();
    });
  }

  return (
    <div className="flex flex-col gap-4">
      {message && (
        <p className="rounded-lg bg-emerald-50 px-3.5 py-2 text-[12.5px] text-emerald-700">
          {message}
        </p>
      )}

      <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-4 font-display text-base">Add a category</h2>
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col items-center gap-1.5">
            <LogoPreview imageUrl={newImageUrl} name={newName || "?"} />
            <input
              ref={newFileRef}
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleNewFile(f);
              }}
            />
            <button
              type="button"
              onClick={() => newFileRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-1 text-[11px] font-semibold text-brand-600 hover:underline"
            >
              <ImagePlus size={12} /> {uploading ? "Uploading..." : "Add logo"}
            </button>
          </div>
          <div className="grid flex-1 gap-2.5 sm:grid-cols-2">
            <div>
              <label className="field-label">Name</label>
              <input
                className="field-input"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Kitchen Appliances"
              />
            </div>
            <div>
              <label className="field-label">
                Slug (optional — auto from name)
              </label>
              <input
                className="field-input"
                value={newSlug}
                onChange={(e) => setNewSlug(e.target.value)}
                placeholder="kitchen-appliances"
              />
            </div>
          </div>
          <button
            onClick={addCategory}
            disabled={isPending || !newName.trim()}
            className="btn-primary !px-5 !py-2.5 text-[12.5px]"
          >
            <Plus size={14} /> Add category
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        {categories.map((c) => (
          <CategoryRow key={c.id} category={c} onChanged={refresh} />
        ))}
        {categories.length === 0 && (
          <p className="rounded-2xl border border-dashed border-ink-900/15 py-10 text-center text-[13px] text-ink-400 dark:border-ink-50/15 dark:text-ink-50/50">
            No categories yet — add your first one above.
          </p>
        )}
      </div>
    </div>
  );
}
