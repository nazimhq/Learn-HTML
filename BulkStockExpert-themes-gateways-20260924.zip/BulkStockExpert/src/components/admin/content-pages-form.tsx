"use client";

import { useState, useTransition } from "react";
import { FileText } from "lucide-react";
import { updateContentPage } from "@/app/actions/admin-content-actions";
import type { ContentPageRow } from "@/app/actions/admin-content-actions";

function PageEditor({ page }: { page: ContentPageRow }) {
  const [title, setTitle] = useState(page.title);
  const [body, setBody] = useState(page.body);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  function save() {
    setMessage("");
    startTransition(async () => {
      const res = await updateContentPage(page.slug, title, body);
      setMessage(res.ok ? "Saved." : (res.message ?? "Something went wrong."));
    });
  }

  return (
    <div className="rounded-2xl border border-ink-900/10 bg-white p-5 dark:border-ink-50/10 dark:bg-panel">
      <p className="mb-3 flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
        <FileText size={13} /> /pages/{page.slug}
      </p>
      <label className="field-label">Page title</label>
      <input
        className="field-input mb-3"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <label className="field-label">
        Body text (leave a blank line between paragraphs)
      </label>
      <textarea
        className="field-input min-h-[160px] font-normal"
        value={body}
        onChange={(e) => setBody(e.target.value)}
      />
      {message && (
        <p className="mt-2 text-[12px] text-ink-400 dark:text-ink-50/50">
          {message}
        </p>
      )}
      <button
        onClick={save}
        disabled={isPending}
        className="btn-primary mt-3 !px-4 !py-2 text-[12.5px]"
      >
        {isPending ? "Saving…" : "Save page"}
      </button>
    </div>
  );
}

export function ContentPagesForm({ pages }: { pages: ContentPageRow[] }) {
  return (
    <div className="flex flex-col gap-5">
      {pages.map((p) => (
        <PageEditor key={p.slug} page={p} />
      ))}
    </div>
  );
}
