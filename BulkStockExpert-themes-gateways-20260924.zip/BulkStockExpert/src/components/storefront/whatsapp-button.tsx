"use client";

/** Floating site-wide WhatsApp quick-order button. Renders nothing if no number is set in Admin → Site Settings → Tracking. */
export function WhatsAppButton({
  number,
  message,
}: {
  number?: string | null;
  message?: string;
}) {
  if (!number) return null;
  const digits = number.replace(/[^\d]/g, "");
  const href = `https://wa.me/${digits}${message ? `?text=${encodeURIComponent(message)}` : ""}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      // Fixed bottom-right, above everything else (z-50) and clear of the iOS/Android home
      // indicator / gesture bar via env(safe-area-inset-*) — added with calc() so it stacks
      // with the base offset instead of replacing it (falls back to 0 on browsers without
      // safe-area support).
      className="animate-soft-pulse fixed bottom-6 right-6 z-50 flex h-[54px] w-[54px] items-center justify-center rounded-full bg-success text-white shadow-[0_12px_26px_-8px_rgba(15,60,35,0.45)] transition hover:scale-[1.06] hover:brightness-95"
      style={{
        right: "max(1.5rem, calc(env(safe-area-inset-right, 0px) + 1rem))",
        bottom: "max(1.5rem, calc(env(safe-area-inset-bottom, 0px) + 1rem))",
      }}
    >
      <svg
        width="27"
        height="27"
        viewBox="0 0 24 24"
        fill="currentColor"
        className="relative z-10"
      >
        <path d="M12.04 2c-5.5 0-10 4.5-10 10 0 1.77.46 3.5 1.34 5.02L2 22l5.13-1.35A9.96 9.96 0 0 0 12.04 22c5.5 0 10-4.5 10-10s-4.5-10-10-10zm5.8 14.2c-.24.68-1.4 1.3-1.94 1.38-.5.08-1.12.11-1.8-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.16-4.94-4.35-.14-.19-1.18-1.57-1.18-3 0-1.42.75-2.12 1.02-2.41.27-.29.58-.36.78-.36h.55c.18 0 .42-.07.65.5.24.58.82 2 .89 2.15.07.15.12.32.02.51-.1.19-.15.31-.3.48-.15.17-.31.38-.44.51-.15.15-.3.31-.13.6.17.29.76 1.25 1.63 2.02 1.12.99 2.06 1.3 2.36 1.45.3.15.48.13.65-.08.18-.21.75-.88.95-1.18.2-.3.4-.25.67-.15.28.1 1.76.83 2.06.98.3.15.5.22.57.35.08.13.08.72-.16 1.4z" />
      </svg>
    </a>
  );
}
