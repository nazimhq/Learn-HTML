const assets: Record<string, string> = {
  Visa: "visa",
  Mastercard: "mastercard",
  Amex: "amex",
  "Apple Pay": "apple-pay",
  "Google Pay": "google-pay",
  PayPal: "paypal",
  Klarna: "klarna",
};
const brands = [
  "Visa",
  "Mastercard",
  "Amex",
  "Apple Pay",
  "Google Pay",
  "PayPal",
  "Klarna",
  "Clearpay",
  "bKash",
  "Nagad",
];
export function PaymentBadges() {
  return (
    <div className="my-4">
      <div
        className="flex flex-wrap gap-2"
        aria-label="Payment options depend on region and availability"
      >
        {brands.map((brand) =>
          assets[brand] ? (
            <img
              key={brand}
              src={`/payments/${assets[brand]}.svg`}
              alt={brand}
              className="h-8 w-20 rounded-md bg-white p-1.5 transition hover:scale-105 hover:shadow-lg"
            />
          ) : (
            <svg
              key={brand}
              role="img"
              aria-label={brand}
              viewBox="0 0 100 40"
              className="h-8 w-20 rounded-md border border-current/20 bg-white text-slate-800 transition hover:scale-105 hover:shadow-lg"
            >
              <title>{brand}</title>
              <text
                x="50"
                y="25"
                textAnchor="middle"
                fontSize="12"
                fontWeight="700"
                fontFamily="Arial,sans-serif"
              >
                {brand}
              </text>
            </svg>
          ),
        )}
      </div>
      <p className="mt-2 text-xs opacity-70">
        Available options are confirmed at checkout.
      </p>
    </div>
  );
}
