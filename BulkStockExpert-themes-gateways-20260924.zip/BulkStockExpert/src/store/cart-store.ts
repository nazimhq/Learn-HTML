"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine } from "@/types";

interface CartState {
  lines: CartLine[];
  isOpen: boolean;
  open: () => void;
  close: () => void;
  addItem: (line: Omit<CartLine, "qty">, qty?: number) => void;
  changeQty: (variantId: string, delta: number) => void;
  removeItem: (variantId: string) => void;
  clear: () => void;
  subtotal: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      isOpen: false,
      open: () => set({ isOpen: true }),
      close: () => set({ isOpen: false }),
      addItem: (line, qty = 1) =>
        set((state) => {
          const existing = state.lines.find(
            (l) => l.variantId === line.variantId,
          );
          if (existing) {
            return {
              lines: state.lines.map((l) =>
                l.variantId === line.variantId
                  ? { ...l, qty: Math.min(l.qty + qty, l.maxStock) }
                  : l,
              ),
              isOpen: true,
            };
          }
          return {
            lines: [
              ...state.lines,
              { ...line, qty: Math.min(qty, line.maxStock) },
            ],
            isOpen: true,
          };
        }),
      changeQty: (variantId, delta) =>
        set((state) => ({
          lines: state.lines.map((l) =>
            l.variantId === variantId
              ? { ...l, qty: Math.max(1, Math.min(l.qty + delta, l.maxStock)) }
              : l,
          ),
        })),
      removeItem: (variantId) =>
        set((state) => ({
          lines: state.lines.filter((l) => l.variantId !== variantId),
        })),
      clear: () => set({ lines: [] }),
      subtotal: () => get().lines.reduce((sum, l) => sum + l.price * l.qty, 0),
    }),
    {
      name: "bulkstockexpert-cart",
      // Only the basket lines are remembered. Persisting `isOpen` made the drawer pop open on
      // every page load after an item was added (covering the checkout "Place order" button).
      partialize: (state) => ({ lines: state.lines }),
      // Ignore an `isOpen` saved by older versions so existing shoppers aren't affected either.
      merge: (persisted, current) => ({
        ...current,
        lines: (persisted as { lines?: CartLine[] } | undefined)?.lines ?? [],
      }),
    },
  ),
);
