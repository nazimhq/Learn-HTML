"use client";
import { useParams } from "next/navigation";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { KeyRound, CheckCircle2, XCircle } from "lucide-react";
import { validateResetToken, resetPassword } from "@/app/actions/auth-actions";

export default function ResetPasswordPage() {
  const params = useParams<{ token: string }>();
  const router = useRouter();
  const [checking, setChecking] = useState(true);
  const [valid, setValid] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [signInHref, setSignInHref] = useState("/admin/login");

  useEffect(() => {
    validateResetToken(params.token).then((res) => {
      setValid(res.valid);
      if (res.role)
        setSignInHref(res.role === "ADMIN" ? "/admin/login" : "/account/login");
      setChecking(false);
    });
  }, [params.token]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setSubmitting(true);
    const result = await resetPassword({ token: params.token, password });
    setSubmitting(false);
    if (!result.ok) {
      setError(result.message ?? "Something went wrong.");
      return;
    }
    if (result.role)
      setSignInHref(
        result.role === "ADMIN" ? "/admin/login" : "/account/login",
      );
    setDone(true);
    setTimeout(
      () =>
        router.push(
          result.role === "ADMIN" ? "/admin/login" : "/account/login",
        ),
      2000,
    );
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-surface px-4">
      <div className="w-full max-w-sm rounded-2xl border border-ink-900/10 bg-white p-7 dark:border-ink-50/10 dark:bg-panel">
        {checking ? (
          <p className="text-center text-[13px] text-ink-400 dark:text-ink-50/50">
            Checking your link...
          </p>
        ) : !valid ? (
          <div className="flex flex-col items-center text-center">
            <XCircle size={32} className="mb-3 text-red-600" />
            <h1 className="font-display text-lg">Link expired or invalid</h1>
            <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">
              This password reset link has already been used or has expired.
              Request a new one below.
            </p>
            <a
              href="/forgot-password"
              className="btn-primary mt-5 w-full justify-center"
            >
              Request a new link
            </a>
          </div>
        ) : done ? (
          <div className="flex flex-col items-center text-center">
            <CheckCircle2 size={32} className="mb-3 text-emerald-600" />
            <h1 className="font-display text-lg">Password updated</h1>
            <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">
              Redirecting you to sign in...
            </p>
          </div>
        ) : (
          <>
            <div className="mb-5 flex flex-col items-center text-center">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 text-ink-50 dark:bg-ink-50 dark:text-ink-900">
                <KeyRound size={18} />
              </div>
              <h1 className="font-display text-xl">Choose a new password</h1>
            </div>
            <form onSubmit={onSubmit} className="flex flex-col gap-3">
              <div>
                <label className="field-label">New password</label>
                <input
                  className="field-input"
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Confirm password</label>
                <input
                  className="field-input"
                  type="password"
                  required
                  minLength={8}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </div>
              {error && (
                <p className="rounded-lg bg-red-50 px-3 py-2 text-[12.5px] text-red-700">
                  {error}
                </p>
              )}
              <button
                type="submit"
                disabled={submitting}
                className="btn-primary mt-2 w-full"
              >
                {submitting ? "Saving..." : "Save new password"}
              </button>
            </form>
          </>
        )}
        {!checking && !valid ? null : (
          <p className="mt-5 text-center text-[12px] text-ink-400 dark:text-ink-50/50">
            <a
              href={signInHref}
              className="hover:text-ink-900 dark:hover:text-ink-50"
            >
              Back to sign in
            </a>
          </p>
        )}
      </div>
    </div>
  );
}
