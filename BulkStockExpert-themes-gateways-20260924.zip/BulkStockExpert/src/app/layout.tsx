import { ThemeSync } from "@/components/layout/theme-sync";
import type { Metadata } from "next";
import "@fontsource/fraunces/500.css";
import "@fontsource/fraunces/600.css";
import "@fontsource/work-sans/400.css";
import "@fontsource/work-sans/500.css";
import "@fontsource/work-sans/600.css";
import "@fontsource/work-sans/700.css";
import "@fontsource/ibm-plex-mono/500.css";
import "@fontsource/ibm-plex-mono/600.css";
import "@fontsource/space-grotesk/500.css";
import "@fontsource/space-grotesk/600.css";
import "@fontsource/space-grotesk/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "./globals.css";
import "./skins.css";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { CartDrawer } from "@/components/cart/cart-drawer";
import { TrackingScripts } from "@/components/storefront/tracking-scripts";
import { WhatsAppButton } from "@/components/storefront/whatsapp-button";
import { prisma } from "@/lib/prisma";
import { SITE_NAME } from "@/lib/constants";
import { getBrandingSettings } from "@/app/actions/admin-settings-actions";
import { getActiveTheme } from "@/lib/site-theme-server";

// Forces the ENTIRE app to render per-request instead of being statically prerendered at
// build time. This root layout queries Prisma on every render (categories, branding
// settings); this host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been
// observed to hang or crash the Prisma query engine (a Rust panic, uncatchable by JS
// try/catch) when it's exercised during `next build`'s static-generation pass. Since every
// route shares this layout, forcing it dynamic here fixes build-time hangs app-wide.
export const dynamic = "force-dynamic";

// Dynamic so a saved change to Site Settings → Site Name is reflected in the browser tab
// title / search-engine metadata immediately, without a redeploy. Falls back to the
// hardcoded SITE_NAME if the settings lookup fails for any reason (offline DB, etc.) so a
// transient DB hiccup never breaks page <head> rendering.
export async function generateMetadata(): Promise<Metadata> {
  const siteName = await getSiteNameForMetadata();
  return {
    title: `${siteName} — Genuine Customer-Return Pallets, UK Wide`,
    description:
      "Electronics, home, clothing and general merchandise customer-return pallets and job lots — manifested stock, sourced and sold across the UK.",
  };
}

async function getSiteNameForMetadata(): Promise<string> {
  try {
    const settings = await prisma.appSettings.findUnique({
      where: { id: "singleton" },
      select: { siteName: true },
    });
    return settings?.siteName || SITE_NAME;
  } catch {
    return SITE_NAME;
  }
}

async function getCategories() {
  try {
    return await prisma.category.findMany({
      orderBy: { position: "asc" },
      select: { id: true, name: true, slug: true },
    });
  } catch {
    return [];
  }
}

async function getSettings() {
  try {
    return await prisma.appSettings.findUnique({ where: { id: "singleton" } });
  } catch {
    return null;
  }
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [categories, settings, branding, activeTheme] = await Promise.all([
    getCategories(),
    getSettings(),
    getBrandingSettings(),
    getActiveTheme(),
  ]);
  // Accent + light/dark come from Settings → Theme; the design (skin) and any automatic
  // rotation come from Admin → Design & themes. getActiveTheme() already merges both.
  const accentTheme = activeTheme.accent;
  const skin = activeTheme.skin;
  // The NEXAWEB design is dark-only.
  const colorMode = skin === "nexaweb" ? "dark" : activeTheme.mode;

  return (
    <html
      suppressHydrationWarning
      lang="en"
      data-accent={accentTheme}
      data-mode={colorMode}
      data-skin={skin}
    >
      <head>
        {/* Anti-flash: apply a visitor's own light/dark override (if they've toggled it before)
            before first paint, so the page never flashes the admin's default then flips. */}
        <script
          dangerouslySetInnerHTML={{
            __html: `try{var d=document.documentElement,m=localStorage.getItem("bse-theme-mode");if(m&&d.dataset.skin!=="nexaweb")d.dataset.mode=m;}catch(e){}`,
          }}
        />
      </head>
      <body className="font-sans">
        <ThemeSync
          accent={accentTheme}
          mode={colorMode}
          skin={skin}
          nextChangeAt={activeTheme.nextChangeAt}
        />
        <TrackingScripts
          gaMeasurementId={settings?.gaMeasurementId}
          metaPixelId={settings?.metaPixelId}
          gtmContainerId={settings?.gtmContainerId}
        />
        <Header
          categories={categories}
          siteName={settings?.siteName ?? SITE_NAME}
          tagline={settings?.tagline}
          logoUrl={branding.logoUrl}
        />
        <main className="min-h-[60vh]">{children}</main>
        <Footer
          siteName={settings?.siteName ?? SITE_NAME}
          contactEmail={settings?.contactEmail}
          contactPhone={settings?.contactPhone}
          facebookUrl={branding.facebookUrl}
          instagramUrl={branding.instagramUrl}
          tiktokUrl={branding.tiktokUrl}
        />
        <CartDrawer />
        <WhatsAppButton
          number={settings?.whatsappNumber}
          message={`Hi ${settings?.siteName ?? SITE_NAME}, I have a question about an order.`}
        />
      </body>
    </html>
  );
}
