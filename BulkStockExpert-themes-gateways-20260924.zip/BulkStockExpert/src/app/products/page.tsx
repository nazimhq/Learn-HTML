import { prisma } from "@/lib/prisma";
import { ProductFilters } from "@/components/catalog/product-filters";
import { SortSelect } from "@/components/catalog/sort-select";
import { ProductCard } from "@/components/home/product-card";
import {
  publicProductCardSelect,
  type PublicProductCard,
} from "@/lib/queries/product-select";
import type { ProductCardData } from "@/types";
import type { Prisma } from "@prisma/client";
import { Reveal } from "@/components/motion/reveal";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

function toCardData(p: PublicProductCard): ProductCardData {
  return {
    id: p.id,
    name: p.name,
    slug: p.slug,
    brand: p.brand?.name ?? null,
    basePrice: Number(p.basePrice),
    compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
    imageUrl: p.images[0]?.url ?? "",
    ratingAvg: p.ratingAvg,
    reviewCount: p.reviewCount,
    inStock: p.variants.some((v) => v.stock > 0),
  };
}

const SORT_MAP: Record<string, Prisma.ProductOrderByWithRelationInput> = {
  newest: { createdAt: "desc" },
  "price-asc": { basePrice: "asc" },
  "price-desc": { basePrice: "desc" },
  rating: { ratingAvg: "desc" },
};

export default async function ProductsPage({
  searchParams: request,
}: {
  searchParams: Promise<{
    category?: string;
    brand?: string;
    min?: string;
    max?: string;
    inStock?: string;
    sort?: string;
    q?: string;
  }>;
}) {
  const searchParams = await request;
  const where: Prisma.ProductWhereInput = { status: "ACTIVE" };
  if (searchParams.category) where.category = { slug: searchParams.category };
  // Brand is an optional relation, so Prisma's filter type needs the `is` wrapper here.
  if (searchParams.brand) where.brand = { is: { slug: searchParams.brand } };
  const q = (searchParams.q ?? "").trim().slice(0, 80);
  if (q) where.OR = [{ name: { contains: q } }, { description: { contains: q } }];
  if (searchParams.min || searchParams.max) {
    where.basePrice = {
      ...(searchParams.min ? { gte: Number(searchParams.min) } : {}),
      ...(searchParams.max ? { lte: Number(searchParams.max) } : {}),
    };
  }
  if (searchParams.inStock === "1")
    where.variants = { some: { stock: { gt: 0 } } };

  const orderBy = SORT_MAP[searchParams.sort ?? "newest"] ?? SORT_MAP.newest;

  let products: ProductCardData[] = [];
  let categories: { id: string; name: string; slug: string }[] = [];
  let brands: { id: string; name: string; slug: string }[] = [];

  try {
    const [productRows, categoryRows, brandRows] = await Promise.all([
      prisma.product.findMany({
        where,
        select: publicProductCardSelect,
        orderBy,
        take: 60,
      }),
      prisma.category.findMany({
        orderBy: { position: "asc" },
        select: { id: true, name: true, slug: true },
      }),
      prisma.brand.findMany({
        orderBy: { name: "asc" },
        select: { id: true, name: true, slug: true },
      }),
    ]);
    products = productRows.map(toCardData);
    categories = categoryRows;
    brands = brandRows;
  } catch {
    // DB not migrated/seeded yet.
  }

  return (
    <div className="container-page py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="font-display text-2xl">All Products</h1>
        <div className="hidden sm:block">
          <SortSelect />
        </div>
      </div>

      <div className="flex flex-col gap-6 lg:flex-row">
        <ProductFilters categories={categories} brands={brands} />
        <div className="flex-1">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-[13px] text-ink-400 dark:text-ink-50/50">
              {products.length} products
            </span>
            <div className="sm:hidden">
              <SortSelect />
            </div>
          </div>
          {products.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-ink-900/15 py-20 text-center text-ink-400 dark:text-ink-50/50">
              <p className="text-sm">No products match these filters yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 md:grid-cols-4">
              {products.map((p, i) => (
                <Reveal key={p.id} delay={(i % 4) * 50}>
                  <ProductCard product={p} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
