import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { publicProductDetailSelect } from "@/lib/queries/product-select";
import { ImageGallery } from "@/components/pdp/image-gallery";
import { ProductBuyBox } from "@/components/pdp/product-buy-box";
import { ReviewList } from "@/components/pdp/review-list";
import { ReviewForm } from "@/components/pdp/review-form";
import { RelatedProducts } from "@/components/pdp/related-products";

export const revalidate = 60;

async function getProduct(slug: string) {
  try {
    return await prisma.product.findUnique({
      where: { slug, status: "ACTIVE" },
      select: publicProductDetailSelect,
    });
  } catch {
    return null;
  }
}

async function getWhatsappNumber() {
  try {
    const settings = await prisma.appSettings.findUnique({
      where: { id: "singleton" },
      select: { whatsappNumber: true },
    });
    return settings?.whatsappNumber ?? null;
  } catch {
    return null;
  }
}

export default async function ProductDetailPage({
  params: request,
}: {
  params: Promise<{ slug: string }>;
}) {
  const params = await request;
  const [product, whatsappNumber] = await Promise.all([
    getProduct(params.slug),
    getWhatsappNumber(),
  ]);
  if (!product) notFound();

  const variants = product.variants.map((v) => ({
    id: v.id,
    sku: v.sku,
    label: v.label,
    price: Number(v.price),
    compareAtPrice: v.compareAtPrice ? Number(v.compareAtPrice) : null,
    stock: v.stock,
    lowStockAt: v.lowStockAt,
    imageUrl: v.imageUrl,
  }));

  return (
    <div className="container-page py-8">
      <nav className="mb-4 flex items-center gap-1.5 text-[12px] text-ink-400 dark:text-ink-50/50">
        <Link href="/" className="hover:text-brand-600">
          Home
        </Link>
        <span>/</span>
        <Link
          href={`/products?category=${product.category.slug}`}
          className="hover:text-brand-600"
        >
          {product.category.name}
        </Link>
        <span>/</span>
        <span className="text-ink-700">{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-14">
        <ImageGallery images={product.images} productName={product.name} />

        <div>
          {product.brand && (
            <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              {product.brand.name}
            </p>
          )}
          <h1 className="mb-4 font-display text-[26px] leading-tight sm:text-[30px]">
            {product.name}
          </h1>

          <ProductBuyBox
            productId={product.id}
            productName={product.name}
            ratingAvg={product.ratingAvg}
            reviewCount={product.reviewCount}
            variants={variants}
            whatsappNumber={whatsappNumber}
          />

          <div className="mt-8 border-t border-ink-900/10 pt-6">
            <h2 className="mb-2 text-[13.5px] font-semibold">Description</h2>
            <p className="whitespace-pre-line text-[13.5px] leading-relaxed text-ink-600 dark:text-ink-50/65">
              {product.description}
            </p>
            {Array.isArray(product.tags) && product.tags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {product.tags
                  .filter((v): v is string => typeof v === "string")
                  .map((t) => (
                    <span
                      key={t}
                      className="rounded-full bg-ink-100 px-2.5 py-1 text-[11px] text-ink-400 dark:text-ink-50/50"
                    >
                      #{t}
                    </span>
                  ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto mt-14 max-w-3xl border-t border-ink-900/10 pt-8">
        <h2 className="mb-4 font-display text-lg">Customer Reviews</h2>
        <div className="grid gap-8 sm:grid-cols-2">
          <ReviewList
            reviews={product.reviews.map((r) => ({
              id: r.id,
              customerName: r.customerName,
              rating: r.rating,
              comment: r.comment,
              createdAt: r.createdAt.toISOString(),
            }))}
          />
          <div>
            <h3 className="mb-2 text-[13px] font-semibold text-ink-800 dark:text-ink-50/90">
              Write a review
            </h3>
            <ReviewForm productId={product.id} productSlug={product.slug} />
          </div>
        </div>
      </div>

      <RelatedProducts
        productId={product.id}
        categoryId={product.categoryId}
        tags={product.tags}
      />
    </div>
  );
}
