import Link from "next/link";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatMoney, ORDER_STATUS_LABEL } from "@/lib/constants";
import { SignOutButton } from "@/components/account/sign-out-button";
import { CartSummary } from "@/components/account/cart-summary";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

interface AccountOrder {
  id: string;
  orderNumber: string;
  status: string;
  paymentStatus: string;
  total: unknown;
  createdAt: Date;
}

async function getMyOrders(userId: string): Promise<AccountOrder[]> {
  try {
    // Cast: `userId` exists on the live schema/DB but this sandbox's generated Prisma client
    // is stale (see src/lib/prisma.ts) — see prisma/schema.prisma's Order.userId comment.
    return await prisma.order.findMany({
      where: { userId } as never,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        orderNumber: true,
        status: true,
        paymentStatus: true,
        total: true,
        createdAt: true,
      },
    });
  } catch {
    return [];
  }
}

export default async function AccountPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/account/login");

  const orders = await getMyOrders(session.user.id ?? "");
  const delivered = orders.filter((o) => o.status === "DELIVERED").length;
  const refunded = orders.filter((o) => o.paymentStatus === "REFUNDED").length;
  const cancelled = orders.filter((o) => o.status === "CANCELLED").length;

  return (
    <div className="container-page py-10">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl">My account</h1>
          <p className="mt-1 text-[13px] text-ink-400 dark:text-ink-50/50">
            Signed in as {session.user.email}
          </p>
        </div>
        <SignOutButton />
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4">
          <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Orders placed
          </p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
            {orders.length}
          </p>
        </div>
        <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4">
          <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Delivered
          </p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
            {delivered}
          </p>
        </div>
        <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4">
          <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Refunded
          </p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
            {refunded}
          </p>
        </div>
        <CartSummary />
      </div>

      {cancelled > 0 && (
        <p className="mt-3 text-[12px] text-ink-400 dark:text-ink-50/50">
          {cancelled} order{cancelled > 1 ? "s" : ""} cancelled.
        </p>
      )}

      <div className="mt-8 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-4 font-display text-base">
          Order history &amp; invoices
        </h2>
        {orders.length === 0 ? (
          <p className="text-[13px] text-ink-400 dark:text-ink-50/50">
            No orders yet on this account.{" "}
            <Link
              href="/products"
              className="font-semibold text-brand-600 hover:underline"
            >
              Start shopping →
            </Link>
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px]">
              <thead>
                <tr className="border-b border-ink-900/10 text-[11px] uppercase tracking-wide text-ink-400 dark:border-ink-50/10 dark:text-ink-50/50">
                  <th className="px-2 py-2">Order</th>
                  <th className="px-2 py-2">Placed</th>
                  <th className="px-2 py-2">Status</th>
                  <th className="px-2 py-2">Payment</th>
                  <th className="px-2 py-2 text-right">Total</th>
                  <th className="px-2 py-2" />
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr
                    key={o.id}
                    className="border-b border-ink-900/5 last:border-none dark:border-ink-50/5"
                  >
                    <td className="px-2 py-3 font-mono font-medium">
                      <Link
                        href={`/track-order?order=${o.orderNumber}&email=${encodeURIComponent(session.user!.email ?? "")}`}
                        className="hover:text-brand-600"
                      >
                        {o.orderNumber}
                      </Link>
                    </td>
                    <td className="px-2 py-3 text-ink-600 dark:text-ink-50/65">
                      {new Date(o.createdAt).toLocaleDateString("en-GB")}
                    </td>
                    <td className="px-2 py-3">
                      {ORDER_STATUS_LABEL[o.status] ?? o.status}
                    </td>
                    <td className="px-2 py-3">{o.paymentStatus}</td>
                    <td className="px-2 py-3 text-right font-mono">
                      {formatMoney(Number(o.total))}
                    </td>
                    <td className="px-2 py-3 text-right">
                      <a
                        href={`/api/invoice/${o.orderNumber}`}
                        className="text-[12.5px] font-semibold text-brand-600 hover:underline"
                      >
                        Invoice ↓
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
