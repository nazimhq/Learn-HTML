"use client";

import { useState } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { User } from "lucide-react";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

export default function CustomerLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError("Invalid email or password.");
      return;
    }
    router.push("/account");
    router.refresh();
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-surface px-4">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-7"
      >
        <div className="mb-5 flex flex-col items-center text-center">
          <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 text-ink-50 dark:bg-ink-50 dark:text-ink-900">
            <User size={18} />
          </div>
          <h1 className="font-display text-xl">Sign in to your account</h1>
          <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">
            See your order history, invoices and more.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <div>
            <label className="field-label">Email</label>
            <input
              className="field-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="field-label">Password</label>
            <input
              className="field-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </div>
        {error && (
          <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12.5px] text-red-700">
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={loading}
          className="btn-primary mt-5 w-full"
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>
        <div className="mt-3 flex items-center justify-between text-[12.5px] text-ink-400 dark:text-ink-50/50">
          <Link
            href="/forgot-password"
            className="hover:text-ink-900 dark:hover:text-ink-50"
          >
            Forgot password?
          </Link>
          <Link
            href="/account/register"
            className="hover:text-ink-900 dark:hover:text-ink-50"
          >
            Create an account →
          </Link>
        </div>
        <Link
          href="/checkout"
          className="mt-4 block text-center text-[12px] text-ink-400 dark:text-ink-50/50 hover:text-ink-900 dark:hover:text-ink-50"
        >
          Prefer not to sign in? Checkout as a guest →
        </Link>
      </form>
    </div>
  );
}
