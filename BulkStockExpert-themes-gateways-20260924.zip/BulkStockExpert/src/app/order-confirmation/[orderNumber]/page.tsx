import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import { getOrderForTracking } from "@/lib/order-lookup";
import { formatMoney } from "@/lib/constants";
import { OrderTimeline } from "@/components/order/order-timeline";

export default async function OrderConfirmationPage({
  params: request,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const params = await request;
  const order = await getOrderForTracking(params.orderNumber);
  if (!order) notFound();

  return (
    <div className="container-page max-w-2xl py-12">
      <div className="mb-8 flex flex-col items-center text-center">
        <CheckCircle2 size={44} className="mb-3 text-brand-600" />
        <h1 className="font-display text-2xl">
          Thank you, {order.customerName.split(" ")[0]}!
        </h1>
        <p className="mt-1 text-[13.5px] text-ink-400 dark:text-ink-50/50">
          Order{" "}
          <strong className="font-mono text-ink-900 dark:text-ink-50">
            {order.orderNumber}
          </strong>{" "}
          has been received. Payment status:{" "}
          <strong>{order.paymentStatus}</strong>.
        </p>
      </div>

      {order.paymentStatus !== "PAID" && (
        <p className="mb-4 rounded-lg border p-4">
          Payment is pending. For online payment problems, contact support with
          your order number before placing another order.
        </p>
      )}
      <div className="mb-8 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <OrderTimeline status={order.status} />
      </div>

      <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Order summary
        </h2>
        <div className="flex flex-col gap-2">
          {order.items.map((it, i) => (
            <div
              key={i}
              className="flex items-center justify-between text-[13px]"
            >
              <span className="text-ink-600 dark:text-ink-50/65">
                {it.name}
                {it.variantLabel ? ` (${it.variantLabel})` : ""} × {it.quantity}
              </span>
              <span className="font-mono">
                {formatMoney(
                  Number(it.unitPrice) * it.quantity,
                  order.currency,
                )}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-col gap-1.5 border-t border-ink-900/10 pt-3 font-mono text-[13px]">
          <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
            <span>Subtotal</span>
            <span>{formatMoney(order.subtotal, order.currency)}</span>
          </div>
          <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
            <span>
              Delivery
              {order.deliveryZone ? ` (${order.deliveryZone.name})` : ""}
            </span>
            <span>{formatMoney(order.deliveryCharge, order.currency)}</span>
          </div>
          {Number(order.discount) > 0 && (
            <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
              <span>Discount</span>
              <span>-{formatMoney(order.discount, order.currency)}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-dashed border-ink-900/15 pt-2 text-[15px] font-bold text-ink-900 dark:border-ink-50/15 dark:text-ink-50">
            <span>Total</span>
            <span>{formatMoney(order.total, order.currency)}</span>
          </div>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5 text-[13px] text-ink-600 dark:text-ink-50/65">
        <h2 className="mb-2 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
          Delivering to
        </h2>
        {order.addressLine1}
        {order.addressLine2 ? `, ${order.addressLine2}` : ""}, {order.city}
        {order.county ? `, ${order.county}` : ""}, {order.postcode}
      </div>

      <div className="mt-8 flex justify-center gap-3">
        <Link
          href={`/track-order?order=${order.orderNumber}&email=${encodeURIComponent(order.email)}`}
          className="btn-secondary"
        >
          Track this order
        </Link>
        <Link href="/products" className="btn-primary">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}
