"use client";

import { PaymentBadges } from "@/components/storefront/payment-badges";
import { REGIONS, REGION_NAMES, Region } from "@/lib/gateway-catalog";
import type { CheckoutInput } from "@/app/actions/checkout-actions";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { useCartStore } from "@/store/cart-store";
import { formatMoney, outwardPostcode } from "@/lib/constants";
import {
  placeOrder,
  captureAbandonedCheckout,
} from "@/app/actions/checkout-actions";
import { getOrCreateSessionId, addGuestOrder } from "@/lib/guest-orders";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

const schema = z.object({
  customerName: z.string().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(7, "Enter a valid phone number"),
  addressLine1: z.string().min(3, "Enter your address"),
  addressLine2: z.string().optional(),
  city: z.string().min(2, "Enter your town/city"),
  county: z.string().optional(),
  postcode: z.string().trim().min(2, "Enter your postcode (or 00000 if you don't have one)"),
  customerNote: z.string().optional(),
  couponCode: z.string().optional(),
  paymentMethod: z.enum(["CARD", "PAYPAL", "COD"]),
});

type FormValues = z.infer<typeof schema>;

interface DeliveryZone {
  countryCode: string;
  id: string;
  name: string;
  description: string;
  charge: string;
  freeOverAmount: string | null;
  postcodePrefixes: string[];
  estimatedDays: string;
}

export default function CheckoutPage() {
  const router = useRouter();
  const { lines, subtotal, clear } = useCartStore();
  const [zones, setZones] = useState<DeliveryZone[]>([]);
  const [region, setRegion] = useState<Region>("GB");
  useEffect(() => {
    const saved = localStorage.getItem("checkout-region");
    if (saved && Object.hasOwn(REGIONS, saved)) setRegion(saved as Region);
  }, []);
  const [gateway, setGateway] = useState("cod");
  const [methods, setMethods] = useState<{ id: string; name: string }[]>([]);
  const [rate, setRate] = useState(1);
  const [loadingMethods, setLoadingMethods] = useState(true);
  const money = (value: number) =>
    formatMoney(Math.round(value * rate * 100) / 100, REGIONS[region]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { paymentMethod: "CARD" },
  });

  useEffect(() => {
    const abort = new AbortController();
    setLoadingMethods(true);
    setMethods([]);
    setError("");
    fetch(`/api/payment-methods?region=${region}`, {
      signal: abort.signal,
      cache: "no-store",
    })
      .then(async (r) => {
        const v = await r.json();
        if (!r.ok) throw new Error(v.error);
        return v;
      })
      .then((v) => {
        setMethods(v.methods);
        setRate(v.rate);
        setGateway(v.methods[0]?.id ?? "");
      })
      .catch((e) => {
        if (e.name !== "AbortError") setError(e.message);
      })
      .finally(() => {
        if (!abort.signal.aborted) setLoadingMethods(false);
      });
    return () => abort.abort();
  }, [region]);
  const postcode = watch("postcode") ?? "";
  const watchedFields = watch();
  const sessionIdRef = useRef<string>("");

  useEffect(() => {
    fetch("/api/delivery-zones")
      .then((r) => r.json())
      .then(setZones)
      .catch(() => setZones([]));
  }, []);

  useEffect(() => {
    // Read the live store, not the first-render `lines`: during hydration React renders with
    // the server snapshot (an empty basket), so checking `lines` here bounced every direct
    // visit or refresh of /checkout back to /products even with items in the basket.
    const leaveIfEmpty = () => {
      if (useCartStore.getState().lines.length === 0) router.replace("/products");
    };
    if (useCartStore.persist.hasHydrated()) leaveIfEmpty();
    else return useCartStore.persist.onFinishHydration(leaveIfEmpty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    sessionIdRef.current = getOrCreateSessionId();
  }, []);

  // Real-time lead capture: as soon as the shopper types contact/address details, save a
  // draft server-side (debounced) so we can follow up even if they never finish checking out.
  // Cart contents alone (before any typing) are captured too — that's the "initiate checkout"
  // signal — and every keystroke re-saves the same row rather than creating duplicates.
  useEffect(() => {
    if (lines.length === 0) return;
    const timer = setTimeout(() => {
      const sessionId = sessionIdRef.current;
      if (!sessionId) return;
      captureAbandonedCheckout({
        sessionId,
        name: watchedFields.customerName,
        email: watchedFields.email,
        phone: watchedFields.phone,
        addressLine1: watchedFields.addressLine1,
        addressLine2: watchedFields.addressLine2,
        city: watchedFields.city,
        county: watchedFields.county,
        postcode: watchedFields.postcode,
        itemsSnapshot: lines.map((l) => ({
          name: l.name,
          variantLabel: l.variantLabel,
          qty: l.qty,
          unitPrice: l.price,
        })),
        subtotal: subtotal(),
      }).catch(() => {});
    }, 1200);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    lines.length,
    watchedFields.customerName,
    watchedFields.email,
    watchedFields.phone,
    watchedFields.addressLine1,
    watchedFields.addressLine2,
    watchedFields.city,
    watchedFields.county,
    watchedFields.postcode,
  ]);

  const outward = outwardPostcode(postcode);
  const regionZones = zones.filter((z) => z.countryCode === region);
  const matchedZone =
    regionZones.find((z) =>
      z.postcodePrefixes.some((p) => outward.startsWith(p)),
    ) ?? regionZones.find((z) => z.postcodePrefixes.length === 0);
  const convertedSub = lines.reduce(
    (sum, l) => sum + (Math.round(l.price * rate * 100) / 100) * l.qty,
    0,
  );
  const sub = subtotal();
  const deliveryCharge = matchedZone
    ? matchedZone.freeOverAmount && sub >= Number(matchedZone.freeOverAmount)
      ? 0
      : Number(matchedZone.charge)
    : 0;
  const total = sub + deliveryCharge;

  async function onSubmit(values: FormValues) {
    setSubmitting(true);
    setError("");
    try {
      const result = await placeOrder({
        ...values,
        region,
        gateway: gateway as CheckoutInput["gateway"],
        sessionId: sessionIdRef.current,
        items: lines.map((l) => ({ variantId: l.variantId, qty: l.qty })),
      });
      if (!result.ok) {
        setError(result.message ?? "Something went wrong — please try again.");
        setSubmitting(false);
        return;
      }
      if (result.orderNumber) addGuestOrder(result.orderNumber, values.email);
      clear();
      if (result.redirectUrl) {
        window.location.href = result.redirectUrl;
        return;
      }
      router.push(`/order-confirmation/${result.orderNumber}`);
    } catch {
      setError("Something went wrong placing your order — please try again.");
      setSubmitting(false);
    }
  }

  if (lines.length === 0) return null;

  return (
    <div className="container-page py-8">
      <h1 className="mb-6 font-display text-2xl">Checkout</h1>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="grid gap-10 lg:grid-cols-[1fr_380px]"
      >
        <div className="flex flex-col gap-7">
          <section>
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Contact details
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="field-label">Full name</label>
                <input className="field-input" {...register("customerName")} />
                {errors.customerName && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.customerName.message}
                  </p>
                )}
              </div>
              <div>
                <label className="field-label">Email</label>
                <input
                  className="field-input"
                  type="email"
                  {...register("email")}
                />
                {errors.email && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.email.message}
                  </p>
                )}
              </div>
              <div>
                <label className="field-label">Phone</label>
                <input className="field-input" {...register("phone")} />
                {errors.phone && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.phone.message}
                  </p>
                )}
              </div>
            </div>
          </section>

          <section>
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Delivery address
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="field-label">
                  Country / currency
                  <select
                    className="field-input"
                    value={region}
                    onChange={(e) => {
                      setRegion(e.target.value as Region);
                      localStorage.setItem("checkout-region", e.target.value);
                    }}
                  >
                    {Object.entries(REGIONS).map(([r, c]) => (
                      <option key={r} value={r}>
                        {REGION_NAMES[r as Region]} · {c}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field-label">Address line 1</label>
                <input className="field-input" {...register("addressLine1")} />
                {errors.addressLine1 && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.addressLine1.message}
                  </p>
                )}
              </div>
              <div className="sm:col-span-2">
                <label className="field-label">Address line 2 (optional)</label>
                <input className="field-input" {...register("addressLine2")} />
              </div>
              <div>
                <label className="field-label">Town / City</label>
                <input className="field-input" {...register("city")} />
                {errors.city && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.city.message}
                  </p>
                )}
              </div>
              <div>
                <label className="field-label">County (optional)</label>
                <input className="field-input" {...register("county")} />
              </div>
              <div>
                <label className="field-label">Postcode</label>
                <input
                  className="field-input uppercase"
                  {...register("postcode")}
                />
                {errors.postcode && (
                  <p className="mt-1 text-[12px] text-red-600">
                    {errors.postcode.message}
                  </p>
                )}
              </div>
            </div>

            {!matchedZone && (
              <p role="status" className="mt-3 text-sm">
                Delivery is not configured for this country. Please contact the
                store.
              </p>
            )}
            {matchedZone && (
              <div className="mt-3 rounded-xl border border-brand-500/25 bg-brand-50 px-4 py-3 text-[12.5px] text-brand-700">
                <strong>{matchedZone.name}</strong> — {matchedZone.description}.
                Estimated {matchedZone.estimatedDays}.{" "}
                {deliveryCharge === 0
                  ? "Free delivery."
                  : `${money(deliveryCharge)} delivery.`}
              </div>
            )}

            <div className="mt-4">
              <label className="field-label">Order note (optional)</label>
              <textarea
                className="field-input"
                rows={2}
                {...register("customerNote")}
                placeholder="Delivery instructions, gift note, etc."
              />
            </div>
          </section>

          <section>
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Payment
            </h2>
            <div className="flex flex-col gap-2">
              {methods.map((m) => (
                <label key={m.id} className="flex gap-3 rounded-lg border p-3">
                  <input
                    type="radio"
                    name="gateway"
                    value={m.id}
                    checked={gateway === m.id}
                    onChange={() => setGateway(m.id)}
                  />
                  {m.name}
                </label>
              ))}
            </div>
            {loadingMethods && (
              <p role="status">Loading available payment methods…</p>
            )}
            {!loadingMethods && methods.length === 0 && (
              <p>No payment methods are available for this region.</p>
            )}
          </section>

          <div>
            <label className="field-label flex items-center gap-1.5">
              Coupon code (optional)
              <span className="rounded-full bg-voucher/10 px-1.5 py-0.5 text-[9.5px] font-bold normal-case tracking-normal text-voucher">
                Voucher
              </span>
            </label>
            <input
              className="field-input max-w-[220px] uppercase focus:!border-voucher focus:!ring-voucher/15"
              {...register("couponCode")}
              placeholder="WELCOME10"
            />
          </div>
        </div>

        <aside className="h-fit rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
          <h2 className="mb-3 font-display text-base">Order summary</h2>
          <PaymentBadges />
          <div className="flex flex-col gap-2.5">
            {lines.map((l) => (
              <div
                key={l.variantId}
                className="flex items-center justify-between text-[12.5px]"
              >
                <span className="pr-2 text-ink-600 dark:text-ink-50/65">
                  {l.name}
                  {l.variantLabel ? ` (${l.variantLabel})` : ""} × {l.qty}
                </span>
                <span className="whitespace-nowrap font-mono">
                  {money(l.price) + " × " + l.qty}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-col gap-1.5 border-t border-ink-900/10 pt-3 font-mono text-[13px]">
            <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
              <span>Subtotal</span>
              <span>{formatMoney(convertedSub, REGIONS[region])}</span>
            </div>
            <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
              <span>Delivery</span>
              <span>{matchedZone ? money(deliveryCharge) : "—"}</span>
            </div>
            <div className="flex justify-between border-t border-dashed border-ink-900/15 pt-2 text-[16px] font-bold text-ink-900 dark:border-ink-50/15 dark:text-ink-50">
              <span>Total</span>
              <span>
                {formatMoney(
                  convertedSub + Math.round(deliveryCharge * rate * 100) / 100,
                  REGIONS[region],
                )}
              </span>
            </div>
          </div>

          {error && (
            <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12.5px] text-red-700">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={
              submitting || loadingMethods || !methods.length || !matchedZone
            }
            aria-busy={submitting}
            className="btn-primary mt-4 w-full"
          >
            {submitting
              ? "Placing order..."
              : `Place order — ${formatMoney(convertedSub + Math.round(deliveryCharge * rate * 100) / 100, REGIONS[region])}`}
          </button>
          <Link
            href="/products"
            className="mt-3 block text-center text-[12.5px] text-ink-400 dark:text-ink-50/50 hover:text-ink-900 dark:hover:text-ink-50"
          >
            ← Continue shopping
          </Link>
        </aside>
      </form>
    </div>
  );
}
