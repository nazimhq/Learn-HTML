import Link from "next/link";
import { Truck, ShieldCheck, RotateCcw, Headset } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { HeroSlider } from "@/components/home/hero-slider";
import { PromoBanners } from "@/components/home/promo-banners";
import {
  ProductBrowser,
  type BrowserCategory,
} from "@/components/home/product-browser";
import { PROMO_SLIDES } from "@/config/promo-slides";
import {
  publicProductCardSelect,
  type PublicProductCard,
} from "@/lib/queries/product-select";
import type { ProductCardData } from "@/types";
import { Reveal } from "@/components/motion/reveal";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

function toCardData(p: PublicProductCard): ProductCardData {
  return {
    id: p.id,
    name: p.name,
    slug: p.slug,
    brand: p.brand?.name ?? null,
    basePrice: Number(p.basePrice),
    compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
    imageUrl: p.images[0]?.url ?? "",
    ratingAvg: p.ratingAvg,
    reviewCount: p.reviewCount,
    inStock: p.variants.some((v) => v.stock > 0),
    tags: Array.isArray(p.tags) ? (p.tags as string[]) : [],
    categorySlug: p.category?.slug,
    categoryName: p.category?.name,
    createdAt: p.createdAt?.toISOString(),
  };
}

const PROMO_BANNERS = [
  {
    eyebrow: "Bulk pallet sale",
    title: "Up to 40% off mixed pallets",
    body: "Selected electronics and general merchandise pallets, this week only.",
    ctaLabel: "Shop the sale",
    ctaHref: "/products",
    gradient: ["#5f4d32", "#171310"] as [string, string],
    tag: "deal" as const,
  },
  {
    eyebrow: "New manifested stock",
    title: "Fresh returns lots, added weekly",
    body: "New electronics, home and clothing job lots land regularly — check back often.",
    ctaLabel: "See what's new",
    ctaHref: "/products?sort=newest",
    gradient: ["#946f2f", "#241f19"] as [string, string],
    tag: "combo" as const,
  },
];

async function getCategories(): Promise<BrowserCategory[]> {
  try {
    const rows = await prisma.category.findMany({
      orderBy: { position: "asc" },
      select: {
        id: true,
        name: true,
        slug: true,
        imageUrl: true,
        _count: { select: { products: { where: { status: "ACTIVE" } } } },
      } as never,
    });
    return (
      rows as unknown as {
        id: string;
        name: string;
        slug: string;
        imageUrl: string | null;
        _count: { products: number };
      }[]
    ).map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      imageUrl: c.imageUrl,
      count: c._count.products,
    }));
  } catch {
    return [];
  }
}

async function getProducts() {
  try {
    const rows = await prisma.product.findMany({
      where: { status: "ACTIVE" },
      select: publicProductCardSelect,
      orderBy: { createdAt: "desc" },
      // The pallet browser shows an initial 16-20 and reveals the rest client-side on "See
      // More" — 60 comfortably covers a "browse everything on the homepage" experience
      // without needing a separate paginated endpoint.
      take: 60,
    });
    return rows as PublicProductCard[];
  } catch {
    // DB not migrated/seeded yet, or the Prisma client failed to initialize — render the shell.
    return [] as PublicProductCard[];
  }
}

export default async function HomePage() {
  const [categories, rows] = await Promise.all([
    getCategories(),
    getProducts(),
  ]);
  const products: ProductCardData[] = rows.map(toCardData);

  return (
    <div>
      <section className="relative overflow-hidden bg-ink-900">
        <div
          className="hero-pattern absolute inset-0 opacity-25"
          style={{
            backgroundImage:
              "repeating-linear-gradient(115deg, rgba(201,161,90,0.5) 0 1px, transparent 1px 64px)",
          }}
        />
        <div className="container-page relative grid gap-10 py-20 sm:grid-cols-2 sm:py-28">
          <div className="flex flex-col justify-center">
            <span className="mb-4 font-mono text-[11.5px] uppercase tracking-[0.16em] text-accent-400">
              Genuine returns stock
            </span>
            <h1 className="hero-title font-display text-[clamp(34px,5vw,54px)] leading-[1.05] text-ink-50">
              Customer-return pallets,{" "}
              <em className="text-accent-400 not-italic">sold direct</em> across
              the UK.
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-ink-100/70">
              Electronics, home, clothing and general merchandise — manifested
              lots at trade prices, delivered nationwide.
            </p>
            <div className="mt-8 flex gap-3">
              <Link href="/products" className="btn-primary">
                Shop pallets
              </Link>
              <Link
                href="/products?sort=newest"
                className="btn-secondary !border-ink-50/25 !text-ink-50 hover:!border-ink-50/60"
              >
                New stock
              </Link>
            </div>
          </div>
          <div className="sm:flex sm:items-center sm:justify-center">
            <HeroSlider slides={PROMO_SLIDES} />
          </div>
        </div>
      </section>

      <PromoBanners banners={PROMO_BANNERS} />

      <ProductBrowser categories={categories} products={products} />

      <section className="border-y border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel">
        <div className="container-page grid grid-cols-2 gap-6 py-8 sm:grid-cols-4">
          {[
            {
              icon: Truck,
              title: "Nationwide delivery",
              body: "UK-wide courier & pallet network",
            },
            {
              icon: Headset,
              title: "Real support",
              body: "We're here to help with your order",
            },
            {
              icon: ShieldCheck,
              title: "Secure payment",
              body: "Card and PayPal, fully encrypted",
            },
            {
              icon: RotateCcw,
              title: "Buyer protection",
              body: "Accurate manifests, every listing",
            },
          ].map((f, i) => (
            <Reveal key={f.title} delay={i * 70}>
              <div className="flex items-start gap-3">
                <f.icon
                  size={20}
                  className="mt-0.5 flex-shrink-0 text-accent-600"
                />
                <div>
                  <p className="text-[13.5px] font-semibold text-ink-900 dark:text-ink-50">
                    {f.title}
                  </p>
                  <p className="text-[12.5px] text-ink-400 dark:text-ink-50/50">
                    {f.body}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="border-t border-ink-900/10 bg-surface-alt py-10 dark:border-ink-50/10">
        <Reveal className="container-page text-center">
          <p className="text-[13.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Trusted by UK resellers and small businesses
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-ink-400/70 dark:text-ink-50/40">
            <span className="text-[13px] font-medium">Verified manifests</span>
            <span className="text-[13px] font-medium">Nationwide delivery</span>
            <span className="text-[13px] font-medium">Secure payments</span>
            <span className="text-[13px] font-medium">Buyer protection</span>
            <span className="text-[13px] font-medium">
              Repeat-buyer discounts
            </span>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
