import { notFound } from "next/navigation";
import { getContentPage } from "@/app/actions/admin-content-actions";

// Same reasoning as src/app/contact/page.tsx: force fresh data every request so an admin's edit
// to a content page shows up immediately, with no risk of a stale build-time snapshot being
// served forever.
export const dynamic = "force-dynamic";

export default async function ContentPageRoute({
  params: request,
}: {
  params: Promise<{ slug: string }>;
}) {
  const params = await request;
  const page = await getContentPage(params.slug);
  if (!page) notFound();

  const paragraphs = page.body
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <div className="container-page max-w-2xl py-14">
      <h1 className="mb-6 font-display text-3xl text-ink-900 dark:text-ink-50">
        {page.title}
      </h1>
      <div className="flex flex-col gap-4 text-[14.5px] leading-relaxed text-ink-600 dark:text-ink-50/80">
        {paragraphs.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>
    </div>
  );
}
