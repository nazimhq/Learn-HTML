"use client";

import { useState } from "react";
import Link from "next/link";
import { signIn, getSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Lock } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });
    if (res?.error) {
      setLoading(false);
      setError("Invalid email or password.");
      return;
    }

    // This same credentials provider also signs in customer accounts (see lib/auth.ts) — an
    // admin-panel sign-in must only succeed for an ADMIN-role user.
    const session = await getSession();
    if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN") {
      await signOut({ redirect: false });
      setLoading(false);
      setError("This account doesn't have admin access.");
      return;
    }
    setLoading(false);
    router.push("/admin");
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-surface px-4">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-7"
      >
        <div className="mb-5 flex flex-col items-center text-center">
          <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 text-ink-50">
            <Lock size={18} />
          </div>
          <h1 className="font-display text-xl">Admin sign in</h1>
          <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">
            BulkStockExpert Ltd store management
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <div>
            <label className="field-label">Email</label>
            <input
              className="field-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="field-label">Password</label>
            <input
              className="field-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </div>
        {error && (
          <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12.5px] text-red-700">
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={loading}
          className="btn-primary mt-5 w-full"
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>
        <Link
          href="/forgot-password"
          className="mt-3 block text-center text-[12.5px] text-ink-400 dark:text-ink-50/50 hover:text-ink-900 dark:hover:text-ink-50"
        >
          Forgot password?
        </Link>
      </form>
    </div>
  );
}
