import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatMoney, ORDER_STATUS_LABEL } from "@/lib/constants";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

const STATUSES = ["PENDING", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"];

interface OrderRow {
  id: string;
  orderNumber: string;
  currency: string;
  customerName: string;
  email: string;
  city: string;
  postcode: string;
  total: number | { toString(): string };
  status: string;
  paymentStatus: string;
  createdAt: Date;
}

export default async function AdminOrdersPage({
  searchParams: request,
}: {
  searchParams: Promise<{ status?: string; q?: string }>;
}) {
  const searchParams = await request;
  // Only real statuses filter (anything else shows all orders instead of a database error).
  const status = (STATUSES as readonly string[]).includes(searchParams.status ?? "")
    ? searchParams.status
    : undefined;
  const q = (searchParams.q ?? "").trim().slice(0, 80);
  // Wrapped in try/catch (matching the pattern used across the admin section, e.g.
  // src/app/admin/page.tsx) so a transient DB hiccup shows a friendly message here instead of
  // the generic Next.js "server-side exception" crash page.
  let orders: OrderRow[] = [];
  let loadError = false;
  try {
    orders = await prisma.order.findMany({
      where: {
        ...(status ? { status: status as never } : {}),
        ...(q
          ? {
              OR: [
                { orderNumber: { contains: q.toUpperCase() } },
                { email: { contains: q.toLowerCase() } },
                { customerName: { contains: q } },
                { phone: { contains: q } },
              ],
            }
          : {}),
      },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        currency: true,
        orderNumber: true,
        customerName: true,
        email: true,
        city: true,
        postcode: true,
        total: true,
        status: true,
        paymentStatus: true,
        createdAt: true,
      },
    });
  } catch (err) {
    console.error("AdminOrdersPage: failed to load orders:", err);
    loadError = true;
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl">Orders</h1>
        <form action="/admin/orders" className="flex gap-2" role="search">
          {status && <input type="hidden" name="status" value={status} />}
          <label className="sr-only" htmlFor="order-search">
            Search orders
          </label>
          <input
            id="order-search"
            name="q"
            defaultValue={q}
            placeholder="Order no., email, name or phone"
            className="field-input !w-64"
          />
          <button className="btn-secondary !px-4 !py-2">Search</button>
        </form>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        <Link
          href="/admin/orders"
          className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-medium ${!searchParams.status ? "bg-ink-900 text-ink-50" : "border border-ink-900/15"}`}
        >
          All
        </Link>
        {STATUSES.map((s) => (
          <Link
            key={s}
            href={`/admin/orders?status=${s}`}
            className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-medium ${searchParams.status === s ? "bg-ink-900 text-ink-50" : "border border-ink-900/15"}`}
          >
            {ORDER_STATUS_LABEL[s]}
          </Link>
        ))}
      </div>

      {loadError && (
        <div className="mb-4 rounded-2xl border border-ink-900/10 bg-white p-6 text-[13.5px] text-ink-500 dark:border-ink-50/10 dark:bg-panel dark:text-ink-50/70">
          Couldn&apos;t load orders just now — this is usually a brief hiccup
          talking to the database. Try refreshing the page in a moment.
        </div>
      )}

      <div className="overflow-x-auto rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel">
        <table className="w-full text-left text-[13px]">
          <thead>
            <tr className="border-b border-ink-900/10 text-[11px] uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Payment</th>
              <th className="px-4 py-3 text-right">Total</th>
              <th className="px-4 py-3">Placed</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr
                key={o.id}
                className="border-b border-ink-900/5 last:border-none hover:bg-ink-50 dark:border-ink-50/5 dark:hover:bg-ink-50/5"
              >
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/orders/${o.id}`}
                    className="font-mono font-medium hover:text-brand-600"
                  >
                    {o.orderNumber}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  {o.customerName}
                  <br />
                  <span className="text-[11.5px] text-ink-400 dark:text-ink-50/50">
                    {o.email}
                  </span>
                </td>
                <td className="px-4 py-3">
                  {o.city}, {o.postcode}
                </td>
                <td className="px-4 py-3">
                  {ORDER_STATUS_LABEL[o.status] ?? o.status}
                </td>
                <td className="px-4 py-3">{o.paymentStatus}</td>
                <td className="px-4 py-3 text-right font-mono">
                  {formatMoney(o.total, o.currency)}
                </td>
                <td className="px-4 py-3 text-[11.5px] text-ink-400 dark:text-ink-50/50">
                  {new Date(o.createdAt).toLocaleDateString("en-GB")}
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-10 text-center text-ink-400 dark:text-ink-50/50"
                >
                  No orders in this view yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
