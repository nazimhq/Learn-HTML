import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/constants";
import { OrderStatusControls } from "@/components/admin/order-status-controls";

export default async function AdminOrderDetailPage({
  params: request,
}: {
  params: Promise<{ id: string }>;
}) {
  const params = await request;
  // Explicit select (rather than a bare include, which still implicitly asks for every
  // scalar field this generated Prisma client knows about — including Order.userId /
  // .paymentReference, new fields added to prisma/schema.prisma) so this page can't 500 with
  // PrismaClientKnownRequestError P2022 if those columns aren't on the live table yet. Only
  // the fields this page actually renders are listed.
  let order;
  try {
    order = await prisma.order.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        orderNumber: true,
        currency: true,
        status: true,
        paymentStatus: true,
        paymentMethod: true,
        trackingCarrier: true,
        trackingNumber: true,
        customerName: true,
        email: true,
        phone: true,
        addressLine1: true,
        addressLine2: true,
        city: true,
        county: true,
        postcode: true,
        country: true,
        customerNote: true,
        adminNote: true,
        subtotal: true,
        discount: true,
        total: true,
        deliveryCharge: true,
        createdAt: true,
        deliveryZone: { select: { name: true } },
        items: {
          select: {
            id: true,
            name: true,
            variantLabel: true,
            quantity: true,
            unitPrice: true,
            costPriceAtTime: true,
          },
        },
        activity: {
          orderBy: { createdAt: "asc" },
          select: { id: true, message: true, createdAt: true },
        },
      },
    });
  } catch (err) {
    console.error("AdminOrderDetailPage: failed to load order:", err);
    order = null;
  }
  if (!order) notFound();

  const totalCost = order.items.reduce(
    (s, it) => s + Number(it.costPriceAtTime ?? 0) * it.quantity,
    0,
  );
  const margin = Number(order.subtotal) - totalCost;

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <h1 className="font-display text-2xl">{order.orderNumber}</h1>
        <span className="text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Placed {new Date(order.createdAt).toLocaleString("en-GB")}
        </span>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="flex flex-col gap-5">
          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Items
            </h2>
            <div className="flex flex-col gap-2">
              {order.items.map((it) => (
                <div
                  key={it.id}
                  className="flex items-center justify-between text-[13px]"
                >
                  <span className="text-ink-600 dark:text-ink-50/65">
                    {it.name}
                    {it.variantLabel ? ` (${it.variantLabel})` : ""} ×{" "}
                    {it.quantity}
                  </span>
                  <span className="font-mono">
                    {formatMoney(Number(it.unitPrice) * it.quantity)}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-col gap-1.5 border-t border-ink-900/10 pt-3 font-mono text-[13px]">
              <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
                <span>Subtotal</span>
                <span>{formatMoney(order.subtotal, order.currency)}</span>
              </div>
              <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
                <span>
                  Delivery
                  {order.deliveryZone ? ` (${order.deliveryZone.name})` : ""}
                </span>
                <span>{formatMoney(order.deliveryCharge, order.currency)}</span>
              </div>
              {Number(order.discount) > 0 && (
                <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
                  <span>Discount</span>
                  <span>-{formatMoney(order.discount, order.currency)}</span>
                </div>
              )}
              <div className="flex justify-between border-t border-dashed border-ink-900/15 pt-2 text-[15px] font-bold">
                <span>Total</span>
                <span>{formatMoney(order.total, order.currency)}</span>
              </div>
            </div>
            <div className="mt-4 rounded-lg bg-ink-50 px-3.5 py-2.5 font-mono text-[12.5px] dark:bg-ink-900/60">
              <div className="flex justify-between text-ink-400 dark:text-ink-50/50">
                <span>Cost of goods (admin only)</span>
                <span>{formatMoney(totalCost)}</span>
              </div>
              <div className="flex justify-between font-semibold text-emerald-700">
                <span>Gross margin</span>
                <span>{formatMoney(margin)}</span>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Update &amp; notify
            </h2>
            <OrderStatusControls
              orderId={order.id}
              currentStatus={order.status}
              currentPaymentStatus={order.paymentStatus}
              trackingCarrier={order.trackingCarrier}
              trackingNumber={order.trackingNumber}
            />
          </div>

          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Activity log
            </h2>
            <ul className="flex flex-col gap-2.5">
              {order.activity.map((a) => (
                <li key={a.id} className="text-[12.5px]">
                  <span className="text-ink-800 dark:text-ink-50/90">
                    {a.message}
                  </span>{" "}
                  <span className="text-ink-400 dark:text-ink-50/50">
                    — {new Date(a.createdAt).toLocaleString("en-GB")}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-5">
          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Customer
            </h2>
            <p className="text-[13px] font-medium">{order.customerName}</p>
            <p className="text-[12.5px] text-ink-400 dark:text-ink-50/50">
              {order.email}
            </p>
            <p className="text-[12.5px] text-ink-400 dark:text-ink-50/50">
              {order.phone}
            </p>
          </div>
          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Delivery address
            </h2>
            <p className="text-[13px] text-ink-600 dark:text-ink-50/65">
              {order.addressLine1}
              {order.addressLine2 ? `, ${order.addressLine2}` : ""}
              <br />
              {order.city}
              {order.county ? `, ${order.county}` : ""}
              <br />
              {order.postcode}
              <br />
              {order.country}
            </p>
            {order.customerNote && (
              <p className="mt-3 rounded-lg bg-ink-50 px-3 py-2 text-[12px] text-ink-600 dark:bg-ink-900/60 dark:text-ink-50/65">
                <strong>Note:</strong> {order.customerNote}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
