import { listContentPages } from "@/app/actions/admin-content-actions";
import { ContentPagesForm } from "@/components/admin/content-pages-form";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

export default async function AdminContentPage() {
  const pages = await listContentPages();

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">Content pages</h1>
      <p className="mb-5 text-[13px] text-ink-400 dark:text-ink-50/50">
        Edit the text shown on your About, Terms &amp; Conditions, Privacy
        Policy and Returns &amp; Refunds pages — linked from the site footer at{" "}
        <code>/pages/about</code>, <code>/pages/terms</code>,{" "}
        <code>/pages/privacy</code> and <code>/pages/returns</code>.
      </p>
      {pages.length === 0 ? (
        <p className="rounded-xl border border-dashed border-ink-900/20 p-4 text-[13px] text-ink-400 dark:border-ink-50/20 dark:text-ink-50/50">
          No content pages found yet — run <code>migration-part4-cms.sql</code>{" "}
          against the database to create the ContentPage table and seed the four
          default pages, then refresh this page.
        </p>
      ) : (
        <ContentPagesForm pages={pages} />
      )}
    </div>
  );
}
