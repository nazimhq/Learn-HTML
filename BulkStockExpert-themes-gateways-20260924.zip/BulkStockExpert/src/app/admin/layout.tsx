import { headers } from "next/headers";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { prisma } from "@/lib/prisma";

async function getSiteName(): Promise<string | undefined> {
  try {
    const settings = await prisma.appSettings.findUnique({
      where: { id: "singleton" },
      select: { siteName: true },
    });
    return settings?.siteName;
  } catch {
    return undefined;
  }
}

// On this host, `getServerSession()` has been observed to hang indefinitely under heavy
// CPU/process contention (shared cPanel hosting with tight CloudLinux LVE limits), which
// turns every /admin/* request into a LiteSpeed "Request Timeout" if we wait on it
// unconditionally. Race it against a short timeout so a stuck lookup degrades gracefully
// instead of hanging the whole request.
function getSessionSafe() {
  // No try/catch here: Next.js signals "this route must render dynamically" during
  // static generation by throwing a special internal error out of cookies()/headers()
  // (which getServerSession uses under the hood) — swallowing that would make this page
  // look statically prerenderable when it isn't, breaking the build. We only want to
  // race a slow *successful* resolution against a timeout, not intercept errors.
  return Promise.race([
    getServerSession(authOptions),
    new Promise<null>((resolve) => setTimeout(() => resolve(null), 4000)),
  ]);
}

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // middleware.ts stamps every request it lets through (i.e. every /admin/* route except
  // /admin/login, which its matcher skips entirely) with this header. That's a much
  // cheaper/faster check than getServerSession() on this host, and — unlike the session
  // lookup — never hangs, so we use it as the source of truth for "should the sidebar
  // show at all". Previously this layout hid the whole sidebar whenever getServerSession()
  // merely timed out (common under this host's CPU contention), which made an otherwise
  // fully logged-in admin land on a real admin page with NO navigation at all — the exact
  // "I can't find any of these features in the admin panel" symptom reported 2026-09-17.
  const isAuthenticatedAdminRoute =
    (await headers()).get("x-admin-authenticated") === "1";
  if (!isAuthenticatedAdminRoute) return <>{children}</>;

  const [session, siteName] = await Promise.all([
    getSessionSafe(),
    getSiteName(),
  ]);
  // Session details (display name, Super Admin flag) are a nice-to-have here, not a gate —
  // middleware already proved this request is a valid ADMIN. Fall back gracefully rather
  // than hiding the sidebar if the session lookup itself is what's slow/timed out.
  const userName = session?.user?.name ?? session?.user?.email ?? "Admin";
  const isSuperAdmin = (session?.user as { isSuperAdmin?: boolean } | undefined)
    ?.isSuperAdmin;

  return (
    <div className="flex min-h-screen bg-surface">
      <AdminSidebar
        userName={userName}
        isSuperAdmin={isSuperAdmin}
        siteName={siteName}
      />
      <div className="min-w-0 flex-1 p-6 sm:p-8">{children}</div>
    </div>
  );
}
