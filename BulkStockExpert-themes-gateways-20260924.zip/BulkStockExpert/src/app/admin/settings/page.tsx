import { prisma } from "@/lib/prisma";
import { SettingsForm } from "@/components/admin/settings-form";
import { getBrandingSettings } from "@/app/actions/admin-settings-actions";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

interface PaymentSettingsRow {
  codEnabled: boolean;
  cardEnabled: boolean;
  stripePublishableKey: string | null;
  stripeSecretKey: string | null;
  stripeWebhookSecret: string | null;
  paypalEnabled: boolean;
  paypalClientId: string | null;
  paypalClientSecret: string | null;
  paypalMode: string;
}

async function getPaymentSettings(): Promise<PaymentSettingsRow> {
  const fallback: PaymentSettingsRow = {
    codEnabled: true,
    cardEnabled: false,
    stripePublishableKey: null,
    stripeSecretKey: null,
    stripeWebhookSecret: null,
    paypalEnabled: false,
    paypalClientId: null,
    paypalClientSecret: null,
    paypalMode: "sandbox",
  };
  try {
    // Cast: PaymentSettings is a new Prisma model (see prisma/schema.prisma) not yet in this
    // sandbox's stale generated Prisma client (src/lib/prisma.ts).
    const row = await (
      prisma as unknown as {
        paymentSettings: {
          findUnique: (a: unknown) => Promise<PaymentSettingsRow | null>;
        };
      }
    ).paymentSettings.findUnique({ where: { id: "singleton" } });
    return row ?? fallback;
  } catch {
    return fallback;
  }
}

// Resilient against a DB whose live schema hasn't caught up with every column this Prisma
// Client (generated from prisma/schema.prisma) now expects — e.g. a migration file that adds
// a new AppSettings column was written but not yet run against the live MySQL database. An
// unscoped findUnique() selects every scalar field the client knows about, so a single missing
// column throws a PrismaClientKnownRequestError (P2022) and previously took down the whole
// page. Falling back to null here lets the page render with defaults instead of crashing —
// matching the same defensive pattern already used below for payments/branding.
async function getSiteSettings() {
  try {
    return await prisma.appSettings.findUnique({ where: { id: "singleton" } });
  } catch (err) {
    console.error("AdminSettingsPage: appSettings.findUnique failed:", err);
    return null;
  }
}

export default async function AdminSettingsPage() {
  const [settings, zones, paymentSettings, branding] = await Promise.all([
    getSiteSettings(),
    prisma.deliveryZone
      .findMany({ orderBy: { position: "asc" } })
      .catch((err) => {
        console.error("AdminSettingsPage: deliveryZone.findMany failed:", err);
        return [];
      }),
    getPaymentSettings(),
    getBrandingSettings(),
  ]);

  return (
    <div>
      <h1 className="mb-5 font-display text-2xl">Delivery &amp; Settings</h1>
      <SettingsForm
        initialSettings={{
          siteName: settings?.siteName ?? "BulkStockExpert Ltd",
          tagline: settings?.tagline ?? "",
          contactEmail: settings?.contactEmail ?? "",
          contactPhone: settings?.contactPhone ?? "",
          adminNotificationEmail: settings?.adminNotificationEmail ?? "",
          vatRate: settings?.vatRate?.toString() ?? "20",
          pricesIncludeVat: settings?.pricesIncludeVat ?? true,
          freeShippingOverAmount:
            settings?.freeShippingOverAmount?.toString() ?? null,
        }}
        initialTracking={{
          metaPixelId: settings?.metaPixelId ?? "",
          gaMeasurementId: settings?.gaMeasurementId ?? "",
          gtmContainerId: settings?.gtmContainerId ?? "",
          whatsappNumber: settings?.whatsappNumber ?? "",
        }}
        initialTheme={{
          // Cast: Prisma client in this sandbox is generated from an older schema snapshot
          // (see src/lib/prisma.ts) so these fields aren't in its types yet — they exist on
          // the live row once the matching MySQL columns are added.
          accentTheme: ((settings as { accentTheme?: string } | null)
            ?.accentTheme ?? "red") as
            "red" | "maroon" | "gold" | "yellow" | "black" | "purple",
          colorMode: ((settings as { colorMode?: string } | null)?.colorMode ??
            "light") as "light" | "dark",
        }}
        initialZones={zones.map((z) => ({
          id: z.id,
          countryCode: z.countryCode,
          name: z.name,
          description: z.description,
          charge: z.charge.toString(),
          freeOverAmount: z.freeOverAmount?.toString() ?? null,
          postcodePrefixes: Array.isArray(z.postcodePrefixes)
            ? z.postcodePrefixes.filter(
                (v): v is string => typeof v === "string",
              )
            : [],
          estimatedDays: z.estimatedDays,
          isActive: z.isActive,
        }))}
        initialPayments={{
          codEnabled: paymentSettings.codEnabled,
          cardEnabled: paymentSettings.cardEnabled,
          stripePublishableKey: "",
          stripeSecretKey: "",
          stripeWebhookSecret: "",
          paypalEnabled: paymentSettings.paypalEnabled,
          paypalClientId: "",
          paypalClientSecret: "",
          paypalMode:
            (paymentSettings.paypalMode as "sandbox" | "live") ?? "sandbox",
        }}
        initialBranding={{
          logoUrl: branding.logoUrl ?? null,
          facebookUrl: branding.facebookUrl ?? "",
          instagramUrl: branding.instagramUrl ?? "",
          tiktokUrl: branding.tiktokUrl ?? "",
        }}
      />
    </div>
  );
}
