import Link from "next/link";
import { UserRound } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/constants";
import { CustomerActiveToggle } from "@/components/admin/customer-active-toggle";

export const dynamic = "force-dynamic";

export default async function CustomersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const q = ((await searchParams).q ?? "").trim().slice(0, 80);
  let loadError = false;
  const customers = await prisma.user
    .findMany({
      where: {
        role: "CUSTOMER",
        ...(q ? { OR: [{ email: { contains: q.toLowerCase() } }, { name: { contains: q } }] } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: { id: true, name: true, email: true, isActive: true, createdAt: true },
    })
    .catch((err) => {
      console.error("CustomersPage failed:", err);
      loadError = true;
      return [];
    });

  // Orders are matched by account or by email (guest orders placed before signing up).
  const emails = customers.map((c) => c.email.toLowerCase());
  const orders = emails.length
    ? await prisma.order
        .findMany({
          where: { OR: [{ userId: { in: customers.map((c) => c.id) } }, { email: { in: emails } }], status: { not: "CANCELLED" } },
          select: { userId: true, email: true, total: true, currency: true, createdAt: true },
        })
        .catch(() => [])
    : [];
  const stats = new Map<string, { count: number; totals: Record<string, number>; last: Date | null }>();
  for (const c of customers) stats.set(c.id, { count: 0, totals: {}, last: null });
  for (const o of orders) {
    const c = customers.find((x) => x.id === o.userId || x.email.toLowerCase() === o.email.toLowerCase());
    if (!c) continue;
    const s = stats.get(c.id)!;
    s.count++;
    s.totals[o.currency] = (s.totals[o.currency] ?? 0) + Number(o.total);
    if (!s.last || o.createdAt > s.last) s.last = o.createdAt;
  }

  return (
    <div className="max-w-6xl">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="flex items-center gap-2 font-display text-2xl">
          <UserRound size={22} /> Customers
        </h1>
        <form action="/admin/customers" className="flex gap-2" role="search">
          <label className="sr-only" htmlFor="customer-search">Search customers</label>
          <input id="customer-search" name="q" defaultValue={q} placeholder="Name or email" className="field-input !w-60" />
          <button className="btn-secondary !px-4 !py-2">Search</button>
        </form>
      </div>
      {loadError && <p role="alert" className="mb-4 text-[13px]">Couldn&apos;t load customers just now. Please refresh.</p>}
      <div className="overflow-x-auto rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel">
        <table className="w-full min-w-[720px] text-left text-[13px]">
          <thead className="border-b border-ink-900/10 text-[11.5px] uppercase tracking-wide text-ink-400 dark:border-ink-50/10 dark:text-ink-50/50">
            <tr>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Joined</th>
              <th className="px-4 py-3 text-right">Orders</th>
              <th className="px-4 py-3 text-right">Spent</th>
              <th className="px-4 py-3">Last order</th>
              <th className="px-4 py-3">Login</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-900/5 dark:divide-ink-50/10">
            {customers.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-ink-400">
                  {q ? "No customers match that search." : "No customer accounts yet."}
                </td>
              </tr>
            )}
            {customers.map((c) => {
              const s = stats.get(c.id)!;
              return (
                <tr key={c.id}>
                  <td className="px-4 py-3">
                    <p className="font-medium">{c.name}</p>
                    <p className="text-[12px] text-ink-400 dark:text-ink-50/50">{c.email}</p>
                  </td>
                  <td className="px-4 py-3">{c.createdAt.toLocaleDateString("en-GB")}</td>
                  <td className="px-4 py-3 text-right">
                    {s.count > 0 ? (
                      <Link className="underline" href={`/admin/orders?q=${encodeURIComponent(c.email)}`}>{s.count}</Link>
                    ) : (
                      0
                    )}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-[12.5px]">
                    {Object.entries(s.totals).map(([cur, t]) => <div key={cur}>{formatMoney(t, cur)}</div>)}
                    {s.count === 0 && "—"}
                  </td>
                  <td className="px-4 py-3">{s.last ? s.last.toLocaleDateString("en-GB") : "—"}</td>
                  <td className="px-4 py-3">
                    <CustomerActiveToggle id={c.id} isActive={c.isActive} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
