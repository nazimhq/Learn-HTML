import Link from "next/link";
import {
  Package,
  CheckCircle2,
  Clock,
  Truck,
  RefreshCcw,
  XCircle,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatMoney, ORDER_STATUS_LABEL } from "@/lib/constants";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; admin data needs to be live on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

/** Reads ?from=&to= (yyyy-mm-dd) from the URL — the date-range filter's "Load" button just
 * navigates to /admin?from=...&to=..., so this page (a Server Component) can re-query with no
 * client-side state needed. Defaults to the last 30 days when neither is given. */
function resolveRange(searchParams: { from?: string; to?: string }) {
  const now = new Date();
  const to = searchParams.to ? new Date(`${searchParams.to}T23:59:59`) : now;
  const from = searchParams.from
    ? new Date(`${searchParams.from}T00:00:00`)
    : new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  return { from, to };
}

function toDateInputValue(d: Date) {
  return d.toISOString().slice(0, 10);
}

interface StatusTotals {
  count: number;
  sum: number;
}

/** Loads everything the dashboard needs in 3 queries total instead of the 14 separate
 * count()/aggregate() round-trips the first version of this page made (one pair per status).
 * That original version worked fine in testing but turned out to crash intermittently in
 * production on this host's constrained shared hosting — 14 queries fired at once via
 * Promise.all is a lot of concurrent DB round-trips for a low-resource box, and it produced a
 * genuine (if inconsistent) "server-side exception" on /admin. groupBy() gets every status's
 * count + revenue sum in one query. Also wrapped in try/catch, matching this codebase's
 * established pattern (see getSettings()/getBrandingSettings() elsewhere), so a transient DB
 * hiccup shows a friendly inline message instead of crashing the whole page. */
async function loadDashboardData(dateFilter: {
  createdAt: { gte: Date; lte: Date };
  currency: string;
}) {
  try {
    const [grouped, lowStockVariants, recentOrders] = await Promise.all([
      prisma.order.groupBy({
        by: ["status"],
        where: dateFilter,
        _count: { _all: true },
        _sum: { total: true },
      }),
      prisma.productVariant.findMany({
        where: { stock: { gt: 0 } },
        select: { stock: true, lowStockAt: true },
      }),
      prisma.order.findMany({
        where: dateFilter,
        orderBy: { createdAt: "desc" },
        take: 8,
        select: {
          id: true,
          orderNumber: true,
          customerName: true,
          total: true,
          status: true,
          createdAt: true,
        },
      }),
    ]);

    const byStatus: Record<string, StatusTotals> = {};
    let totalCount = 0;
    let totalSum = 0;
    for (const g of grouped) {
      const count = g._count._all;
      const sum = Number(g._sum.total ?? 0);
      byStatus[g.status] = { count, sum };
      totalCount += count;
      totalSum += sum;
    }

    const lowStockCount = lowStockVariants.filter(
      (v) => v.stock <= v.lowStockAt,
    ).length;
    return {
      ok: true as const,
      totalCount,
      totalSum,
      byStatus,
      lowStockCount,
      recentOrders,
    };
  } catch (err) {
    console.error("Dashboard data load failed:", err);
    return { ok: false as const };
  }
}

export default async function AdminDashboardPage({
  searchParams: request,
}: {
  searchParams: Promise<{ from?: string; to?: string; currency?: string }>;
}) {
  const searchParams = await request;
  const { from, to } = resolveRange(searchParams);
  const currency = ["GBP", "USD", "CAD", "BDT"].includes(
    searchParams.currency ?? "",
  )
    ? searchParams.currency!
    : "GBP";
  const dateFilter = { createdAt: { gte: from, lte: to }, currency };
  const data = await loadDashboardData(dateFilter);

  const filterForm = (
    <form className="mb-6 flex flex-wrap items-end gap-2.5 rounded-2xl border border-ink-900/10 bg-white p-4 dark:border-ink-50/10 dark:bg-panel">
      <label>
        Report currency
        <select className="field-input" name="currency" defaultValue={currency}>
          {["GBP", "USD", "CAD", "BDT"].map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </label>
      <div>
        <label className="field-label">From</label>
        <input
          type="date"
          name="from"
          defaultValue={toDateInputValue(from)}
          className="field-input"
        />
      </div>
      <div>
        <label className="field-label">To</label>
        <input
          type="date"
          name="to"
          defaultValue={toDateInputValue(to)}
          className="field-input"
        />
      </div>
      <button type="submit" className="btn-primary !px-5 !py-2 text-[12.5px]">
        Load
      </button>
    </form>
  );

  if (!data.ok) {
    return (
      <div>
        <h1 className="mb-5 font-display text-2xl">Dashboard</h1>
        {filterForm}
        <div className="rounded-2xl border border-ink-900/10 bg-white p-6 text-[13.5px] text-ink-500 dark:border-ink-50/10 dark:bg-panel dark:text-ink-50/70">
          Couldn&apos;t load the dashboard stats just now — this is usually a
          brief hiccup talking to the database. Try refreshing the page in a
          moment. Orders and other admin pages are unaffected.
        </div>
      </div>
    );
  }

  const { totalCount, totalSum, byStatus, lowStockCount, recentOrders } = data;
  const cancelledCount = byStatus.CANCELLED?.count ?? 0;
  const cancelPct =
    totalCount > 0 ? Math.round((cancelledCount / totalCount) * 100) : 0;

  const cards = [
    {
      label: "Total orders",
      count: totalCount,
      amount: totalSum,
      icon: Package,
      color: "bg-blue-500/15 text-blue-600",
    },
    {
      label: "Delivered",
      count: byStatus.DELIVERED?.count ?? 0,
      amount: byStatus.DELIVERED?.sum ?? 0,
      icon: CheckCircle2,
      color: "bg-success/15 text-success",
    },
    {
      label: "Pending",
      count: byStatus.PENDING?.count ?? 0,
      amount: byStatus.PENDING?.sum ?? 0,
      icon: Clock,
      color: "bg-amber-500/15 text-amber-600",
    },
    {
      label: "Processing",
      count: byStatus.PROCESSING?.count ?? 0,
      amount: byStatus.PROCESSING?.sum ?? 0,
      icon: RefreshCcw,
      color: "bg-cyan-500/15 text-cyan-600",
    },
    {
      label: "Shipped",
      count: byStatus.SHIPPED?.count ?? 0,
      amount: byStatus.SHIPPED?.sum ?? 0,
      icon: Truck,
      color: "bg-purple-500/15 text-purple-600",
    },
    {
      label: "Cancelled",
      count: cancelledCount,
      amount: byStatus.CANCELLED?.sum ?? 0,
      icon: XCircle,
      color: "bg-discount/15 text-discount",
      suffix: totalCount > 0 ? ` (${cancelPct}%)` : "",
    },
  ];

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl">Dashboard</h1>
        {lowStockCount > 0 && (
          <span className="rounded-full bg-amber-500/15 px-3 py-1 text-[12px] font-semibold text-amber-700">
            {lowStockCount} low-stock variant{lowStockCount === 1 ? "" : "s"}
          </span>
        )}
      </div>

      {filterForm}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {cards.map((c) => (
          <div
            key={c.label}
            className="flex items-center justify-between rounded-2xl border border-ink-900/10 bg-white p-4 dark:border-ink-50/10 dark:bg-panel"
          >
            <div className="flex items-center gap-3">
              <span
                className={`flex h-9 w-9 items-center justify-center rounded-full ${c.color}`}
              >
                <c.icon size={17} />
              </span>
              <div>
                <p className="text-[12px] text-ink-400 dark:text-ink-50/50">
                  {c.label}
                </p>
                <p className="font-mono text-xl font-bold text-ink-900 dark:text-ink-50">
                  {c.count}
                  {c.suffix ?? ""}
                </p>
              </div>
            </div>
            <p className="font-mono text-[13.5px] font-semibold text-ink-600 dark:text-ink-50/70">
              {formatMoney(c.amount, currency)}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-base">Recent orders</h2>
          <Link
            href="/admin/orders"
            className="text-[12.5px] font-semibold text-brand-600 hover:underline"
          >
            View all →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px]">
            <thead>
              <tr className="text-[11px] uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
                <th className="pb-2">Order</th>
                <th className="pb-2">Customer</th>
                <th className="pb-2">Status</th>
                <th className="pb-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((o) => (
                <tr key={o.id} className="border-t border-ink-900/5">
                  <td className="py-2.5">
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="font-mono font-medium hover:text-brand-600"
                    >
                      {o.orderNumber}
                    </Link>
                  </td>
                  <td className="py-2.5">{o.customerName}</td>
                  <td className="py-2.5">
                    <StatusPill status={o.status} />
                  </td>
                  <td className="py-2.5 text-right font-mono">
                    {formatMoney(o.total, currency)}
                  </td>
                </tr>
              ))}
              {recentOrders.length === 0 && (
                <tr>
                  <td
                    colSpan={4}
                    className="py-8 text-center text-ink-400 dark:text-ink-50/50"
                  >
                    No orders in this date range.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const colors: Record<string, string> = {
    PENDING: "bg-accent-500/15 text-accent-700",
    PROCESSING: "bg-blue-100 text-blue-700",
    SHIPPED: "bg-purple-100 text-purple-700",
    DELIVERED: "bg-emerald-100 text-emerald-700",
    CANCELLED: "bg-red-100 text-red-700",
  };
  return (
    <span
      className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${colors[status] ?? ""}`}
    >
      {ORDER_STATUS_LABEL[status] ?? status}
    </span>
  );
}
