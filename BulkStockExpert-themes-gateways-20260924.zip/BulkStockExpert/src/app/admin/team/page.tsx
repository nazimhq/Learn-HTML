import { listAdmins } from "@/app/actions/admin-team-actions";
import { TeamManagerForm } from "@/components/admin/team-manager-form";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

export default async function AdminTeamPage() {
  const admins = await listAdmins();

  if (admins === null) {
    return (
      <div>
        <h1 className="mb-1 font-display text-2xl">Team</h1>
        <p className="text-[12.5px] text-ink-400 dark:text-ink-50/50">
          Only a Super Admin can view or manage admin accounts. Ask a Super
          Admin to give you access if you need it.
        </p>
      </div>
    );
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">Team</h1>
      <p className="mb-5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        Add another Gmail address as an admin, and choose whether they&apos;re a
        regular Admin or a Super Admin. Super Admins can also manage this Team
        page; regular Admins can&apos;t.
      </p>
      <TeamManagerForm initialAdmins={admins} />
    </div>
  );
}
