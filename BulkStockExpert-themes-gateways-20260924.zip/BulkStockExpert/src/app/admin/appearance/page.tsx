import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { DesignThemesManager } from "@/components/admin/design-themes-manager";
import { getBaseLook, getRotationConfig } from "@/lib/site-theme-server";
import { resolveTheme } from "@/lib/site-theme";

export const dynamic = "force-dynamic";

export default async function AppearancePage() {
  const session = await getServerSession(authOptions);
  if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN") redirect("/admin/login");

  const cfg = await getRotationConfig();
  const base = await getBaseLook(cfg);
  const active = resolveTheme(base, cfg);

  return (
    <DesignThemesManager
      migrated={cfg !== null || (await tableExists())}
      initial={{
        skin: base.skin,
        accent: base.accent,
        mode: base.mode,
        rotationEnabled: cfg?.rotationEnabled ?? false,
        rotationMode: cfg?.rotationMode === "schedule" ? "schedule" : "interval",
        rotationHours: cfg?.rotationHours ?? 6,
        timezone: cfg?.timezone ?? "UTC",
        slots: cfg?.slots.length
          ? cfg.slots
          : [
              { skin: "classic", accent: base.accent, mode: "light", at: "08:00" },
              { skin: "nexaweb", accent: "purple", mode: "dark", at: "18:00" },
            ],
      }}
      active={active}
    />
  );
}

async function tableExists() {
  const { prisma } = await import("@/lib/prisma");
  try {
    await prisma.siteTheme.count();
    return true;
  } catch {
    return false;
  }
}
