import { prisma } from "@/lib/prisma";
import { CategoryManagerForm } from "@/components/admin/category-manager-form";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

async function getCategories() {
  try {
    const rows = await prisma.category.findMany({
      orderBy: { position: "asc" },
      include: { _count: { select: { products: true } } },
    });
    return rows.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      position: c.position,
      // Cast: Category.imageUrl is a new field (see prisma/schema.prisma) not yet in this
      // sandbox's stale generated Prisma client (src/lib/prisma.ts).
      imageUrl: (c as unknown as { imageUrl?: string | null }).imageUrl ?? null,
      productCount: c._count.products,
    }));
  } catch {
    return [];
  }
}

export default async function AdminCategoriesPage() {
  const categories = await getCategories();

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">Categories</h1>
      <p className="mb-5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        These power the category row on your homepage, the header/footer shop
        links, and the product filters. Upload a square logo image for each one
        — categories without a logo fall back to a generic icon.
      </p>
      <CategoryManagerForm initialCategories={categories} />
    </div>
  );
}
