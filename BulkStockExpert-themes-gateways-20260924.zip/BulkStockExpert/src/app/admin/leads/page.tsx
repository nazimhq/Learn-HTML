import { prisma } from "@/lib/prisma";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

interface LeadItem {
  name: string;
  variantLabel?: string | null;
  qty: number;
  unitPrice: number;
}

interface Lead {
  id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  addressLine1: string | null;
  addressLine2: string | null;
  city: string | null;
  county: string | null;
  postcode: string | null;
  itemsSnapshot: string;
  subtotal: unknown;
  stage: string;
  updatedAt: Date;
}

async function getLeads(): Promise<Lead[]> {
  try {
    // Cast: AbandonedCheckout is a new model (see prisma/schema.prisma) not yet in this
    // sandbox's stale generated Prisma client (src/lib/prisma.ts).
    return await (
      prisma as unknown as {
        abandonedCheckout: { findMany: (a: unknown) => Promise<Lead[]> };
      }
    ).abandonedCheckout.findMany({
      where: { convertedOrderId: null },
      orderBy: { updatedAt: "desc" },
      take: 200,
    });
  } catch {
    return [];
  }
}

function formatAddress(l: Lead): string {
  return [l.addressLine1, l.addressLine2, l.city, l.county, l.postcode]
    .filter(Boolean)
    .join(", ");
}

export default async function AdminLeadsPage() {
  const leads = await getLeads();
  const started = leads.filter((l) => l.stage === "CHECKOUT_STARTED");
  const cartOnly = leads.filter((l) => l.stage !== "CHECKOUT_STARTED");

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">
        Leads &amp; abandoned checkouts
      </h1>
      <p className="mb-5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        Anyone who added items to their basket or started typing checkout
        details but didn&apos;t finish placing an order — saved automatically so
        you can follow up. Rows drop off this list the moment they do complete
        an order.
      </p>

      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4">
          <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            With contact details
          </p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
            {started.length}
          </p>
        </div>
        <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-4">
          <p className="text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Basket only, no details yet
          </p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-ink-900 dark:text-ink-50">
            {cartOnly.length}
          </p>
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel">
        <table className="w-full text-left text-[13px]">
          <thead>
            <tr className="border-b border-ink-900/10 text-[11px] uppercase tracking-wide text-ink-400 dark:border-ink-50/10 dark:text-ink-50/50">
              <th className="px-4 py-3">Contact</th>
              <th className="px-4 py-3">Address</th>
              <th className="px-4 py-3">Basket</th>
              <th className="px-4 py-3 text-right">Value</th>
              <th className="px-4 py-3">Last activity</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((l) => {
              let items: LeadItem[] = [];
              try {
                items = JSON.parse(l.itemsSnapshot || "[]");
              } catch {
                items = [];
              }
              return (
                <tr
                  key={l.id}
                  className="border-b border-ink-900/5 last:border-none dark:border-ink-50/5"
                >
                  <td className="px-4 py-3">
                    <p className="font-medium">
                      {l.name || (
                        <span className="text-ink-400 dark:text-ink-50/50">
                          Unknown name
                        </span>
                      )}
                    </p>
                    {l.email && (
                      <p className="text-[12px] text-ink-400 dark:text-ink-50/50">
                        {l.email}
                      </p>
                    )}
                    {l.phone && (
                      <p className="text-[12px] text-ink-400 dark:text-ink-50/50">
                        {l.phone}
                      </p>
                    )}
                  </td>
                  <td className="px-4 py-3 text-[12.5px] text-ink-600 dark:text-ink-50/65">
                    {formatAddress(l) || "—"}
                  </td>
                  <td className="px-4 py-3 text-[12.5px] text-ink-600 dark:text-ink-50/65">
                    {items.length === 0
                      ? "—"
                      : items.map((it, i) => (
                          <div key={i}>
                            {it.name}
                            {it.variantLabel
                              ? ` (${it.variantLabel})`
                              : ""} × {it.qty}
                          </div>
                        ))}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">
                    £{Number(l.subtotal ?? 0).toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-[11.5px] text-ink-400 dark:text-ink-50/50">
                    {new Date(l.updatedAt).toLocaleString("en-GB")}
                  </td>
                </tr>
              );
            })}
            {leads.length === 0 && (
              <tr>
                <td
                  colSpan={5}
                  className="px-4 py-10 text-center text-ink-400 dark:text-ink-50/50"
                >
                  No unfinished checkouts yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
