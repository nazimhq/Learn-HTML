import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatMoney } from "@/lib/constants";

// See src/app/admin/page.tsx for why this is forced dynamic.
export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      variants: { select: { stock: true, price: true, costPrice: true } },
      category: { select: { name: true } },
    },
  });

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <h1 className="font-display text-2xl">Products</h1>
        <Link
          href="/admin/products/new"
          className="btn-primary !px-4 !py-2 text-[13px]"
        >
          <Plus size={15} /> Add product
        </Link>
      </div>
      <div className="overflow-x-auto rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel">
        <table className="w-full text-left text-[13px]">
          <thead>
            <tr className="border-b border-ink-900/10 text-[11px] uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Price</th>
              <th className="px-4 py-3 text-right">Margin</th>
              <th className="px-4 py-3 text-right">Stock</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              const stock = p.variants.reduce((s, v) => s + v.stock, 0);
              const avgCost = p.variants.length
                ? p.variants.reduce((s, v) => s + Number(v.costPrice ?? 0), 0) /
                  p.variants.length
                : 0;
              const margin =
                avgCost > 0
                  ? Math.round(
                      ((Number(p.basePrice) - avgCost) / Number(p.basePrice)) *
                        100,
                    )
                  : null;
              return (
                <tr
                  key={p.id}
                  className="border-b border-ink-900/5 last:border-none hover:bg-ink-50 dark:border-ink-50/5 dark:hover:bg-ink-50/5"
                >
                  <td className="px-4 py-3 font-medium">{p.name}</td>
                  <td className="px-4 py-3 text-ink-400 dark:text-ink-50/50">
                    {p.category.name}
                  </td>
                  <td className="px-4 py-3">{p.status}</td>
                  <td className="px-4 py-3 text-right font-mono">
                    {formatMoney(p.basePrice)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-emerald-700">
                    {margin !== null ? `${margin}%` : "—"}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">
                    {stock === 0 ? (
                      <span className="text-red-600">0</span>
                    ) : (
                      stock
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link
                      href={`/admin/products/${p.id}`}
                      className="text-[12.5px] font-semibold text-brand-600 hover:underline"
                    >
                      Edit
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-[12px] text-ink-400 dark:text-ink-50/50">
        Margin is admin-only — computed from the hidden purchase cost you set
        per variant and never shown to customers.
      </p>
    </div>
  );
}
