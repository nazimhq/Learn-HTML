import { prisma } from "@/lib/prisma";
import { ProductCreateForm } from "@/components/admin/product-create-form";

async function getCategories() {
  try {
    const rows = await prisma.category.findMany({
      orderBy: { position: "asc" },
      select: { id: true, name: true },
    });
    return rows;
  } catch {
    return [];
  }
}

export default async function NewProductPage() {
  const categories = await getCategories();

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">Add a product</h1>
      <p className="mb-5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        Creates a live product with a single default variant — upload photos,
        set your price and stock, then publish. You can add extra variants or
        edit any of this afterwards from the product&apos;s edit page.
      </p>
      <ProductCreateForm categories={categories} />
    </div>
  );
}
