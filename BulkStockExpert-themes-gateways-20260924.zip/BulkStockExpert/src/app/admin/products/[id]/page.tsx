import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ProductEditForm } from "@/components/admin/product-edit-form";
import { ProductExtras } from "@/components/admin/product-extras";

export default async function AdminProductEditPage({
  params: request,
}: {
  params: Promise<{ id: string }>;
}) {
  const params = await request;
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      variants: { orderBy: { label: "asc" } },
      images: { orderBy: [{ position: "asc" }, { id: "asc" }] },
    },
  });
  if (!product) notFound();
  const categories = await prisma.category
    .findMany({ orderBy: { position: "asc" }, select: { id: true, name: true } })
    .catch(() => []);

  return (
    <div>
      <h1 className="mb-5 font-display text-2xl">{product.name}</h1>
      <ProductEditForm
        productId={product.id}
        initial={{
          name: product.name,
          description: product.description,
          basePrice: product.basePrice.toString(),
          compareAtPrice: product.compareAtPrice?.toString() ?? null,
          costPrice: product.costPrice?.toString() ?? null,
          status: product.status,
        }}
        variants={product.variants.map((v) => ({
          id: v.id,
          sku: v.sku,
          label: v.label,
          price: v.price.toString(),
          compareAtPrice: v.compareAtPrice?.toString() ?? null,
          costPrice: v.costPrice?.toString() ?? null,
          stock: v.stock,
          lowStockAt: v.lowStockAt,
        }))}
      />
      <ProductExtras
        productId={product.id}
        productSlug={product.slug}
        categoryId={product.categoryId}
        categories={categories}
        images={product.images.map((i) => ({ id: i.id, url: i.url, altText: i.altText }))}
        variants={product.variants.map((v) => ({ id: v.id, label: v.label, sku: v.sku, stock: v.stock }))}
      />
    </div>
  );
}
