import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { REGIONS, REGION_NAMES, type Region } from "@/lib/gateway-catalog";
import { CurrencyRatesForm } from "@/components/admin/currency-rates-form";

export const dynamic = "force-dynamic";

export default async function CurrenciesPage() {
  const session = await getServerSession(authOptions);
  if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN") redirect("/admin/login");

  const rows = await prisma.currencyRate.findMany().catch(() => null);
  const byCode = new Map((rows ?? []).map((r) => [r.code, r]));
  const currencies = Array.from(new Set(Object.values(REGIONS)))
    .filter((c) => c !== "GBP")
    .map((code) => {
      const regions = (Object.keys(REGIONS) as Region[]).filter((r) => REGIONS[r] === code);
      const row = byCode.get(code);
      const env = Number(process.env[`FX_GBP_${code}`]);
      return {
        code,
        countries: regions.map((r) => REGION_NAMES[r]).join(", "),
        saved: row ? Number(row.rate).toString() : "",
        updatedAt: row?.updatedAt.toISOString() ?? null,
        envRate: Number.isFinite(env) && env > 0 ? env : null,
      };
    });

  return <CurrencyRatesForm currencies={currencies} migrated={rows !== null} />;
}
