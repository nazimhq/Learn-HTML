import { getAllReviews } from "@/app/actions/admin-review-actions";
import { ReviewsManager } from "@/components/admin/reviews-manager";

// See src/app/admin/page.tsx for why admin pages are forced dynamic on this host.
export const dynamic = "force-dynamic";

export default async function AdminReviewsPage() {
  const reviews = await getAllReviews();

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl">Reviews</h1>
      <p className="mb-5 text-[12.5px] text-ink-400 dark:text-ink-50/50">
        Customer reviews publish immediately when submitted. Edit, unpublish or
        delete any review here — the product&apos;s star rating and review count
        update automatically to match.
      </p>
      <ReviewsManager initialReviews={reviews} />
    </div>
  );
}
