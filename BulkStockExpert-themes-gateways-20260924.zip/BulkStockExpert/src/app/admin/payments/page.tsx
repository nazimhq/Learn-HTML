import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { GatewayManager } from "@/components/admin/gateway-manager";
export const dynamic = "force-dynamic";
export default async function PaymentsPage() {
  const session = await getServerSession(authOptions);
  if (session?.user?.role !== "ADMIN") redirect("/admin/login");
  try {
    const rows = await prisma.gatewayConfig.findMany({
      select: { id: true, enabled: true, mode: true },
    });
    return <GatewayManager initial={rows} />;
  } catch {
    return (
      <div role="alert">
        Payment configuration is unavailable. Apply the database migration and
        regenerate Prisma before configuring providers.
      </div>
    );
  }
}
