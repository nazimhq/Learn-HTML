import { prisma } from "@/lib/prisma";
import { CouponManager } from "@/components/admin/coupon-manager";

// Admin routes are protected by src/middleware.ts; actions re-check the session.
export const dynamic = "force-dynamic";

export default async function CouponsPage() {
  const coupons = await prisma.coupon
    .findMany({ orderBy: { code: "asc" }, include: { _count: { select: { orders: true } } } })
    .catch(() => []);
  return (
    <CouponManager
      coupons={coupons.map((c) => ({
        id: c.id,
        code: c.code,
        type: c.type,
        value: Number(c.value),
        minSubtotal: c.minSubtotal == null ? null : Number(c.minSubtotal),
        expiresAt: c.expiresAt ? c.expiresAt.toISOString().slice(0, 10) : null,
        isActive: c.isActive,
        uses: c._count.orders,
      }))}
    />
  );
}
