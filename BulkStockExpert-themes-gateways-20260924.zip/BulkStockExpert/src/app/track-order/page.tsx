"use client";

import { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Search, Truck } from "lucide-react";
import { formatMoney } from "@/lib/constants";
import { OrderTimeline } from "@/components/order/order-timeline";
import { getGuestOrders, type GuestOrderRef } from "@/lib/guest-orders";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

interface TrackedOrder {
  orderNumber: string;
  currency: string;
  status: string;
  customerName: string;
  deliveryZone: { name: string; estimatedDays: string } | null;
  deliveryCharge: string;
  subtotal: string;
  discount: string;
  total: string;
  trackingNumber: string | null;
  trackingCarrier: string | null;
  createdAt: string;
  items: {
    name: string;
    variantLabel: string | null;
    quantity: number;
    unitPrice: string;
  }[];
  activity: { message: string; createdAt: string }[];
}

function TrackOrderInner() {
  const searchParams = useSearchParams();
  const [orderNumber, setOrderNumber] = useState(
    searchParams.get("order") ?? "",
  );
  const [email, setEmail] = useState(searchParams.get("email") ?? "");
  const [order, setOrder] = useState<TrackedOrder | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [guestOrders, setGuestOrders] = useState<GuestOrderRef[]>([]);

  useEffect(() => {
    setGuestOrders(getGuestOrders());
  }, []);

  async function lookup(
    e?: React.FormEvent,
    overrideOrder?: string,
    overrideEmail?: string,
  ) {
    e?.preventDefault();
    const useOrder = overrideOrder ?? orderNumber;
    const useEmail = overrideEmail ?? email;
    if (!useOrder || !useEmail) return;
    if (overrideOrder) setOrderNumber(overrideOrder);
    if (overrideEmail) setEmail(overrideEmail);
    return lookupOrder(useOrder, useEmail);
  }

  async function lookupOrder(useOrder: string, useEmail: string) {
    setLoading(true);
    setError("");
    setOrder(null);
    try {
      const res = await fetch(
        `/api/track-order?order=${encodeURIComponent(useOrder)}&email=${encodeURIComponent(useEmail)}`,
      );
      const json = await res.json();
      if (!res.ok) {
        setError(json.error ?? "Order not found.");
        return;
      }
      setOrder(json);
    } catch {
      setError("Something went wrong — please try again.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (searchParams.get("order") && searchParams.get("email")) lookup();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="container-page max-w-xl py-12">
      <div className="mb-8 text-center">
        <Truck size={32} className="mx-auto mb-2 text-brand-600" />
        <h1 className="font-display text-2xl">Track your order</h1>
        <p className="mt-1 text-[13px] text-ink-400 dark:text-ink-50/50">
          Enter your order number and the email you used at checkout.
        </p>
      </div>

      {guestOrders.length > 0 && (
        <div className="mb-5">
          <p className="mb-2 text-[11.5px] font-semibold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
            Your recent orders (this browser)
          </p>
          <div className="flex flex-wrap gap-2">
            {guestOrders.map((g) => (
              <button
                key={g.orderNumber}
                onClick={() => lookup(undefined, g.orderNumber, g.email)}
                className="rounded-full border border-ink-900/15 px-3 py-1.5 font-mono text-[12px] font-medium hover:border-brand-500 hover:text-brand-600 dark:border-ink-50/15"
              >
                {g.orderNumber}
              </button>
            ))}
          </div>
        </div>
      )}

      <form
        onSubmit={lookup}
        className="flex flex-col gap-3 rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5"
      >
        <div>
          <label className="field-label">Order number</label>
          <input
            className="field-input uppercase"
            placeholder="BRM-100001"
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
          />
        </div>
        <div>
          <label className="field-label">Email</label>
          <input
            className="field-input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="btn-primary mt-1 justify-center"
        >
          <Search size={15} /> {loading ? "Searching..." : "Track order"}
        </button>
        {error && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-[12.5px] text-red-700">
            {error}
          </p>
        )}
      </form>

      <p className="mt-3 text-center text-[12px] text-ink-400 dark:text-ink-50/50">
        Want your full order history saved to an account?{" "}
        <Link
          href="/account/register"
          className="font-semibold text-brand-600 hover:underline"
        >
          Create one →
        </Link>
      </p>

      {order && (
        <div className="mt-6 flex flex-col gap-5">
          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <div className="mb-4 flex items-center justify-between">
              <span className="font-mono text-[13px] font-semibold">
                {order.orderNumber}
              </span>
              <div className="flex items-center gap-3">
                <span className="text-[12px] text-ink-400 dark:text-ink-50/50">
                  {new Date(order.createdAt).toLocaleDateString("en-GB")}
                </span>
                <a
                  href={`/api/invoice/${order.orderNumber}?email=${encodeURIComponent(email)}`}
                  className="text-[12px] font-semibold text-brand-600 hover:underline"
                >
                  Invoice ↓
                </a>
              </div>
            </div>
            <OrderTimeline status={order.status} />
            {order.trackingNumber && (
              <p className="mt-4 text-[12.5px] text-ink-600 dark:text-ink-50/65">
                Carrier: <strong>{order.trackingCarrier}</strong> · Tracking
                number:{" "}
                <strong className="font-mono">{order.trackingNumber}</strong>
              </p>
            )}
          </div>

          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Timeline
            </h2>
            <ul className="flex flex-col gap-3">
              {order.activity.map((a, i) => (
                <li key={i} className="flex gap-3 text-[12.5px]">
                  <span className="mt-0.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-brand-500" />
                  <div>
                    <p className="text-ink-800 dark:text-ink-50/90">
                      {a.message}
                    </p>
                    <p className="text-[11px] text-ink-400 dark:text-ink-50/50">
                      {new Date(a.createdAt).toLocaleString("en-GB")}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-ink-900/10 bg-white dark:border-ink-50/10 dark:bg-panel p-5">
            <h2 className="mb-3 text-[13px] font-bold uppercase tracking-wide text-ink-400 dark:text-ink-50/50">
              Items
            </h2>
            <div className="flex flex-col gap-2">
              {order.items.map((it, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between text-[13px]"
                >
                  <span className="text-ink-600 dark:text-ink-50/65">
                    {it.name}
                    {it.variantLabel ? ` (${it.variantLabel})` : ""} ×{" "}
                    {it.quantity}
                  </span>
                  <span className="font-mono">
                    {formatMoney(
                      Number(it.unitPrice) * it.quantity,
                      order.currency,
                    )}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-3 flex justify-between border-t border-dashed border-ink-900/15 pt-2 text-[14.5px] font-bold">
              <span>Total</span>
              <span className="font-mono">
                {formatMoney(order.total, order.currency)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function TrackOrderPage() {
  return (
    <Suspense fallback={null}>
      <TrackOrderInner />
    </Suspense>
  );
}
