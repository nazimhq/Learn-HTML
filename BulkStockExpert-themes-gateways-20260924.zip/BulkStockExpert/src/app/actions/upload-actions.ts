"use server";

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import crypto from "crypto";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

const ALLOWED_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};
const MAX_BYTES = 5 * 1024 * 1024; // 5MB

export interface UploadResult {
  ok: boolean;
  url?: string;
  message?: string;
}

/**
 * Saves an admin-uploaded image (category logo, product photo, etc.) to disk under
 * public/uploads/<subfolder>/ and returns its public URL. Files land on the same
 * persistent filesystem the Node app itself runs from (this is a long-running Passenger
 * process on shared cPanel hosting, not a serverless/ephemeral runtime), so anything
 * written here is served by Next's normal static file handling on the next request —
 * no separate object-storage setup needed.
 */
export async function uploadImage(
  formData: FormData,
  subfolder: "categories" | "products" | "branding",
): Promise<UploadResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }

  const file = formData.get("file");
  if (!(file instanceof File))
    return { ok: false, message: "No file received." };
  if (file.size === 0) return { ok: false, message: "That file is empty." };
  if (file.size > MAX_BYTES)
    return { ok: false, message: "Image must be 5MB or smaller." };

  const ext = ALLOWED_TYPES[file.type];
  if (!ext)
    return {
      ok: false,
      message: "Please upload a JPG, PNG, WEBP or GIF image.",
    };

  try {
    const dir = path.join(process.cwd(), "public", "uploads", subfolder);
    await mkdir(dir, { recursive: true });
    const filename = `${crypto.randomUUID()}.${ext}`;
    const bytes = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(dir, filename), bytes);
    return { ok: true, url: `/uploads/${subfolder}/${filename}` };
  } catch (err) {
    console.error("uploadImage failed:", err);
    return {
      ok: false,
      message: "Something went wrong saving that image — please try again.",
    };
  }
}
