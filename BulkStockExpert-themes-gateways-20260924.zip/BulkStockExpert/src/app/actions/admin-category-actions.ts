"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

export interface CategoryActionResult {
  ok: boolean;
  message?: string;
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export async function createCategory(data: {
  name: string;
  slug?: string;
  imageUrl?: string | null;
}): Promise<CategoryActionResult> {
  await requireAdmin();
  const name = data.name.trim();
  if (name.length < 2) return { ok: false, message: "Enter a category name." };
  const slug = slugify(data.slug || name);
  if (!slug)
    return {
      ok: false,
      message:
        "Couldn't work out a URL slug from that name — try adding one manually.",
    };

  const existing = await prisma.category.findUnique({ where: { slug } });
  if (existing)
    return {
      ok: false,
      message: `A category with the slug "${slug}" already exists.`,
    };

  const count = await prisma.category.count();
  await prisma.category.create({
    // Cast: Category.imageUrl is a new field (see prisma/schema.prisma) not yet in this
    // sandbox's stale generated Prisma client (src/lib/prisma.ts).
    data: {
      name,
      slug,
      position: count,
      imageUrl: data.imageUrl || null,
    } as never,
  });

  revalidatePath("/admin/categories");
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function updateCategory(
  id: string,
  data: {
    name: string;
    slug: string;
    position: number;
    imageUrl?: string | null;
  },
): Promise<CategoryActionResult> {
  await requireAdmin();
  const name = data.name.trim();
  const slug = slugify(data.slug || name);
  if (name.length < 2 || !slug)
    return { ok: false, message: "Category needs a name and a slug." };

  const clash = await prisma.category.findFirst({
    where: { slug, NOT: { id } },
  });
  if (clash)
    return {
      ok: false,
      message: `Another category already uses the slug "${slug}".`,
    };

  await prisma.category.update({
    where: { id },
    data: {
      name,
      slug,
      position: data.position,
      ...(data.imageUrl !== undefined
        ? ({ imageUrl: data.imageUrl } as never)
        : {}),
    },
  });

  revalidatePath("/admin/categories");
  revalidatePath("/", "layout");
  revalidatePath("/products");
  return { ok: true };
}

export async function deleteCategory(
  id: string,
): Promise<CategoryActionResult> {
  await requireAdmin();
  const productCount = await prisma.product.count({
    where: { categoryId: id },
  });
  if (productCount > 0) {
    return {
      ok: false,
      message: `Move or delete the ${productCount} product(s) in this category first.`,
    };
  }
  await prisma.category.delete({ where: { id } });
  revalidatePath("/admin/categories");
  revalidatePath("/", "layout");
  return { ok: true };
}
