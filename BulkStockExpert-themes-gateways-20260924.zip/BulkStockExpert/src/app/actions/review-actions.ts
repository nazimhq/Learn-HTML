"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  productId: z.string().min(1, "Missing product."),
  productSlug: z.string().min(1, "Missing product."),
  customerName: z.string().trim().min(2, "Please enter your name"),
  // z.coerce.number() on an empty/blank string produces NaN, which then silently fails a
  // plain .min()/.max() check with a confusing generic message — catch that explicitly first
  // so an unrated review says "Please select a star rating" instead of a NaN-related error.
  rating: z
    .string()
    .optional()
    .transform((v) => Number(v))
    .refine((n) => Number.isInteger(n) && n >= 1 && n <= 5, {
      message: "Please select a star rating",
    }),
  email: z
    .string()
    .trim()
    .email("Enter a valid email")
    .optional()
    .or(z.literal("")),
  comment: z
    .string()
    .trim()
    .min(2, "Please enter a review (at least 2 characters)")
    .max(2000),
});

export interface ReviewFormState {
  ok: boolean;
  message: string;
}

/** Recomputes Product.ratingAvg/reviewCount from its currently-APPROVED reviews — called after
 *  any review is created, edited, (un)published or deleted, so the public rating never drifts
 *  out of sync with what's actually visible on the storefront. */
export async function recomputeProductRating(productId: string) {
  const agg = await prisma.review.aggregate({
    where: { productId, status: "APPROVED" },
    _avg: { rating: true },
    _count: { _all: true },
  });
  await prisma.product.update({
    where: { id: productId },
    data: {
      ratingAvg: agg._avg.rating ?? 0,
      reviewCount: agg._count._all,
    },
  });
}

export async function submitReview(
  _prev: ReviewFormState,
  formData: FormData,
): Promise<ReviewFormState> {
  const parsed = schema.safeParse({
    productId: formData.get("productId"),
    productSlug: formData.get("productSlug"),
    customerName: formData.get("customerName"),
    rating: formData.get("rating"),
    email: formData.get("email") ?? "",
    comment: formData.get("comment"),
  });

  if (!parsed.success) {
    return {
      ok: false,
      message:
        parsed.error.issues[0]?.message ??
        "Please check the form and try again.",
    };
  }

  try {
    // Reviews publish immediately (status APPROVED) so the customer sees their own review and
    // the product's rating updates right away — admins can still edit, unpublish or delete any
    // review afterwards from Admin → Reviews.
    await prisma.review.create({
      data: {
        productId: parsed.data.productId,
        customerName: parsed.data.customerName,
        email: parsed.data.email?.toLowerCase() || null,
        rating: parsed.data.rating,
        comment: parsed.data.comment,
        status: "PENDING",
      },
    });
    await recomputeProductRating(parsed.data.productId);
  } catch (err) {
    console.error("submitReview failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong submitting your review — please try again.",
    };
  }

  revalidatePath(`/products/${parsed.data.productSlug}`);
  return { ok: true, message: "Thanks! Your review is awaiting moderation." };
}
