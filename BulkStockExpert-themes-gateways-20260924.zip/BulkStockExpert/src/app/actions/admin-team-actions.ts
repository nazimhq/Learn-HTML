"use server";

import crypto from "crypto";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// `isSuperAdmin` is a newer column that this project's deployed environments may not have
// migrated yet, so every read/write here goes through raw SQL rather than the typed Prisma
// client — see auth-actions.ts for the same pattern (and why) with PasswordResetToken.

async function requireSuperAdmin(): Promise<{ id: string }> {
  const session = await getServerSession(authOptions);
  const user = session?.user as
    { id?: string; role?: string; isSuperAdmin?: boolean } | undefined;
  if (!session || !user?.id || user.role !== "ADMIN" || !user.isSuperAdmin) {
    throw new Error("Only a Super Admin can manage admin accounts.");
  }
  return { id: user.id };
}

export interface AdminAccount {
  id: string;
  name: string;
  email: string;
  isSuperAdmin: boolean;
  isActive: boolean;
  createdAt: string;
}

export interface TeamActionResult {
  ok: boolean;
  message?: string;
}

/** Returns null (rather than throwing) when the caller isn't a Super Admin, so the page can render a friendly message. */
export async function listAdmins(): Promise<AdminAccount[] | null> {
  try {
    await requireSuperAdmin();
  } catch {
    return null;
  }
  const rows = await prisma.$queryRaw<
    Array<{
      id: string;
      name: string;
      email: string;
      isSuperAdmin: number;
      isActive: number;
      createdAt: Date;
    }>
  >`SELECT id, name, email, isSuperAdmin, isActive, createdAt FROM \`User\` WHERE role = 'ADMIN' ORDER BY createdAt ASC`;
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    email: r.email,
    isSuperAdmin: !!r.isSuperAdmin,
    isActive: !!r.isActive,
    createdAt: new Date(r.createdAt).toISOString(),
  }));
}

const createAdminSchema = z.object({
  name: z.string().min(2, "Enter a name"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  isSuperAdmin: z.boolean().default(false),
});

export async function createAdminUser(
  input: z.infer<typeof createAdminSchema>,
): Promise<TeamActionResult> {
  try {
    await requireSuperAdmin();
  } catch {
    return { ok: false, message: "Only a Super Admin can add admin accounts." };
  }

  const parsed = createAdminSchema.safeParse(input);
  if (!parsed.success)
    return {
      ok: false,
      message: parsed.error.issues[0]?.message ?? "Please check the form.",
    };
  const { name, email, password, isSuperAdmin } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing)
    return { ok: false, message: "An account with that email already exists." };

  const id = crypto.randomUUID();
  const passwordHash = await bcrypt.hash(password, 10);
  try {
    await prisma.$executeRaw`
      INSERT INTO \`User\` (\`id\`, \`name\`, \`email\`, \`passwordHash\`, \`role\`, \`isSuperAdmin\`, \`isActive\`, \`createdAt\`, \`updatedAt\`)
      VALUES (${id}, ${name}, ${email}, ${passwordHash}, 'ADMIN', ${isSuperAdmin ? 1 : 0}, 1, NOW(3), NOW(3))
    `;
  } catch (err) {
    console.error("createAdminUser failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong saving this account — the isSuperAdmin column may not have been added to the database yet.",
    };
  }

  revalidatePath("/admin/team");
  return { ok: true };
}

export async function setAdminSuperStatus(
  id: string,
  isSuperAdmin: boolean,
): Promise<TeamActionResult> {
  try {
    await requireSuperAdmin();
  } catch {
    return { ok: false, message: "Only a Super Admin can change this." };
  }
  await prisma.$executeRaw`UPDATE \`User\` SET \`isSuperAdmin\` = ${isSuperAdmin ? 1 : 0} WHERE \`id\` = ${id} AND \`role\` = 'ADMIN'`;
  revalidatePath("/admin/team");
  return { ok: true };
}

export async function setAdminActive(
  id: string,
  isActive: boolean,
): Promise<TeamActionResult> {
  let caller: { id: string };
  try {
    caller = await requireSuperAdmin();
  } catch {
    return { ok: false, message: "Only a Super Admin can change this." };
  }
  if (!isActive && caller.id === id) {
    return { ok: false, message: "You can't deactivate your own account." };
  }
  await prisma.user.update({ where: { id }, data: { isActive } });
  revalidatePath("/admin/team");
  return { ok: true };
}
