"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { recomputeProductRating } from "@/app/actions/review-actions";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

export interface AdminReviewRow {
  id: string;
  productId: string;
  productName: string;
  productSlug: string;
  customerName: string;
  email: string | null;
  rating: number;
  comment: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  createdAt: string;
}

export interface AdminReviewActionResult {
  ok: boolean;
  message?: string;
}

export async function getAllReviews(): Promise<AdminReviewRow[]> {
  try {
    await requireAdmin();
  } catch {
    return [];
  }
  try {
    const reviews = await prisma.review.findMany({
      orderBy: { createdAt: "desc" },
      include: { product: { select: { name: true, slug: true } } },
    });
    return reviews.map((r) => ({
      id: r.id,
      productId: r.productId,
      productName: r.product?.name ?? "(deleted product)",
      productSlug: r.product?.slug ?? "",
      customerName: r.customerName,
      email: r.email,
      rating: r.rating,
      comment: r.comment,
      status: r.status,
      createdAt: r.createdAt.toISOString(),
    }));
  } catch (err) {
    console.error("getAllReviews failed:", err);
    return [];
  }
}

/** Edits a review's text/reviewer name/star rating directly from the admin panel. */
export async function updateReview(
  id: string,
  data: { customerName: string; rating: number; comment: string },
): Promise<AdminReviewActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    const rating = Math.min(
      5,
      Math.max(1, Math.round(Number(data.rating) || 1)),
    );
    const review = await prisma.review.update({
      where: { id },
      data: {
        customerName: (data.customerName ?? "").trim() || "Anonymous",
        rating,
        comment: (data.comment ?? "").trim(),
      },
    });
    await recomputeProductRating(review.productId);
    revalidatePath("/admin/reviews");
    revalidatePath(
      `/products/${(await prisma.product.findUnique({ where: { id: review.productId }, select: { slug: true } }))?.slug ?? ""}`,
    );
  } catch (err) {
    console.error("updateReview failed:", err);
    return {
      ok: false,
      message: "Something went wrong saving that review — please try again.",
    };
  }
  return { ok: true };
}

/** Approve, unpublish (send back to pending) or reject a review — any status change recomputes
 *  the product's public rating average/count since that's derived only from APPROVED reviews. */
export async function setReviewStatus(
  id: string,
  status: "PENDING" | "APPROVED" | "REJECTED",
): Promise<AdminReviewActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    const review = await prisma.review.update({
      where: { id },
      data: { status },
    });
    await recomputeProductRating(review.productId);
    revalidatePath("/admin/reviews");
    const product = await prisma.product.findUnique({
      where: { id: review.productId },
      select: { slug: true },
    });
    if (product) revalidatePath(`/products/${product.slug}`);
  } catch (err) {
    console.error("setReviewStatus failed:", err);
    return {
      ok: false,
      message: "Something went wrong updating that review — please try again.",
    };
  }
  return { ok: true };
}

export async function deleteReview(
  id: string,
): Promise<AdminReviewActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    const review = await prisma.review.delete({ where: { id } });
    await recomputeProductRating(review.productId);
    revalidatePath("/admin/reviews");
    const product = await prisma.product.findUnique({
      where: { id: review.productId },
      select: { slug: true },
    });
    if (product) revalidatePath(`/products/${product.slug}`);
  } catch (err) {
    console.error("deleteReview failed:", err);
    return {
      ok: false,
      message: "Something went wrong deleting that review — please try again.",
    };
  }
  return { ok: true };
}
