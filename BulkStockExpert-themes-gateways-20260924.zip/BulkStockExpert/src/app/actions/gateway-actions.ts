"use server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { GATEWAYS } from "@/lib/gateway-catalog";
import { encryptSecret } from "@/lib/payment-crypto";
import { gatewayConfig, invalidateGateways } from "@/lib/gateway-settings";
export async function saveGateway(input: unknown) {
  try {
    const session = await getServerSession(authOptions);
    if (session?.user?.role !== "ADMIN")
      return { ok: false, message: "Not authorized." };
    const data = z
      .object({
        id: z.string(),
        enabled: z.boolean(),
        mode: z.enum(["sandbox", "live"]),
        credentials: z.record(z.string().max(4096)),
      })
      .parse(input);
    const def = GATEWAYS.find((g) => g.id === data.id);
    if (!def) throw new Error("Unknown provider");
    if (data.enabled && !def.ready)
      return {
        ok: false,
        message: "This adapter is not implemented yet and cannot be enabled.",
      };
    const old = await gatewayConfig(data.id);
    const merged = { ...old.credentials };
    for (const field of def.fields)
      if (data.credentials[field]?.trim())
        merged[field] = data.credentials[field].trim();
    if (data.enabled && def.fields.some((f) => !merged[f]))
      return {
        ok: false,
        message: "Complete the required credentials before enabling.",
      };
    const credentials = Object.keys(merged).length
      ? encryptSecret(JSON.stringify(merged))
      : null;
    await prisma.$transaction(async (tx) => {
      await tx.gatewayConfig.upsert({
        where: { id: data.id },
        create: {
          id: data.id,
          enabled: data.enabled,
          mode: data.mode,
          credentials,
        },
        update: { enabled: data.enabled, mode: data.mode, credentials },
      });
      // Keep the existing hosted checkout and webhook integration compatible.
      if (data.id === "stripe" || data.id === "paypal" || data.id === "cod") {
        const values =
          data.id === "stripe"
            ? {
                cardEnabled: data.enabled,
                stripePublishableKey: merged.publishableKey
                  ? encryptSecret(merged.publishableKey)
                  : undefined,
                stripeSecretKey: merged.secretKey
                  ? encryptSecret(merged.secretKey)
                  : undefined,
                stripeWebhookSecret: merged.webhookSecret
                  ? encryptSecret(merged.webhookSecret)
                  : undefined,
              }
            : data.id === "paypal"
              ? {
                  paypalEnabled: data.enabled,
                  paypalMode: data.mode,
                  paypalClientId: merged.clientId
                    ? encryptSecret(merged.clientId)
                    : undefined,
                  paypalClientSecret: merged.clientSecret
                    ? encryptSecret(merged.clientSecret)
                    : undefined,
                }
              : { codEnabled: data.enabled };
        await tx.paymentSettings.upsert({
          where: { id: "singleton" },
          create: { id: "singleton", ...values },
          update: values,
        });
      }
    });
    invalidateGateways();
    return {
      ok: true,
      message:
        "Saved. Existing credentials are retained when inputs are blank.",
    };
  } catch (error) {
    console.error(
      "saveGateway failed",
      error instanceof Error ? error.name : "Unknown error",
    );
    return {
      ok: false,
      message:
        "Could not save. Check database migration and encryption key configuration.",
    };
  }
}
