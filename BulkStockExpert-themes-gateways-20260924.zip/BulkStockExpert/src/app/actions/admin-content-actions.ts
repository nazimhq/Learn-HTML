"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// ContentPage is a newer model (see prisma/schema.prisma) that postdates this project's live
// generated Prisma Client, so — same pattern as PasswordResetToken/PaymentSettings elsewhere
// in this codebase — every read/write here goes through $queryRaw/$executeRaw rather than the
// typed `prisma.contentPage` delegate.

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

export interface ContentPageRow {
  slug: string;
  title: string;
  body: string;
  updatedAt: string;
}

/** All admin-editable pages, for the /admin/content list. Returns [] (not a throw) if the
 * ContentPage table hasn't been created yet (migration-part4-cms.sql not yet run). */
export async function listContentPages(): Promise<ContentPageRow[]> {
  await requireAdmin();
  try {
    const rows = await prisma.$queryRaw<
      Array<{ slug: string; title: string; body: string; updatedAt: Date }>
    >`
      SELECT slug, title, body, updatedAt FROM \`ContentPage\` ORDER BY FIELD(slug, 'about','terms','privacy','returns'), slug
    `;
    return rows.map((r) => ({
      ...r,
      updatedAt: new Date(r.updatedAt).toISOString(),
    }));
  } catch (err) {
    console.error("listContentPages failed (table may not exist yet):", err);
    return [];
  }
}

/** Public, unauthenticated lookup for /pages/[slug] — no admin check. */
export async function getContentPage(
  slug: string,
): Promise<{ title: string; body: string } | null> {
  try {
    const rows = await prisma.$queryRaw<Array<{ title: string; body: string }>>`
      SELECT title, body FROM \`ContentPage\` WHERE slug = ${slug} LIMIT 1
    `;
    return rows[0] ?? null;
  } catch (err) {
    console.error("getContentPage failed:", err);
    return null;
  }
}

export interface ContentActionResult {
  ok: boolean;
  message?: string;
}

export async function updateContentPage(
  slug: string,
  title: string,
  body: string,
): Promise<ContentActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  if (!title.trim()) return { ok: false, message: "Enter a title." };
  try {
    await prisma.$executeRaw`UPDATE \`ContentPage\` SET \`title\` = ${title}, \`body\` = ${body} WHERE \`slug\` = ${slug}`;
  } catch (err) {
    console.error("updateContentPage failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong saving that page — the ContentPage table may not have been created yet (run migration-part4-cms.sql).",
    };
  }
  revalidatePath("/admin/content");
  revalidatePath(`/pages/${slug}`);
  return { ok: true };
}
