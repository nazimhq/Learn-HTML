"use server";

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export interface AdminNotification {
  id: string;
  type: string;
  message: string;
  orderId: string | null;
  isRead: boolean;
  createdAt: string;
}

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

// Cast throughout: Notification is a new model (see prisma/schema.prisma) not yet in this
// sandbox's stale generated Prisma client (src/lib/prisma.ts).
function notificationTable() {
  return (
    prisma as unknown as {
      notification: {
        findMany: (
          a: unknown,
        ) => Promise<
          {
            id: string;
            type: string;
            message: string;
            orderId: string | null;
            isRead: boolean;
            createdAt: Date;
          }[]
        >;
        count: (a: unknown) => Promise<number>;
        updateMany: (a: unknown) => Promise<unknown>;
        update: (a: unknown) => Promise<unknown>;
      };
    }
  ).notification;
}

export async function getNotifications(): Promise<{
  unreadCount: number;
  recent: AdminNotification[];
}> {
  try {
    await requireAdmin();
    const table = notificationTable();
    const [unreadCount, recent] = await Promise.all([
      table.count({ where: { isRead: false } }),
      table.findMany({ orderBy: { createdAt: "desc" }, take: 15 }),
    ]);
    return {
      unreadCount,
      recent: recent.map((n) => ({
        ...n,
        createdAt: n.createdAt.toISOString(),
      })),
    };
  } catch {
    return { unreadCount: 0, recent: [] };
  }
}

export async function markAllNotificationsRead() {
  try {
    await requireAdmin();
    await notificationTable().updateMany({
      where: { isRead: false },
      data: { isRead: true },
    });
  } catch (err) {
    console.error("markAllNotificationsRead failed:", err);
  }
}

export async function markNotificationRead(id: string) {
  try {
    await requireAdmin();
    await notificationTable().update({ where: { id }, data: { isRead: true } });
  } catch (err) {
    console.error("markNotificationRead failed:", err);
  }
}
