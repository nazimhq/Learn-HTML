"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

/** Enables or disables a customer's login. Their orders are untouched. */
export async function setCustomerActive(id: string, isActive: boolean): Promise<{ ok: boolean; message: string }> {
  const session = await getServerSession(authOptions);
  if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN")
    return { ok: false, message: "Not authorized." };
  try {
    const res = await prisma.user.updateMany({ where: { id, role: "CUSTOMER" }, data: { isActive } });
    if (!res.count) return { ok: false, message: "Customer not found." };
  } catch (err) {
    console.error("setCustomerActive failed:", err);
    return { ok: false, message: "Could not update the customer." };
  }
  revalidatePath("/admin/customers");
  return { ok: true, message: isActive ? "Account enabled." : "Account disabled. They can no longer sign in." };
}
