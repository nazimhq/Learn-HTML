"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function isAdmin() {
  const session = await getServerSession(authOptions);
  return (session?.user as { role?: string } | undefined)?.role === "ADMIN";
}

const couponSchema = z
  .object({
    id: z.string().optional(),
    code: z
      .string()
      .trim()
      .min(3, "Code must be at least 3 characters")
      .max(40)
      .regex(/^[A-Za-z0-9_-]+$/, "Use letters, numbers, - or _ only")
      .transform((v) => v.toUpperCase()),
    type: z.enum(["PERCENT", "FIXED"]),
    value: z.number().positive("Enter a discount above 0"),
    minSubtotal: z.number().min(0).nullable(),
    expiresAt: z.string().nullable(),
    isActive: z.boolean(),
  })
  .refine((c) => c.type !== "PERCENT" || c.value <= 100, {
    message: "A percentage discount can't be more than 100%",
  });

export async function saveCoupon(input: unknown): Promise<{ ok: boolean; message: string }> {
  if (!(await isAdmin())) return { ok: false, message: "Not authorized." };
  const parsed = couponSchema.safeParse(input);
  if (!parsed.success) return { ok: false, message: parsed.error.issues[0]?.message ?? "Check the form." };
  const { id, expiresAt, ...rest } = parsed.data;
  const expires = expiresAt ? new Date(`${expiresAt}T23:59:59`) : null;
  if (expires && Number.isNaN(expires.getTime())) return { ok: false, message: "Invalid expiry date." };
  try {
    const clash = await prisma.coupon.findUnique({ where: { code: rest.code } });
    if (clash && clash.id !== id) return { ok: false, message: `Code ${rest.code} already exists.` };
    const data = { ...rest, expiresAt: expires };
    if (id) await prisma.coupon.update({ where: { id }, data });
    else await prisma.coupon.create({ data });
  } catch (err) {
    console.error("saveCoupon failed:", err);
    return { ok: false, message: "Could not save the coupon." };
  }
  revalidatePath("/admin/coupons");
  return { ok: true, message: id ? "Coupon updated." : "Coupon created." };
}

export async function deleteCoupon(id: string): Promise<{ ok: boolean; message: string }> {
  if (!(await isAdmin())) return { ok: false, message: "Not authorized." };
  try {
    const used = await prisma.order.count({ where: { couponId: id } });
    if (used > 0) {
      // Orders keep a link to the coupon they used, so switch it off instead of deleting.
      await prisma.coupon.update({ where: { id }, data: { isActive: false } });
      revalidatePath("/admin/coupons");
      return { ok: true, message: `Used on ${used} order(s), so it was switched off instead of deleted.` };
    }
    await prisma.coupon.delete({ where: { id } });
  } catch (err) {
    console.error("deleteCoupon failed:", err);
    return { ok: false, message: "Could not delete the coupon." };
  }
  revalidatePath("/admin/coupons");
  return { ok: true, message: "Coupon deleted." };
}
