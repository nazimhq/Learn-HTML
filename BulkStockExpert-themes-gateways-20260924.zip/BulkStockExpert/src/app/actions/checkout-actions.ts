"use server";

import { availableGateways } from "@/lib/gateway-settings";
import { adapters } from "@/lib/payment-adapters";
import { getRegionPricing, convertMoney } from "@/lib/region-pricing";
import { REGION_CODES } from "@/lib/gateway-catalog";
import { grantOrderAccess } from "@/lib/order-access";
import { createHash, randomUUID } from "node:crypto";
import { getEnabledPaymentMethods } from "@/lib/payments";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { matchDeliveryZone } from "@/lib/delivery";
import { generateOrderNumber } from "@/lib/constants";
import {
  sendOrderConfirmationEmail,
  sendAdminOrderAlertEmail,
} from "@/lib/email";
import { buildInvoicePdf } from "@/lib/invoice";
import { createStripeCheckoutSession, createPaypalOrder } from "@/lib/payments";

// ---------------------------------------------------------------------------
// Real-time abandoned-checkout capture — called from the checkout page as the shopper
// types (debounced), so their contact/address details are saved even if they never submit.
// ---------------------------------------------------------------------------

export interface AbandonedCheckoutInput {
  sessionId: string;
  name?: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  county?: string;
  postcode?: string;
  itemsSnapshot: {
    name: string;
    variantLabel?: string | null;
    qty: number;
    unitPrice: number;
  }[];
  subtotal: number;
}

export async function captureAbandonedCheckout(input: AbandonedCheckoutInput) {
  if (!input.sessionId) return;
  try {
    const session = await getServerSession(authOptions);
    const hasContactInfo = Boolean(
      input.name ||
      input.phone ||
      input.addressLine1 ||
      input.city ||
      input.postcode,
    );
    const data = {
      userId: session?.user?.id ?? null,
      name: input.name || null,
      email: input.email || null,
      phone: input.phone || null,
      addressLine1: input.addressLine1 || null,
      addressLine2: input.addressLine2 || null,
      city: input.city || null,
      county: input.county || null,
      postcode: input.postcode || null,
      itemsSnapshot: JSON.stringify(input.itemsSnapshot ?? []),
      subtotal: input.subtotal ?? 0,
      stage: hasContactInfo ? "CHECKOUT_STARTED" : "CART",
    };

    // Cast: AbandonedCheckout is a new model added for this feature — see prisma/schema.prisma
    // — this sandbox's generated Prisma client predates it (src/lib/prisma.ts).
    const existing = await (
      prisma as never as {
        abandonedCheckout: {
          findFirst: (a: unknown) => Promise<{ id: string } | null>;
        };
      }
    ).abandonedCheckout.findFirst({
      where: { sessionId: input.sessionId, convertedOrderId: null },
    });
    const table = (
      prisma as never as {
        abandonedCheckout: {
          update: (a: unknown) => Promise<unknown>;
          create: (a: unknown) => Promise<unknown>;
        };
      }
    ).abandonedCheckout;
    if (existing) {
      await table.update({ where: { id: existing.id }, data });
    } else {
      await table.create({ data: { sessionId: input.sessionId, ...data } });
    }
  } catch (err) {
    // Best-effort — never let lead capture break the checkout page.
    console.error("captureAbandonedCheckout failed:", err);
  }
}

const checkoutSchema = z.object({
  customerName: z.string().trim().min(2).max(120),
  email: z
    .string()
    .trim()
    .email()
    .transform((v) => v.toLowerCase()),
  phone: z.string().min(7),
  addressLine1: z.string().min(3),
  addressLine2: z.string().optional(),
  city: z.string().min(2),
  county: z.string().optional(),
  // Min 2: many countries have short or no postcodes (use a placeholder such as "00000").
  postcode: z.string().trim().min(2).max(20),
  customerNote: z.string().max(2000).optional(),
  couponCode: z.string().optional(),
  region: z
    .enum(REGION_CODES as [(typeof REGION_CODES)[number], ...(typeof REGION_CODES)[number][]])
    .default("GB"),
  gateway: z
    .enum([
      "stripe",
      "paypal",
      "klarna",
      "clearpay",
      "sslcommerz",
      "cod",
      "bkash",
      "mollie",
      "razorpay",
      "paystack",
      "flutterwave",
    ])
    .default("cod"),
  paymentMethod: z.enum(["CARD", "PAYPAL", "COD"]).default("CARD"),
  /** The same id used for real-time lead capture (see captureAbandonedCheckout) — lets us mark
   *  that draft as converted instead of it sitting around looking like a drop-off. */
  sessionId: z.string().optional(),
  items: z
    .array(
      z.object({
        variantId: z.string(),
        qty: z.number().int().min(1).max(100),
      }),
    )
    .min(1)
    .max(100),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;

export interface CheckoutResult {
  ok: boolean;
  orderNumber?: string;
  message?: string;
  /** Set when the chosen payment method needs the shopper sent to a hosted gateway page
   *  (Stripe Checkout / PayPal approval) — the checkout page redirects the browser here
   *  instead of going straight to the order-confirmation page. */
  redirectUrl?: string;
}

export async function placeOrder(
  input: CheckoutInput,
): Promise<CheckoutResult> {
  try {
    return await placeOrderInner(input);
  } catch (err) {
    // Top-level safety net: whatever goes wrong (a DB hiccup, a schema mismatch, an
    // unexpected null) must never surface as a raw server-side exception to the shopper —
    // the order may or may not have been created, so we ask them to check their email/track
    // page before retrying, rather than implying nothing happened.
    console.error("placeOrder failed unexpectedly:", err);
    return {
      ok: false,
      message:
        "Something went wrong placing your order — please try again in a moment. If you were charged or received a confirmation email, your order has gone through.",
    };
  }
}

async function placeOrderInner(input: CheckoutInput): Promise<CheckoutResult> {
  const parsed = checkoutSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      message:
        parsed.error.issues[0]?.message ??
        "Please check the form and try again.",
    };
  }
  const data = parsed.data;
  if (!process.env.NEXTAUTH_SECRET)
    return {
      ok: false,
      message: "Checkout is temporarily unavailable. Contact the store.",
    };
  const checkoutKey = data.sessionId
    ? createHash("sha256").update(JSON.stringify(data)).digest("hex")
    : null;
  if (checkoutKey) {
    const previous = await prisma.order.findUnique({ where: { checkoutKey } });
    if (previous) {
      await grantOrderAccess(previous.orderNumber);
      return { ok: true, orderNumber: previous.orderNumber };
    }
  }

  const pricing = await getRegionPricing(data.region);
  const enabled = await availableGateways(data.region);
  if (!enabled.some((g) => g.id === data.gateway))
    return {
      ok: false,
      message:
        "This payment method is unavailable. Please choose another method.",
    };
  data.paymentMethod =
    data.gateway === "cod"
      ? "COD"
      : data.gateway === "paypal"
        ? "PAYPAL"
        : "CARD";
  if (data.gateway !== "cod" && !process.env.NEXT_PUBLIC_SITE_URL)
    return {
      ok: false,
      message:
        "Online checkout is not configured. Please choose Cash on Delivery.",
    };
  const merged = new Map<string, number>();
  for (const item of data.items)
    merged.set(item.variantId, (merged.get(item.variantId) ?? 0) + item.qty);
  data.items = [...merged].map(([variantId, qty]) => ({ variantId, qty }));

  // Re-price everything server-side — never trust client-supplied prices.
  const variantIds = data.items.map((i) => i.variantId);
  const variants = await prisma.productVariant.findMany({
    where: { id: { in: variantIds } },
    include: { product: { select: { id: true, name: true, status: true } } },
  });

  const lines: { variant: (typeof variants)[number]; qty: number }[] = [];
  for (const item of data.items) {
    const v = variants.find((x) => x.id === item.variantId);
    if (!v || v.product.status !== "ACTIVE")
      return {
        ok: false,
        message: "One of the items in your basket is no longer available.",
      };
    if (v.stock < item.qty)
      return {
        ok: false,
        message: `Only ${v.stock} left of "${v.product.name} — ${v.label}".`,
      };
    lines.push({ variant: v, qty: item.qty });
  }

  const baseSubtotal = lines.reduce(
    (sum, l) => sum + Number(l.variant.price) * l.qty,
    0,
  );
  const subtotal = lines.reduce(
    (sum, l) =>
      sum + convertMoney(Number(l.variant.price), pricing.rate) * l.qty,
    0,
  );

  let discount = 0;
  let couponId: string | undefined;
  if (data.couponCode) {
    const coupon = await prisma.coupon.findUnique({
      where: { code: data.couponCode.toUpperCase() },
    });
    if (
      coupon &&
      coupon.isActive &&
      (!coupon.expiresAt || coupon.expiresAt > new Date())
    ) {
      const min = coupon.minSubtotal
        ? convertMoney(Number(coupon.minSubtotal), pricing.rate)
        : 0;
      if (subtotal >= min) {
        discount =
          coupon.type === "PERCENT"
            ? subtotal * (Number(coupon.value) / 100)
            : convertMoney(Number(coupon.value), pricing.rate);
        couponId = coupon.id;
      }
    }
  }

  const zone = await matchDeliveryZone(data.postcode, data.region);
  if (!zone)
    return {
      ok: false,
      message:
        "Delivery is not configured for this country. Please contact the store.",
    };
  const deliveryCharge =
    zone && zone.freeOverAmount && baseSubtotal >= Number(zone.freeOverAmount)
      ? 0
      : convertMoney(Number(zone?.charge ?? 0), pricing.rate);

  discount = Math.min(subtotal, Math.max(0, Math.round(discount * 100) / 100));
  const total =
    Math.round((Math.max(0, subtotal - discount) + deliveryCharge) * 100) / 100;

  const orderNumber = `ORD-${randomUUID().replace(/-/g, "").slice(0, 20).toUpperCase()}`;

  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;

  const order = await prisma.$transaction(async (tx) => {
    const baseOrderData = {
      orderNumber,
      checkoutKey,
      country: data.region,
      currency: pricing.currency,
      paymentGateway: data.gateway,
      customerName: data.customerName,
      email: data.email,
      phone: data.phone,
      addressLine1: data.addressLine1,
      addressLine2: data.addressLine2,
      city: data.city,
      county: data.county,
      postcode: data.postcode.toUpperCase(),
      deliveryZoneId: zone?.id,
      deliveryCharge,
      subtotal,
      discount,
      total,
      couponId,
      paymentMethod: data.paymentMethod,
      customerNote: data.customerNote,
      items: {
        create: lines.map((l) => ({
          productId: l.variant.productId,
          variantId: l.variant.id,
          name: l.variant.product.name,
          variantLabel: l.variant.label,
          unitPrice: convertMoney(Number(l.variant.price), pricing.rate),
          costPriceAtTime:
            l.variant.costPrice == null
              ? null
              : convertMoney(Number(l.variant.costPrice), pricing.rate),
          quantity: l.qty,
          imageUrl: l.variant.imageUrl,
        })),
      },
      activity: { create: { message: "Order received." } },
    };
    // Explicit select: without this, Prisma's default create() return implicitly selects
    // EVERY scalar field this generated client knows about — including Order.userId and
    // Order.paymentReference (new fields added to prisma/schema.prisma). If those columns
    // don't physically exist yet on the live MySQL table, that implicit read-back throws
    // PrismaClientKnownRequestError P2022 and aborts the entire order — this was the root
    // cause of "Something went wrong placing your order" on checkout. Only the fields this
    // function actually reads afterwards (order.id / .orderNumber / .createdAt) are needed.
    const createSelect = {
      id: true,
      orderNumber: true,
      createdAt: true,
    } as const;
    const created = await tx.order.create({
      data: { ...baseOrderData, userId },
      select: createSelect,
    });

    for (const l of lines) {
      const reserved = await tx.productVariant.updateMany({
        where: { id: l.variant.id, stock: { gte: l.qty } },
        data: { stock: { decrement: l.qty } },
      });
      if (reserved.count !== 1)
        throw new Error("An item sold out. Please refresh your basket.");
    }

    return created;
  });

  await grantOrderAccess(order.orderNumber);

  // Best-effort side-effects — a failure here must never undo or block the order itself.
  if (data.sessionId) {
    try {
      await (
        prisma as never as {
          abandonedCheckout: { updateMany: (a: unknown) => Promise<unknown> };
        }
      ).abandonedCheckout.updateMany({
        where: { sessionId: data.sessionId, convertedOrderId: null },
        data: { convertedOrderId: order.id },
      });
    } catch (err) {
      console.error("Marking abandoned-checkout as converted failed:", err);
    }
  }
  try {
    await (
      prisma as never as {
        notification: { create: (a: unknown) => Promise<unknown> };
      }
    ).notification.create({
      data: {
        type: "ORDER_PLACED",
        message: `New order ${order.orderNumber} from ${data.customerName} — ${data.addressLine1}, ${data.city}, ${data.postcode}`,
        orderId: order.id,
      },
    });
  } catch (err) {
    console.error("Creating admin notification failed:", err);
  }

  const settings = await prisma.appSettings
    .findUnique({ where: { id: "singleton" } })
    .catch(() => null);

  const trackingUrl = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/track-order?order=${order.orderNumber}&email=${encodeURIComponent(data.email)}`;
  const items = lines.map((l) => ({
    name: l.variant.product.name,
    variantLabel: l.variant.label,
    quantity: l.qty,
    unitPrice: convertMoney(Number(l.variant.price), pricing.rate),
  }));
  const emailPayload = {
    orderNumber: order.orderNumber,
    currency: pricing.currency,
    customerName: data.customerName,
    customerEmail: data.email,
    phone: data.phone,
    addressLine1: data.addressLine1,
    addressLine2: data.addressLine2,
    city: data.city,
    county: data.county,
    postcode: data.postcode,
    deliveryZoneName: zone?.name,
    deliveryCharge,
    subtotal,
    discount,
    total,
    items,
    trackingUrl,
    paymentMethod: data.paymentMethod,
    createdAt: order.createdAt,
    siteName: settings?.siteName,
    contactEmail: settings?.contactEmail,
    contactPhone: settings?.contactPhone,
  };

  // Email + PDF invoice failures must never block order placement — log and continue.
  try {
    const invoicePdf = await buildInvoicePdf({
      settings: {
        logoUrl: settings?.logoUrl,
        siteName: settings?.siteName,
        contactEmail: settings?.contactEmail,
        contactPhone: settings?.contactPhone,
      },
      order: {
        orderNumber: order.orderNumber,
        currency: pricing.currency,
        customerName: data.customerName,
        email: data.email,
        phone: data.phone,
        addressLine1: data.addressLine1,
        addressLine2: data.addressLine2,
        city: data.city,
        county: data.county,
        postcode: data.postcode,
        deliveryZoneName: zone?.name,
        deliveryCharge,
        subtotal,
        discount,
        total,
        paymentMethod: data.paymentMethod,
        createdAt: order.createdAt,
        items,
      },
      status: "unpaid",
    });
    const attachments = [
      {
        filename: `invoice-${order.orderNumber}-unpaid.pdf`,
        content: invoicePdf,
        contentType: "application/pdf",
      },
    ];
    await Promise.all([
      sendOrderConfirmationEmail(emailPayload, attachments),
      sendAdminOrderAlertEmail(emailPayload),
    ]);
  } catch (err) {
    console.error("Order email failed to send:", err);
  }

  // Card/PayPal: if the admin has configured & enabled that gateway (Admin → Settings →
  // Payments), send the shopper to its hosted checkout/approval page and remember the
  // gateway's own reference so the webhook/return-callback can find this order again.
  // If the gateway isn't configured, this silently falls back to the order already being
  // recorded above with payment status "Pending" for manual follow-up — same as before this
  // feature existed. Cash on Delivery never reaches this block.
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "";
  if (data.gateway !== "cod") {
    try {
      const fullOrder = await prisma.order.findUniqueOrThrow({
        where: { id: order.id },
      });
      const payment = await adapters[data.gateway].create(fullOrder, siteUrl);
      await prisma.order.update({
        where: { id: order.id },
        data: { paymentReference: payment.reference },
      });
      return {
        ok: true,
        orderNumber: order.orderNumber,
        redirectUrl: payment.url,
      };
    } catch (error) {
      console.error(
        "Gateway session unavailable",
        error instanceof Error ? error.name : "Error",
      );
      await prisma.orderActivityLog.create({
        data: {
          orderId: order.id,
          message:
            "Online payment could not start. Payment remains pending; contact support before paying or reordering.",
        },
      });
      return {
        ok: true,
        orderNumber: order.orderNumber,
        redirectUrl: `/order-confirmation/${order.orderNumber}?payment=unavailable`,
      };
    }
  }
  return { ok: true, orderNumber: order.orderNumber };
}
