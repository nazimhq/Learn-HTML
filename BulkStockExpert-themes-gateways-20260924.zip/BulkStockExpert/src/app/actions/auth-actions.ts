"use server";

import { z } from "zod";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { sendPasswordResetEmail } from "@/lib/email";

// Random raw token is emailed to the user; only its SHA-256 hash is ever stored, so a
// leaked/stolen database never exposes usable reset links.
function hashToken(raw: string): string {
  return crypto.createHash("sha256").update(raw).digest("hex");
}

const registerSchema = z.object({
  name: z.string().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export interface AuthActionResult {
  ok: boolean;
  message?: string;
}

/** Customer self-registration — accounts created here always get the CUSTOMER role. */
export async function registerCustomer(
  input: z.infer<typeof registerSchema>,
): Promise<AuthActionResult> {
  const parsed = registerSchema.safeParse(input);
  if (!parsed.success)
    return {
      ok: false,
      message: parsed.error.issues[0]?.message ?? "Please check the form.",
    };
  const { name, email, password } = parsed.data;

  try {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing)
      return {
        ok: false,
        message:
          "An account with that email already exists — try signing in instead.",
      };

    const passwordHash = await bcrypt.hash(password, 10);
    await prisma.user.create({
      data: { name, email, passwordHash, role: "CUSTOMER" },
    });
    return { ok: true };
  } catch (err) {
    console.error("registerCustomer failed:", err);
    return {
      ok: false,
      message: "Something went wrong creating your account — please try again.",
    };
  }
}

/**
 * Shared "forgot password" request for BOTH the admin panel and customer accounts — they're
 * the same User table, so one flow covers both. Always returns ok:true regardless of whether
 * the email matches a real account, so this can't be used to enumerate registered emails.
 */
export async function requestPasswordReset(
  email: string,
  redirectBase?: string,
): Promise<AuthActionResult> {
  try {
    const user = await prisma.user.findUnique({ where: { email } });
    if (user && user.isActive) {
      const raw = crypto.randomBytes(32).toString("hex");
      const id = crypto.randomUUID();
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
      // Raw SQL on purpose: some deployed environments run a Prisma Client generated
      // before this model existed, where `prisma.passwordResetToken` isn't a valid
      // delegate yet. $executeRaw only needs the table to exist, not the generated
      // client to know about it, so it works everywhere without a client regeneration.
      await prisma.$executeRaw`INSERT INTO \`PasswordResetToken\` (\`id\`, \`userId\`, \`tokenHash\`, \`expiresAt\`, \`usedAt\`, \`createdAt\`) VALUES (${id}, ${user.id}, ${hashToken(raw)}, ${expiresAt}, NULL, NOW(3))`;
      const base = redirectBase || process.env.NEXT_PUBLIC_SITE_URL || "";
      const resetUrl = `${base}/reset-password/${raw}`;
      await sendPasswordResetEmail(user.email, user.name, resetUrl).catch(
        (err) => console.error("sendPasswordResetEmail failed:", err),
      );
    }
  } catch (err) {
    console.error("requestPasswordReset failed:", err);
  }
  return {
    ok: true,
    message:
      "If that email has an account, we've sent a password reset link to it.",
  };
}

export async function validateResetToken(
  rawToken: string,
): Promise<{ valid: boolean; role?: string }> {
  try {
    const rows = await prisma.$queryRaw<
      Array<{ usedAt: Date | null; expiresAt: Date; role: string }>
    >`
      SELECT prt.usedAt AS usedAt, prt.expiresAt AS expiresAt, u.role AS role
      FROM \`PasswordResetToken\` prt
      JOIN \`User\` u ON u.id = prt.userId
      WHERE prt.tokenHash = ${hashToken(rawToken)}
      LIMIT 1
    `;
    const record = rows[0];
    if (!record || record.usedAt || new Date(record.expiresAt) < new Date())
      return { valid: false };
    return { valid: true, role: record.role };
  } catch (err) {
    console.error("validateResetToken failed:", err);
    return { valid: false };
  }
}

const resetSchema = z.object({
  token: z.string().min(10),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export async function resetPassword(
  input: z.infer<typeof resetSchema>,
): Promise<AuthActionResult & { role?: string }> {
  const parsed = resetSchema.safeParse(input);
  if (!parsed.success)
    return {
      ok: false,
      message: parsed.error.issues[0]?.message ?? "Please check the form.",
    };
  const { token, password } = parsed.data;

  try {
    const rows = await prisma.$queryRaw<
      Array<{
        id: string;
        userId: string;
        usedAt: Date | null;
        expiresAt: Date;
        role: string;
      }>
    >`
      SELECT prt.id AS id, prt.userId AS userId, prt.usedAt AS usedAt, prt.expiresAt AS expiresAt, u.role AS role
      FROM \`PasswordResetToken\` prt
      JOIN \`User\` u ON u.id = prt.userId
      WHERE prt.tokenHash = ${hashToken(token)}
      LIMIT 1
    `;
    const record = rows[0];
    if (!record || record.usedAt || new Date(record.expiresAt) < new Date()) {
      return {
        ok: false,
        message:
          "This reset link is invalid or has expired — request a new one.",
      };
    }

    const passwordHash = await bcrypt.hash(password, 10);
    await prisma.$transaction([
      prisma.user.update({
        where: { id: record.userId },
        data: { passwordHash },
      }),
      prisma.$executeRaw`UPDATE \`PasswordResetToken\` SET \`usedAt\` = NOW(3) WHERE \`id\` = ${record.id}`,
    ]);

    return { ok: true, role: record.role };
  } catch (err) {
    console.error("resetPassword failed:", err);
    return { ok: false, message: "Something went wrong — please try again." };
  }
}
