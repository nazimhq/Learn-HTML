"use server";

import { z } from "zod";
import { encryptSecret } from "@/lib/payment-crypto";
import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { REGION_CODES } from "@/lib/gateway-catalog";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

export interface SettingsActionResult {
  ok: boolean;
  message?: string;
}

export async function updateSiteSettings(data: {
  siteName: string;
  tagline: string;
  contactEmail: string;
  contactPhone: string;
  adminNotificationEmail: string;
  vatRate: number;
  pricesIncludeVat: boolean;
  freeShippingOverAmount?: number | null;
}): Promise<SettingsActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    // Guard against null/undefined/NaN slipping through from the form before they ever reach
    // the database — a blank "VAT rate" field, for example, would otherwise upsert NaN.
    const safe = {
      siteName: (data.siteName ?? "").trim() || "Store",
      tagline: data.tagline ?? "",
      contactEmail: data.contactEmail ?? "",
      contactPhone: data.contactPhone ?? "",
      adminNotificationEmail: data.adminNotificationEmail ?? "",
      vatRate: Number.isFinite(data.vatRate) ? data.vatRate : 20,
      pricesIncludeVat: Boolean(data.pricesIncludeVat),
      freeShippingOverAmount:
        data.freeShippingOverAmount != null &&
        Number.isFinite(data.freeShippingOverAmount)
          ? data.freeShippingOverAmount
          : null,
    };
    await prisma.appSettings.upsert({
      where: { id: "singleton" },
      update: safe,
      create: { id: "singleton", ...safe },
    });
  } catch (err) {
    console.error("updateSiteSettings failed:", err);
    return {
      ok: false,
      message: "Something went wrong saving site settings — please try again.",
    };
  }
  revalidatePath("/", "layout");
  revalidatePath("/admin/settings");
  return { ok: true };
}

export async function updateTrackingSettings(data: {
  metaPixelId?: string | null;
  gaMeasurementId?: string | null;
  gtmContainerId?: string | null;
  whatsappNumber?: string | null;
}): Promise<SettingsActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    if (!data || typeof data !== "object")
      return { ok: false, message: "Invalid settings." };
    await prisma.appSettings.upsert({
      where: { id: "singleton" },
      update: data,
      create: { id: "singleton", ...data },
    });
  } catch (err) {
    console.error("updateTrackingSettings failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong saving tracking settings — please try again.",
    };
  }
  revalidatePath("/", "layout");
  revalidatePath("/admin/settings");
  return { ok: true };
}

export async function updateThemeSettings(data: {
  accentTheme: "red" | "maroon" | "gold" | "yellow" | "black" | "purple";
  colorMode: "light" | "dark";
}): Promise<SettingsActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    if (!data || typeof data !== "object")
      return { ok: false, message: "Invalid settings." };
    data = z
      .object({
        accentTheme: z.enum([
          "red",
          "maroon",
          "gold",
          "yellow",
          "black",
          "purple",
        ]),
        colorMode: z.enum(["light", "dark"]),
      })
      .parse(data);
    await prisma.appSettings.upsert({
      where: { id: "singleton" },
      update: data,
      create: { id: "singleton", ...data },
    });
  } catch (err) {
    console.error("updateThemeSettings failed:", err);
    return {
      ok: false,
      message: "Something went wrong saving the theme — please try again.",
    };
  }
  revalidatePath("/", "layout");
  revalidatePath("/admin/settings");
  return { ok: true };
}

export interface PaymentSettingsInput {
  codEnabled: boolean;
  cardEnabled: boolean;
  stripePublishableKey?: string | null;
  stripeSecretKey?: string | null;
  stripeWebhookSecret?: string | null;
  paypalEnabled: boolean;
  paypalClientId?: string | null;
  paypalClientSecret?: string | null;
  paypalMode: "sandbox" | "live";
}

export async function updatePaymentSettings(
  _data: PaymentSettingsInput,
): Promise<SettingsActionResult> {
  return {
    ok: false,
    message: "Payment settings have moved to /admin/payments.",
  };
}

export async function upsertDeliveryZone(data: {
  id?: string;
  name: string;
  description: string;
  charge: number;
  freeOverAmount?: number | null;
  postcodePrefixes: string[];
  countryCode?: string;
  estimatedDays: string;
  isActive: boolean;
}): Promise<SettingsActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    const { id, ...rest } = data;
    const safe = {
      ...rest,
      countryCode: z
        .string()
        .refine((c) => (REGION_CODES as string[]).includes(c), "Unsupported country")
        .parse(rest.countryCode ?? "GB"),
      charge: Number.isFinite(rest.charge) ? rest.charge : 0,
    };
    if (id) {
      await prisma.deliveryZone.update({ where: { id }, data: safe });
    } else {
      const count = await prisma.deliveryZone.count();
      await prisma.deliveryZone.create({ data: { ...safe, position: count } });
    }
  } catch (err) {
    console.error("upsertDeliveryZone failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong saving that delivery zone — please try again.",
    };
  }
  revalidatePath("/admin/settings");
  revalidatePath("/checkout");
  return { ok: true };
}

export async function deleteDeliveryZone(
  id: string,
): Promise<SettingsActionResult> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    await prisma.deliveryZone.delete({ where: { id } });
  } catch (err) {
    console.error("deleteDeliveryZone failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong removing that delivery zone — please try again.",
    };
  }
  revalidatePath("/admin/settings");
  return { ok: true };
}

export interface BrandingSettingsInput {
  logoUrl?: string | null;
  facebookUrl?: string | null;
  instagramUrl?: string | null;
  tiktokUrl?: string | null;
}

// logoUrl/facebookUrl/instagramUrl/tiktokUrl are newer AppSettings columns that postdate this
// project's live generated Prisma Client, so — same pattern as PaymentSettings above — these
// go through raw SQL rather than the typed `prisma.appSettings` delegate.
export async function updateBrandingSettings(
  data: BrandingSettingsInput,
): Promise<{ ok: boolean; message?: string }> {
  try {
    await requireAdmin();
  } catch {
    return { ok: false, message: "Not authorized." };
  }
  try {
    const values = {
      logoUrl: data?.logoUrl || null,
      facebookUrl: data?.facebookUrl || null,
      instagramUrl: data?.instagramUrl || null,
      tiktokUrl: data?.tiktokUrl || null,
    };
    for (const value of Object.values(values))
      if (value && !value.startsWith("/uploads/"))
        z.string()
          .url()
          .refine((v) => v.startsWith("https://"))
          .parse(value);
    await prisma.appSettings.upsert({
      where: { id: "singleton" },
      create: { id: "singleton", ...values },
      update: values,
    });
  } catch (err) {
    console.error("updateBrandingSettings failed:", err);
    return {
      ok: false,
      message:
        "Something went wrong saving branding — the new columns may not have been added yet (run migration-part4-cms.sql).",
    };
  }
  revalidatePath("/", "layout");
  revalidatePath("/admin/settings");
  return { ok: true };
}

/** Raw-SQL read of the branding columns, for pages that only need these (avoids depending on
 * the typed AppSettings delegate knowing about columns newer than the live generated client). */
export async function getBrandingSettings(): Promise<BrandingSettingsInput> {
  try {
    const rows = await prisma.$queryRaw<
      Array<{
        logoUrl: string | null;
        facebookUrl: string | null;
        instagramUrl: string | null;
        tiktokUrl: string | null;
      }>
    >`
      SELECT logoUrl, facebookUrl, instagramUrl, tiktokUrl FROM \`AppSettings\` WHERE id = 'singleton' LIMIT 1
    `;
    return rows[0] ?? {};
  } catch (err) {
    console.error(
      "getBrandingSettings failed (columns may not exist yet):",
      err,
    );
    return {};
  }
}
