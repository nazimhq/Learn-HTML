"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { REGIONS } from "@/lib/gateway-catalog";

const CODES = Array.from(new Set(Object.values(REGIONS))).filter((c) => c !== "GBP");

/** Saves 1 GBP = N <currency> rates. A blank value removes the saved rate (env fallback applies). */
export async function saveCurrencyRates(input: unknown): Promise<{ ok: boolean; message: string }> {
  const session = await getServerSession(authOptions);
  if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN")
    return { ok: false, message: "Not authorized." };
  const parsed = z.record(z.string()).safeParse(input);
  if (!parsed.success) return { ok: false, message: "Invalid rates." };
  const updates: { code: string; rate: number | null }[] = [];
  for (const code of CODES) {
    const raw = (parsed.data[code] ?? "").trim();
    if (raw === "") {
      updates.push({ code, rate: null });
      continue;
    }
    const rate = Number(raw);
    if (!Number.isFinite(rate) || rate <= 0 || rate > 1_000_000)
      return { ok: false, message: `${code}: enter a positive number, e.g. 1.17` };
    updates.push({ code, rate });
  }
  try {
    await prisma.$transaction(
      updates.map((u) =>
        u.rate === null
          ? prisma.currencyRate.deleteMany({ where: { code: u.code } })
          : prisma.currencyRate.upsert({
              where: { code: u.code },
              create: { code: u.code, rate: u.rate },
              update: { rate: u.rate },
            }),
      ),
    );
  } catch (err) {
    console.error("saveCurrencyRates failed:", err);
    return { ok: false, message: "Could not save. Run migration-themes-gateways.sql first." };
  }
  revalidatePath("/admin/currencies");
  revalidatePath("/checkout");
  return { ok: true, message: "Exchange rates saved. Checkout uses them immediately." };
}
