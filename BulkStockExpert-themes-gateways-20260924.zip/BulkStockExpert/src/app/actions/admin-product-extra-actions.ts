"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

type Result = { ok: boolean; message: string };

async function isAdmin() {
  const session = await getServerSession(authOptions);
  return (session?.user as { role?: string } | undefined)?.role === "ADMIN";
}

async function refresh(productId: string) {
  const p = await prisma.product.findUnique({ where: { id: productId }, select: { slug: true } });
  revalidatePath("/admin/products");
  revalidatePath(`/admin/products/${productId}`);
  revalidatePath("/products");
  if (p) revalidatePath(`/products/${p.slug}`);
  revalidatePath("/");
}

async function guard<T>(fn: () => Promise<T>, fail: string): Promise<T | Result> {
  if (!(await isAdmin())) return { ok: false, message: "Not authorized." };
  try {
    return await fn();
  } catch (err) {
    console.error(fail, err);
    return { ok: false, message: fail };
  }
}

export async function setProductCategory(productId: string, categoryId: string): Promise<Result> {
  return guard(async () => {
    const cat = await prisma.category.findUnique({ where: { id: categoryId } });
    if (!cat) return { ok: false, message: "Choose a category." };
    await prisma.product.update({ where: { id: productId }, data: { categoryId } });
    await refresh(productId);
    return { ok: true, message: `Moved to ${cat.name}.` };
  }, "Could not change the category.");
}

/** Only accepts images uploaded through the admin uploader or https URLs. */
const imageUrl = z
  .string()
  .max(2048)
  .refine((u) => /^\/uploads\/products\/[\w-]+\.(jpg|png|webp|gif)$/.test(u) || /^https:\/\//.test(u), "Invalid image");

export async function addProductImage(productId: string, url: string, altText = ""): Promise<Result> {
  return guard(async () => {
    const parsed = imageUrl.safeParse(url);
    if (!parsed.success) return { ok: false, message: "Invalid image." };
    const count = await prisma.productImage.count({ where: { productId } });
    await prisma.productImage.create({
      data: { productId, url: parsed.data, altText: altText.slice(0, 200), position: count },
    });
    await refresh(productId);
    return { ok: true, message: "Photo added." };
  }, "Could not add the photo.");
}

export async function removeProductImage(imageId: string): Promise<Result> {
  return guard(async () => {
    const img = await prisma.productImage.delete({ where: { id: imageId } });
    await refresh(img.productId);
    return { ok: true, message: "Photo removed." };
  }, "Could not remove the photo.");
}

/** Moves a photo one place earlier (-1) or later (+1). The first photo is the main one. */
export async function moveProductImage(imageId: string, direction: -1 | 1): Promise<Result> {
  return guard(async () => {
    const img = await prisma.productImage.findUnique({ where: { id: imageId } });
    if (!img) return { ok: false, message: "Photo not found." };
    const all = await prisma.productImage.findMany({ where: { productId: img.productId }, orderBy: [{ position: "asc" }, { id: "asc" }] });
    const i = all.findIndex((x) => x.id === imageId);
    const j = i + direction;
    if (j < 0 || j >= all.length) return { ok: true, message: "" };
    [all[i], all[j]] = [all[j], all[i]];
    await prisma.$transaction(all.map((x, pos) => prisma.productImage.update({ where: { id: x.id }, data: { position: pos } })));
    await refresh(img.productId);
    return { ok: true, message: "Photo order saved." };
  }, "Could not reorder photos.");
}

const variantSchema = z.object({
  label: z.string().trim().min(1, "Enter an option name, e.g. Black / Large").max(120),
  sku: z.string().trim().min(2, "Enter a SKU").max(60).regex(/^[A-Za-z0-9._-]+$/, "SKU: letters, numbers, . _ - only"),
  price: z.number().positive("Enter a price above 0"),
  stock: z.number().int().min(0),
  lowStockAt: z.number().int().min(0).default(5),
});

export async function addVariant(productId: string, input: unknown): Promise<Result> {
  return guard(async () => {
    const parsed = variantSchema.safeParse(input);
    if (!parsed.success) return { ok: false, message: parsed.error.issues[0]?.message ?? "Check the option." };
    const sku = parsed.data.sku.toUpperCase();
    if (await prisma.productVariant.findUnique({ where: { sku } })) return { ok: false, message: `SKU ${sku} is already used.` };
    await prisma.productVariant.create({ data: { productId, ...parsed.data, sku } });
    await refresh(productId);
    return { ok: true, message: `Option "${parsed.data.label}" added.` };
  }, "Could not add the option.");
}

export async function deleteVariant(variantId: string): Promise<Result> {
  return guard(async () => {
    const v = await prisma.productVariant.findUnique({
      where: { id: variantId },
      include: { _count: { select: { orderItems: true } }, product: { select: { _count: { select: { variants: true } } } } },
    });
    if (!v) return { ok: false, message: "Option not found." };
    if (v.product._count.variants <= 1) return { ok: false, message: "A product needs at least one option." };
    if (v._count.orderItems > 0) {
      // Past orders point at this option, so keep it but make it unavailable.
      await prisma.productVariant.update({ where: { id: variantId }, data: { stock: 0 } });
      await refresh(v.productId);
      return { ok: true, message: `"${v.label}" is on past orders, so it was set to out of stock instead of deleted.` };
    }
    await prisma.productVariant.delete({ where: { id: variantId } });
    await refresh(v.productId);
    return { ok: true, message: `Option "${v.label}" deleted.` };
  }, "Could not delete the option.");
}

export async function deleteProduct(productId: string): Promise<Result> {
  return guard(async () => {
    const used = await prisma.orderItem.count({ where: { productId } });
    if (used > 0) {
      await prisma.product.update({ where: { id: productId }, data: { status: "ARCHIVED" } });
      await refresh(productId);
      return { ok: true, message: "This product is on past orders, so it was archived (hidden) instead of deleted." };
    }
    await prisma.product.delete({ where: { id: productId } });
    revalidatePath("/admin/products");
    revalidatePath("/products");
    revalidatePath("/");
    return { ok: true, message: "Product deleted." };
  }, "Could not delete the product.");
}
