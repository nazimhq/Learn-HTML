"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export interface CreateProductInput {
  name: string;
  slug?: string;
  description: string;
  categoryId: string;
  brandName?: string;
  basePrice: number;
  compareAtPrice?: number | null;
  costPrice?: number | null;
  status: "ACTIVE" | "DRAFT" | "ARCHIVED";
  stock: number;
  lowStockAt?: number;
  imageUrls: string[];
}

export interface CreateProductResult {
  ok: boolean;
  message?: string;
  productId?: string;
}

/** Creates a product with one default variant (this admin panel doesn't yet build multi-variant
 *  products from scratch — use "Add variant" style edits on the product page for that later). */
export async function createProduct(
  input: CreateProductInput,
): Promise<CreateProductResult> {
  await requireAdmin();

  const name = input.name.trim();
  if (name.length < 2) return { ok: false, message: "Enter a product name." };
  if (!input.categoryId) return { ok: false, message: "Choose a category." };
  if (!input.basePrice || input.basePrice <= 0)
    return { ok: false, message: "Enter a valid price." };

  const slug = slugify(input.slug || name);
  const existingSlug = await prisma.product.findUnique({ where: { slug } });
  if (existingSlug)
    return {
      ok: false,
      message: `A product with the slug "${slug}" already exists — try a different name.`,
    };

  let brandId: string | undefined;
  if (input.brandName?.trim()) {
    const brandName = input.brandName.trim();
    const brandSlug = slugify(brandName);
    const brand = await prisma.brand.upsert({
      where: { slug: brandSlug },
      update: {},
      create: { name: brandName, slug: brandSlug },
    });
    brandId = brand.id;
  }

  const sku = `${slug}-001`.toUpperCase().slice(0, 60);

  const product = await prisma.product.create({
    data: {
      name,
      slug,
      description: input.description || "",
      status: input.status,
      basePrice: input.basePrice,
      compareAtPrice: input.compareAtPrice || null,
      costPrice: input.costPrice || null,
      categoryId: input.categoryId,
      brandId,
      images: {
        create: input.imageUrls.map((url, i) => ({ url, position: i })),
      },
      variants: {
        create: [
          {
            sku,
            label: "Default",
            price: input.basePrice,
            compareAtPrice: input.compareAtPrice || null,
            costPrice: input.costPrice || null,
            stock: input.stock,
            lowStockAt: input.lowStockAt ?? 5,
            imageUrl: input.imageUrls[0] || null,
          },
        ],
      },
    },
  });

  revalidatePath("/admin/products");
  revalidatePath("/products");
  revalidatePath("/", "layout");
  return { ok: true, productId: product.id };
}

export async function updateProduct(
  productId: string,
  data: {
    name: string;
    description: string;
    basePrice: number;
    compareAtPrice: number | null;
    costPrice: number | null;
    status: "ACTIVE" | "DRAFT" | "ARCHIVED";
  },
) {
  await requireAdmin();
  // Reject blank/NaN/negative numbers (a blank price used to save as £0.00).
  const money = (v: number | null) => v === null || (Number.isFinite(v) && v >= 0);
  if (!data.name?.trim() || !Number.isFinite(data.basePrice) || data.basePrice <= 0 || !money(data.compareAtPrice) || !money(data.costPrice) || !["ACTIVE", "DRAFT", "ARCHIVED"].includes(data.status))
    throw new Error("Invalid product details");
  await prisma.product.update({ where: { id: productId }, data });
  revalidatePath("/admin/products");
  revalidatePath(`/admin/products/${productId}`);
  revalidatePath("/products");
}

export async function updateVariant(
  variantId: string,
  data: {
    label: string;
    price: number;
    compareAtPrice: number | null;
    costPrice: number | null;
    stock: number;
    lowStockAt: number;
  },
) {
  await requireAdmin();
  const ok = (v: number | null) => v === null || (Number.isFinite(v) && v >= 0);
  if (!data.label?.trim() || !Number.isFinite(data.price) || data.price <= 0 || !ok(data.compareAtPrice) || !ok(data.costPrice) || !Number.isInteger(data.stock) || data.stock < 0 || !Number.isInteger(data.lowStockAt) || data.lowStockAt < 0)
    throw new Error("Invalid option details");
  const variant = await prisma.productVariant.update({
    where: { id: variantId },
    data,
  });
  revalidatePath("/admin/products");
  revalidatePath(`/admin/products/${variant.productId}`);
  revalidatePath("/products");
}

export async function approveReview(reviewId: string, approve: boolean) {
  await requireAdmin();
  await prisma.review.update({
    where: { id: reviewId },
    data: { status: approve ? "APPROVED" : "REJECTED" },
  });
  revalidatePath("/admin/products");
}
