"use server";

import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  accentSchema,
  isValidTimeZone,
  modeSchema,
  skinSchema,
  slotSchema,
} from "@/lib/site-theme";

const inputSchema = z.object({
  skin: skinSchema,
  /** Optional: also set the accent + light/dark mode (AppSettings) in the same save. */
  accent: accentSchema.optional(),
  mode: modeSchema.optional(),
  rotationEnabled: z.boolean(),
  rotationMode: z.enum(["interval", "schedule"]),
  rotationHours: z.number().int().min(1).max(720),
  timezone: z.string().min(1).max(64).refine(isValidTimeZone, "Unknown time zone"),
  slots: z.array(slotSchema).max(24),
});

export type SiteThemeInput = z.infer<typeof inputSchema>;

export async function saveSiteTheme(input: unknown): Promise<{ ok: boolean; message: string }> {
  const session = await getServerSession(authOptions);
  if ((session?.user as { role?: string } | undefined)?.role !== "ADMIN")
    return { ok: false, message: "Not authorized." };

  const parsed = inputSchema.safeParse(input);
  if (!parsed.success)
    return { ok: false, message: parsed.error.issues[0]?.message ?? "Please check the form." };
  const data = parsed.data;

  if (data.rotationEnabled) {
    if (data.slots.length < 2)
      return { ok: false, message: "Add at least two looks to rotate between." };
    if (data.rotationMode === "schedule") {
      if (data.slots.some((s) => !s.at))
        return { ok: false, message: "Give every look a switch time." };
      const times = data.slots.map((s) => s.at);
      if (new Set(times).size !== times.length)
        return { ok: false, message: "Two looks have the same switch time." };
    }
  }

  try {
    const values = {
      skin: data.skin,
      rotationEnabled: data.rotationEnabled,
      rotationMode: data.rotationMode,
      rotationHours: data.rotationHours,
      timezone: data.timezone,
      slots: JSON.stringify(data.slots),
    };
    await prisma.$transaction(async (tx) => {
      await tx.siteTheme.upsert({
        where: { id: "singleton" },
        create: { id: "singleton", ...values },
        update: values,
      });
      if (data.accent || data.mode) {
        const look = {
          ...(data.accent ? { accentTheme: data.accent } : {}),
          ...(data.mode ? { colorMode: data.mode } : {}),
        };
        await tx.appSettings.upsert({
          where: { id: "singleton" },
          create: { id: "singleton", ...look },
          update: look,
        });
      }
    });
  } catch (err) {
    console.error("saveSiteTheme failed:", err);
    return {
      ok: false,
      message:
        "Could not save. Run migration-themes-gateways.sql on the database if you haven't yet.",
    };
  }
  revalidatePath("/", "layout");
  revalidatePath("/admin/appearance");
  return { ok: true, message: "Saved. Open storefront tabs update within a few seconds." };
}
