"use server";

import { deliverEmailJobs } from "@/lib/email-jobs";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ORDER_STATUS_LABEL } from "@/lib/constants";
import {
  sendOrderStatusUpdateEmail,
  sendShippingUpdateEmail,
  sendOrderCancellationEmail,
} from "@/lib/email";
import { markOrderPaid } from "@/lib/order-payment";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as { role?: string })?.role !== "ADMIN") {
    throw new Error("Not authorized.");
  }
}

export async function updateOrderStatus(
  orderId: string,
  status: string,
  note?: string,
) {
  await requireAdmin();

  const next = z
    .enum(["PENDING", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"])
    .parse(status);
  const order = await prisma.$transaction(async (tx) => {
    const before = await tx.order.findUniqueOrThrow({
      where: { id: orderId },
      include: { items: true },
    });
    if (before.status === next) return null;
    if (before.status === "CANCELLED")
      throw new Error(
        "Cancelled orders cannot be reopened. Create a new order.",
      );
    if (
      next === "DELIVERED" &&
      before.paymentMethod !== "COD" &&
      before.paymentStatus !== "PAID"
    )
      throw new Error(
        "Confirm payment before marking this prepaid order delivered.",
      );
    const changed = await tx.order.updateMany({
      where: { id: orderId, status: before.status },
      data: {
        status: next,
        ...(next === "DELIVERED" && before.paymentMethod === "COD"
          ? { paymentStatus: "PAID" as const }
          : {}),
        ...(next === "CANCELLED" ? { stockRestoredAt: new Date() } : {}),
      },
    });
    if (changed.count !== 1)
      throw new Error(
        "Order was updated by another request. Refresh and retry.",
      );
    if (next === "CANCELLED" && !before.stockRestoredAt)
      for (const item of before.items)
        if (item.variantId)
          await tx.productVariant.update({
            where: { id: item.variantId },
            data: { stock: { increment: item.quantity } },
          });
    await tx.orderActivityLog.create({
      data: {
        orderId,
        message:
          note?.trim() || `Status updated to ${ORDER_STATUS_LABEL[next]}.`,
      },
    });
    if (next === "CANCELLED" || next === "DELIVERED")
      await tx.emailJob.upsert({
        where: {
          orderId_kind: {
            orderId,
            kind: next === "CANCELLED" ? "CANCELLED" : "DELIVERED_INVOICE",
          },
        },
        create: {
          orderId,
          kind: next === "CANCELLED" ? "CANCELLED" : "DELIVERED_INVOICE",
        },
        update: {},
      });
    return before;
  });
  if (!order) return;
  let siteName: string | null | undefined;
  try {
    siteName = (
      await prisma.appSettings.findUnique({
        where: { id: "singleton" },
        select: { siteName: true },
      })
    )?.siteName;
  } catch {
    siteName = undefined;
  }

  const trackingUrl = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/track-order?order=${order.orderNumber}&email=${encodeURIComponent(order.email)}`;

  try {
    if (status === "CANCELLED") {
      await deliverEmailJobs(orderId);
    } else if (status === "SHIPPED") {
      await sendShippingUpdateEmail({
        to: order.email,
        orderNumber: order.orderNumber,
        trackingUrl,
        trackingCarrier: order.trackingCarrier,
        trackingNumber: order.trackingNumber,
        note,
        siteName,
      });
    } else if (status === "DELIVERED") {
      // COD orders collect payment on delivery — mark PAID (if not already) so the customer
      // gets the same "Paid" invoice-with-PDF email that a card/PayPal order gets on
      // confirmation. markOrderPaid() is a no-op (and sends nothing) if already PAID, so a
      // card/PayPal order that was paid at checkout doesn't get a duplicate invoice here.
      await markOrderPaid(orderId, {
        activityMessage:
          'Payment status updated to "PAID" (order delivered — payment collected).',
      });
    } else {
      await sendOrderStatusUpdateEmail(
        order.email,
        order.orderNumber,
        ORDER_STATUS_LABEL[status] ?? status,
        trackingUrl,
        note,
        siteName,
      );
    }
  } catch (err) {
    console.error("Order status email/side-effects failed:", err);
  }

  await deliverEmailJobs(orderId);
  revalidatePath(`/admin/orders/${orderId}`);
  revalidatePath("/admin/orders");
}

export async function updateOrderTracking(
  orderId: string,
  trackingCarrier: string,
  trackingNumber: string,
) {
  await requireAdmin();
  await prisma.order.update({
    where: { id: orderId },
    data: { trackingCarrier, trackingNumber },
    select: { id: true },
  });
  await prisma.orderActivityLog.create({
    data: {
      orderId,
      message: `Tracking added: ${trackingCarrier} — ${trackingNumber}`,
    },
  });
  await deliverEmailJobs(orderId);
  revalidatePath(`/admin/orders/${orderId}`);
}

export async function updatePaymentStatus(
  orderId: string,
  paymentStatus: string,
) {
  await requireAdmin();

  z.enum(["PENDING", "PAID", "FAILED", "REFUNDED"]).parse(paymentStatus);
  if (paymentStatus === "PAID") {
    // Shared with the automatic Stripe webhook / PayPal capture handlers so a manual admin
    // override and an automatic gateway confirmation behave identically (activity log entry +
    // the "Paid" invoice email, sent exactly once).
    const changed = await markOrderPaid(orderId, {
      activityMessage: 'Payment status updated to "PAID" (manually, by admin).',
    });
    if (!changed) {
      // Already PAID — nothing to do, but still let a re-save of the same value pass silently.
    }
  } else {
    await prisma.order.update({
      where: { id: orderId },
      data: { paymentStatus: paymentStatus as never },
      select: { id: true },
    });
    await prisma.orderActivityLog.create({
      data: {
        orderId,
        message: `Payment status updated to "${paymentStatus}".`,
      },
    });
  }

  await deliverEmailJobs(orderId);
  revalidatePath(`/admin/orders/${orderId}`);
}
