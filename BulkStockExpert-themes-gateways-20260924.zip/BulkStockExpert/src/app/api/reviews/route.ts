import { NextRequest, NextResponse } from "next/server";
import { submitReview } from "@/app/actions/review-actions";
export async function POST(req: NextRequest) {
  try {
    const value = await req.json();
    const form = new FormData();
    for (const key of [
      "productId",
      "productSlug",
      "customerName",
      "email",
      "rating",
      "comment",
    ])
      if (value[key] != null) form.set(key, String(value[key]));
    const result = await submitReview({ ok: false, message: "" }, form);
    return NextResponse.json(result, { status: result.ok ? 201 : 400 });
  } catch {
    return NextResponse.json(
      { ok: false, message: "Invalid review request." },
      { status: 400 },
    );
  }
}
