import { NextRequest, NextResponse } from "next/server";
import { mollie } from "@/lib/payment-adapters-intl";
import { confirmVerifiedPayment } from "@/lib/gateway-confirm";

/** Mollie posts `id=tr_...` on every status change; we re-read the payment from Mollie's API. */
export async function POST(req: NextRequest) {
  try {
    const id = String((await req.formData()).get("id") ?? "");
    const r = await confirmVerifiedPayment("mollie", await mollie.verify(id));
    // 200 for anything we understood (Mollie retries non-2xx); unknown ids are simply ignored.
    return NextResponse.json({ received: true, outcome: r.outcome });
  } catch (error) {
    console.error("Mollie webhook failed", error instanceof Error ? error.message : error);
    return NextResponse.json({ error: "Verification unavailable" }, { status: 503 });
  }
}
