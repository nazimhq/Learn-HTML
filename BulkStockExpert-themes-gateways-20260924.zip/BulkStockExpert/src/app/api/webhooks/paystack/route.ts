import { NextRequest, NextResponse } from "next/server";
import { paystack } from "@/lib/payment-adapters-intl";
import { confirmVerifiedPayment } from "@/lib/gateway-confirm";

/** Paystack webhook (event: charge.success). Signature is checked, then the transaction is re-verified. */
export async function POST(req: NextRequest) {
  try {
    const raw = await req.text();
    if (!(await paystack.validSignature(raw, req.headers.get("x-paystack-signature"))))
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    const body = JSON.parse(raw);
    if (body?.event !== "charge.success") return NextResponse.json({ received: true });
    const r = await confirmVerifiedPayment("paystack", await paystack.verify(String(body.data?.reference ?? "")));
    return NextResponse.json({ received: true, outcome: r.outcome });
  } catch (error) {
    console.error("Paystack webhook failed", error instanceof Error ? error.message : error);
    return NextResponse.json({ error: "Verification unavailable" }, { status: 503 });
  }
}
