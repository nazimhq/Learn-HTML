import { NextRequest, NextResponse } from "next/server";
import { razorpay } from "@/lib/payment-adapters-intl";
import { confirmVerifiedPayment } from "@/lib/gateway-confirm";

/** Razorpay webhook (event: payment_link.paid). The link is re-read from Razorpay's API. */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null);
    const id = String(body?.payload?.payment_link?.entity?.id ?? "");
    if (!id) return NextResponse.json({ received: true });
    const r = await confirmVerifiedPayment("razorpay", await razorpay.verify(id));
    return NextResponse.json({ received: true, outcome: r.outcome });
  } catch (error) {
    console.error("Razorpay webhook failed", error instanceof Error ? error.message : error);
    return NextResponse.json({ error: "Verification unavailable" }, { status: 503 });
  }
}
