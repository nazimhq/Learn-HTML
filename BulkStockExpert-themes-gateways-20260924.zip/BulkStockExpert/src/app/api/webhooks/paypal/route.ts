import { NextRequest, NextResponse } from "next/server";
import { verifyPaypalWebhook } from "@/lib/payments";
import {
  findOrderByPaymentReference,
  markOrderPaid,
} from "@/lib/order-payment";
export async function POST(req: NextRequest) {
  try {
    const event = await req.json();
    if (!(await verifyPaypalWebhook(event, req.headers)))
      return NextResponse.json(
        { error: "Unverified callback" },
        { status: 400 },
      );
    if (event.event_type === "PAYMENT.CAPTURE.COMPLETED") {
      const capture = event.resource;
      const ref = capture?.supplementary_data?.related_ids?.order_id;
      if (!ref)
        return NextResponse.json(
          { error: "Missing order reference" },
          { status: 400 },
        );
      const order = await findOrderByPaymentReference(ref);
      if (
        !order ||
        capture.status !== "COMPLETED" ||
        capture.amount?.currency_code !== order.currency ||
        Math.round(Number(capture.amount?.value) * 100) !==
          Math.round(Number(order.total) * 100)
      )
        return NextResponse.json(
          { error: "Payment mismatch" },
          { status: 409 },
        );
      await markOrderPaid(order.id);
    }
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json(
      { error: "Callback processing unavailable" },
      { status: 503 },
    );
  }
}
