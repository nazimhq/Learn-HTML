import { NextRequest, NextResponse } from "next/server";
import { gatewayConfig } from "@/lib/gateway-settings";
import { prisma } from "@/lib/prisma";
import { markOrderPaid } from "@/lib/order-payment";
import { matchesPayment } from "@/lib/payment-validation";
export async function POST(req: NextRequest) {
  try {
    const f = await req.formData();
    const val = String(f.get("val_id") ?? "");
    if (!val || val.length > 100)
      return NextResponse.json({ error: "Invalid callback" }, { status: 400 });
    const c = await gatewayConfig("sslcommerz");
    const base =
      c.mode === "live"
        ? "https://securepay.sslcommerz.com"
        : "https://sandbox.sslcommerz.com";
    const query = new URLSearchParams({
      val_id: val,
      store_id: c.credentials.storeId,
      store_passwd: c.credentials.storePassword,
      format: "json",
    });
    const r = await fetch(
      `${base}/validator/api/validationserverAPI.php?${query}`,
      { cache: "no-store", signal: AbortSignal.timeout(15000) },
    );
    if (!r.ok) throw new Error("Validation unavailable");
    const v = await r.json();
    if (!["VALID", "VALIDATED"].includes(v.status))
      return NextResponse.json(
        { error: "Unverified payment" },
        { status: 400 },
      );
    const order = await prisma.order.findUnique({
      where: { id: String(v.tran_id) },
    });
    if (
      !order ||
      order.paymentGateway !== "sslcommerz" ||
      !matchesPayment(order, { currency: v.currency, amount: v.amount })
    )
      return NextResponse.json({ error: "Payment mismatch" }, { status: 400 });
    await markOrderPaid(order.id);
    return NextResponse.redirect(
      new URL(
        `/order-confirmation/${order.orderNumber}`,
        process.env.NEXT_PUBLIC_SITE_URL,
      ),
      303,
    );
  } catch (error) {
    console.error(
      "SSLCommerz verification failed",
      error instanceof Error ? error.name : "Error",
    );
    return NextResponse.json(
      { error: "Verification unavailable" },
      { status: 503 },
    );
  }
}
