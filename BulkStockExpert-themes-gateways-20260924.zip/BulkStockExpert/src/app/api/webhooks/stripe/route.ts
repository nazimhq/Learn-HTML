import { NextRequest, NextResponse } from "next/server";
import type Stripe from "stripe";
import { verifyStripeWebhookSignature } from "@/lib/payments";
import {
  markOrderPaid,
  findOrderByPaymentReference,
} from "@/lib/order-payment";

/**
 * Stripe calls this the moment a Checkout Session completes — set this route's full URL as the
 * endpoint in your Stripe Dashboard (Developers → Webhooks) once Card payments are configured
 * in Admin → Settings → Payments, listening for the "checkout.session.completed" event, and
 * paste the signing secret it gives you into that same admin settings page.
 */
export async function POST(req: NextRequest) {
  const signature = req.headers.get("stripe-signature");
  if (!signature)
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });

  const rawBody = await req.text();
  const event = await verifyStripeWebhookSignature(rawBody, signature);
  if (!event)
    return NextResponse.json(
      { error: "Invalid signature or Stripe not configured" },
      { status: 400 },
    );

  if (
    event.type === "checkout.session.completed" ||
    event.type === "checkout.session.async_payment_succeeded"
  ) {
    const session = event.data.object as Stripe.Checkout.Session;
    if (session.payment_status !== "paid")
      return NextResponse.json({ received: true });
    try {
      const order = await findOrderByPaymentReference(session.id);
      if (
        order &&
        session.amount_total === Math.round(Number(order.total) * 100) &&
        session.currency?.toUpperCase() === order.currency
      ) {
        await markOrderPaid(order.id, {
          activityMessage: "Payment confirmed automatically via Stripe.",
        });
      } else {
        return NextResponse.json(
          { error: "Order reference or amount mismatch" },
          { status: 409 },
        );
      }
    } catch (err) {
      console.error("Stripe webhook: failed to mark order paid:", err);
      // Return 500 so Stripe retries the webhook rather than silently losing the confirmation.
      return NextResponse.json({ error: "Internal error" }, { status: 500 });
    }
  }

  return NextResponse.json({ received: true });
}
