import { NextRequest, NextResponse } from "next/server";
import { flutterwave } from "@/lib/payment-adapters-intl";
import { confirmVerifiedPayment } from "@/lib/gateway-confirm";

/** Flutterwave webhook (event: charge.completed). The transaction is re-verified with Flutterwave's API. */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null);
    const id = String(body?.data?.id ?? "");
    if (!id) return NextResponse.json({ received: true });
    const v = await flutterwave.verify(id);
    if (body?.data?.tx_ref && v.reference !== String(body.data.tx_ref))
      return NextResponse.json({ error: "Reference mismatch" }, { status: 400 });
    const r = await confirmVerifiedPayment("flutterwave", v);
    return NextResponse.json({ received: true, outcome: r.outcome });
  } catch (error) {
    console.error("Flutterwave webhook failed", error instanceof Error ? error.message : error);
    return NextResponse.json({ error: "Verification unavailable" }, { status: 503 });
  }
}
