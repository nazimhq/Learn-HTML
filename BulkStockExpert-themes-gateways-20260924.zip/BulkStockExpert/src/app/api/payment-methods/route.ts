import { NextRequest, NextResponse } from "next/server";
import { REGIONS, Region } from "@/lib/gateway-catalog";
import { availableGateways } from "@/lib/gateway-settings";
import { getRegionPricing } from "@/lib/region-pricing";
export const dynamic = "force-dynamic";
export async function GET(req: NextRequest) {
  const region = (req.nextUrl.searchParams.get("region") ?? "GB") as Region;
  if (!Object.hasOwn(REGIONS, region))
    return NextResponse.json({ error: "Unsupported region" }, { status: 400 });
  try {
    const pricing = await getRegionPricing(region);
    const methods = await availableGateways(region);
    return NextResponse.json(
      { ...pricing, methods },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error && error.message.startsWith("Pricing for ")
            ? error.message
            : "Payment settings unavailable",
      },
      { status: 503 },
    );
  }
}
