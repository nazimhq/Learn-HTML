import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { buildInvoicePdf } from "@/lib/invoice";

/**
 * Downloads a PDF invoice for one order. Two ways in, matching the two checkout paths:
 *  - Signed-in customer: allowed when the order's userId matches their session.
 *  - Guest: allowed when ?email=<the order's email> is supplied (same proof-of-ownership
 *    pattern as /track-order, which guests already use to look up their order).
 */
export async function GET(
  req: NextRequest,
  { params: request }: { params: Promise<{ orderNumber: string }> },
) {
  const params = await request;
  const email = req.nextUrl.searchParams.get("email");
  const session = await getServerSession(authOptions);
  const userId = session?.user?.id;

  // Explicit select (rather than a bare include, which still implicitly asks for every
  // scalar field this generated Prisma client knows about) so a missing newer column
  // (Order.userId — see prisma/schema.prisma) can't 500 this whole download. userId is
  // requested separately and gracefully degraded to email-only ownership checks if the
  // live table doesn't have that column yet (PrismaClientKnownRequestError P2022).
  interface OrderForInvoice {
    orderNumber: string;
    currency: string;
    email: string;
    customerName: string;
    phone: string;
    addressLine1: string;
    addressLine2: string | null;
    city: string;
    county: string | null;
    postcode: string;
    country: string;
    deliveryCharge: unknown;
    subtotal: unknown;
    discount: unknown;
    total: unknown;
    paymentMethod: string;
    paymentStatus: string;
    createdAt: Date;
    updatedAt: Date;
    deliveryZone: { name: string } | null;
    items: {
      name: string;
      variantLabel: string | null;
      quantity: number;
      unitPrice: unknown;
    }[];
    userId?: string | null;
  }
  const baseOrderSelect = {
    orderNumber: true,
    currency: true,
    email: true,
    customerName: true,
    phone: true,
    addressLine1: true,
    addressLine2: true,
    city: true,
    county: true,
    postcode: true,
    country: true,
    deliveryCharge: true,
    subtotal: true,
    discount: true,
    total: true,
    paymentMethod: true,
    paymentStatus: true,
    createdAt: true,
    updatedAt: true,
    deliveryZone: { select: { name: true } },
    items: {
      select: {
        name: true,
        variantLabel: true,
        quantity: true,
        unitPrice: true,
      },
    },
  };
  let order: OrderForInvoice | null = null;
  try {
    // Cast: Order.userId is a new field (see prisma/schema.prisma) not yet in this sandbox's
    // stale generated Prisma client (src/lib/prisma.ts).
    order = (await prisma.order.findFirst({
      where: { orderNumber: params.orderNumber.toUpperCase() },
      select: { ...baseOrderSelect, userId: true } as never,
    })) as unknown as OrderForInvoice | null;
  } catch {
    // userId column likely doesn't exist yet on the live table — retry without it.
    order = (await prisma.order.findFirst({
      where: { orderNumber: params.orderNumber.toUpperCase() },
      select: baseOrderSelect,
    })) as unknown as OrderForInvoice | null;
  }
  if (!order)
    return NextResponse.json({ error: "Order not found." }, { status: 404 });

  const owns =
    (userId && order.userId === userId) ||
    (email && order.email.toLowerCase() === email.toLowerCase());
  if (!owns)
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });

  const settings = await prisma.appSettings
    .findUnique({
      where: { id: "singleton" },
      select: {
        siteName: true,
        contactEmail: true,
        logoUrl: true,
        contactPhone: true,
      },
    })
    .catch(() => null);
  const isPaid = order.paymentStatus === "PAID";

  const pdf = await buildInvoicePdf({
    settings: {
      logoUrl: settings?.logoUrl,
      siteName: settings?.siteName,
      contactEmail: settings?.contactEmail,
      contactPhone: settings?.contactPhone,
    },
    order: {
      orderNumber: order.orderNumber,
      currency: order.currency,
      customerName: order.customerName,
      email: order.email,
      phone: order.phone,
      addressLine1: order.addressLine1,
      addressLine2: order.addressLine2,
      city: order.city,
      county: order.county,
      postcode: order.postcode,
      country: order.country,
      deliveryZoneName: order.deliveryZone?.name,
      deliveryCharge: Number(order.deliveryCharge),
      subtotal: Number(order.subtotal),
      discount: Number(order.discount),
      total: Number(order.total),
      paymentMethod: order.paymentMethod,
      createdAt: order.createdAt,
      confirmedAt: order.updatedAt,
      items: order.items.map((it) => ({
        name: it.name,
        variantLabel: it.variantLabel,
        quantity: it.quantity,
        unitPrice: Number(it.unitPrice),
      })),
    },
    status: isPaid ? "paid" : "unpaid",
  });

  return new NextResponse(new Uint8Array(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="invoice-${order.orderNumber}.pdf"`,
    },
  });
}
