import { getActiveTheme } from "@/lib/site-theme-server";
export const dynamic = "force-dynamic";
export async function GET() {
  try {
    const t = await getActiveTheme();
    return Response.json(
      {
        accentTheme: t.accent,
        colorMode: t.skin === "nexaweb" ? "dark" : t.mode,
        skin: t.skin,
        source: t.source,
        nextChangeAt: t.nextChangeAt,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Unavailable" }, { status: 503 });
  }
}
