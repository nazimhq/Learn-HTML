import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getOrderForTracking } from "@/lib/order-lookup";
export async function GET(req: NextRequest) {
  const parsed = z
    .object({
      order: z
        .string()
        .trim()
        .min(3)
        .max(80)
        .regex(/^[a-z0-9-]+$/i),
      email: z.string().trim().email().max(254),
    })
    .safeParse(Object.fromEntries(req.nextUrl.searchParams));
  if (!parsed.success)
    return NextResponse.json(
      { error: "Enter a valid order number and email." },
      { status: 400 },
    );
  try {
    const order = await getOrderForTracking(
      parsed.data.order,
      parsed.data.email,
    );
    if (!order)
      return NextResponse.json(
        { error: "We couldn't find an order matching those details." },
        { status: 404 },
      );
    return NextResponse.json(order, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("track-order database lookup failed", error);
    return NextResponse.json(
      {
        error: "Tracking is temporarily unavailable. Please try again shortly.",
      },
      { status: 503 },
    );
  }
}
