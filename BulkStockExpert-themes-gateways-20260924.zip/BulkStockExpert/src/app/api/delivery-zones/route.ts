import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const zones = await prisma.deliveryZone.findMany({
      where: { isActive: true },
      orderBy: { position: "asc" },
      select: {
        countryCode: true,
        id: true,
        name: true,
        description: true,
        charge: true,
        freeOverAmount: true,
        postcodePrefixes: true,
        estimatedDays: true,
      },
    });
    return NextResponse.json(zones);
  } catch {
    return NextResponse.json([], { status: 200 });
  }
}
