import { NextRequest, NextResponse } from "next/server";
import { capturePaypalOrder } from "@/lib/payments";
import {
  markOrderPaid,
  findOrderByPaymentReference,
} from "@/lib/order-payment";

/**
 * PayPal redirects the shopper's browser here after they approve payment (this is the
 * `return_url` passed when the order was created — see createPaypalOrder in src/lib/payments.ts).
 * `token` is PayPal's own order id; we capture it (finalising the payment) then send the
 * shopper on to the normal order-confirmation page either way — a failed capture still leaves
 * the order recorded as Pending for manual follow-up, same as any other gateway hiccup.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const paypalOrderId = searchParams.get("token");
  const orderNumber = searchParams.get("order");
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? new URL(req.url).origin;

  if (!paypalOrderId || !orderNumber) {
    return NextResponse.redirect(`${siteUrl}/checkout?payment=error`);
  }

  try {
    const known = await findOrderByPaymentReference(paypalOrderId);
    if (!known || known.orderNumber !== orderNumber)
      return NextResponse.json(
        { error: "Payment reference mismatch" },
        { status: 400 },
      );
    const captured = await capturePaypalOrder(paypalOrderId, {
      total: Number(known.total),
      currency: known.currency,
      id: known.id,
    });
    if (captured) {
      const order = await findOrderByPaymentReference(paypalOrderId);
      if (order) {
        await markOrderPaid(order.id, {
          activityMessage: "Payment confirmed automatically via PayPal.",
        });
      } else {
        console.error(
          "PayPal capture: no order found for PayPal order id",
          paypalOrderId,
        );
      }
    } else {
      console.error(
        "PayPal capture did not complete for order id",
        paypalOrderId,
      );
    }
  } catch (err) {
    console.error("PayPal capture handler failed:", err);
  }

  return NextResponse.redirect(
    `${siteUrl}/order-confirmation/${orderNumber}?payment=paypal`,
  );
}
