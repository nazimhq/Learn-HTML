import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { bkash, flutterwave, mollie, paystack, razorpay } from "@/lib/payment-adapters-intl";
import { confirmVerifiedPayment } from "@/lib/gateway-confirm";

export const dynamic = "force-dynamic";

/**
 * Where hosted payment pages send the shopper back. The query string is only used to find
 * WHICH payment to look up; the result always comes from the provider's API.
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  const q = req.nextUrl.searchParams;
  const site = process.env.NEXT_PUBLIC_SITE_URL || req.nextUrl.origin;
  const done = (orderNumber: string | undefined, state: string) =>
    NextResponse.redirect(
      new URL(orderNumber ? `/order-confirmation/${encodeURIComponent(orderNumber)}?payment=${state}` : `/checkout?payment=${state}`, site),
      303,
    );

  try {
    let result: { outcome: string; orderNumber?: string } | null = null;
    switch (provider) {
      case "mollie": {
        const order = await prisma.order.findUnique({
          where: { orderNumber: String(q.get("order") ?? "").slice(0, 80) },
          select: { paymentReference: true, paymentGateway: true, orderNumber: true },
        });
        if (!order?.paymentReference || order.paymentGateway !== "mollie") return done(undefined, "failed");
        result = await confirmVerifiedPayment("mollie", await mollie.verify(order.paymentReference));
        break;
      }
      case "razorpay":
        result = await confirmVerifiedPayment("razorpay", await razorpay.verify(String(q.get("razorpay_payment_link_id") ?? "")));
        break;
      case "paystack":
        result = await confirmVerifiedPayment("paystack", await paystack.verify(String(q.get("reference") ?? q.get("trxref") ?? "")));
        break;
      case "flutterwave": {
        const txRef = String(q.get("tx_ref") ?? "");
        const id = String(q.get("transaction_id") ?? "");
        if (q.get("status") === "cancelled" || !id) {
          const o = await prisma.order.findFirst({ where: { paymentReference: txRef, paymentGateway: "flutterwave" }, select: { orderNumber: true } });
          return done(o?.orderNumber, "cancelled");
        }
        const v = await flutterwave.verify(id);
        if (v.reference !== txRef) return done(undefined, "failed");
        result = await confirmVerifiedPayment("flutterwave", v);
        break;
      }
      case "bkash": {
        const paymentId = String(q.get("paymentID") ?? "");
        const order = await prisma.order.findFirst({
          where: { paymentReference: paymentId, paymentGateway: "bkash" },
          select: { orderNumber: true },
        });
        if (!order) return done(undefined, "failed");
        if (q.get("status") !== "success") return done(order.orderNumber, q.get("status") === "cancel" ? "cancelled" : "failed");
        const v = await bkash.verify(paymentId);
        if (v.invoice && v.invoice !== order.orderNumber) return done(order.orderNumber, "failed");
        result = await confirmVerifiedPayment("bkash", v);
        break;
      }
      default:
        return NextResponse.json({ error: "Unknown provider" }, { status: 404 });
    }
    const state = result.outcome === "paid" ? "success" : result.outcome === "unpaid" ? "pending" : "failed";
    return done(result.orderNumber, state);
  } catch (error) {
    console.error(`${provider} return verification failed`, error instanceof Error ? error.message : error);
    return done(undefined, "unavailable");
  }
}
