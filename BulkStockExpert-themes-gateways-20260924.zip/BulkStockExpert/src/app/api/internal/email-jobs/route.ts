import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { deliverEmailJobs } from "@/lib/email-jobs";
export async function POST(req: NextRequest) {
  const expected = `Bearer ${process.env.INTERNAL_JOB_SECRET ?? ""}`;
  const actual = req.headers.get("authorization") ?? "";
  if (
    !process.env.INTERNAL_JOB_SECRET ||
    actual.length !== expected.length ||
    !timingSafeEqual(Buffer.from(actual), Buffer.from(expected))
  )
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  await deliverEmailJobs();
  return NextResponse.json({ ok: true });
}
