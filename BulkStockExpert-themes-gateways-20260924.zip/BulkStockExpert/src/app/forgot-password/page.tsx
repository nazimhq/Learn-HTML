"use client";

import { useState } from "react";
import Link from "next/link";
import { KeyRound } from "lucide-react";
import { requestPasswordReset } from "@/app/actions/auth-actions";

// Forces this page to render per-request instead of being prerendered at build time. This
// host (shared cPanel/CloudLinux, tight LVE process/CPU limits) has been observed to hang or
// crash the Prisma query engine when it's exercised during `next build`'s static-generation
// pass; this page needs live data on every request anyway, so build-time prerendering was
// never correct here regardless of the host issue.
export const dynamic = "force-dynamic";

/**
 * Shared "forgot password" entry point for BOTH admin and customer accounts (same User
 * table) — linked from /admin/login and /account/login.
 */
export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    await requestPasswordReset(
      email,
      typeof window !== "undefined" ? window.location.origin : undefined,
    );
    setSubmitting(false);
    setSent(true);
  }

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-surface px-4">
      <div className="w-full max-w-sm rounded-2xl border border-ink-900/10 bg-white p-7 dark:border-ink-50/10 dark:bg-panel">
        <div className="mb-5 flex flex-col items-center text-center">
          <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 text-ink-50 dark:bg-ink-50 dark:text-ink-900">
            <KeyRound size={18} />
          </div>
          <h1 className="font-display text-xl">Reset your password</h1>
          <p className="mt-1 text-[12.5px] text-ink-400 dark:text-ink-50/50">
            Enter the email on your account and we&apos;ll send you a reset
            link.
          </p>
        </div>

        {sent ? (
          <p className="rounded-lg bg-emerald-50 px-3.5 py-3 text-[13px] text-emerald-700">
            If that email has an account, a password reset link is on its way —
            check your inbox (and spam folder).
          </p>
        ) : (
          <form onSubmit={onSubmit} className="flex flex-col gap-3">
            <div>
              <label className="field-label">Email</label>
              <input
                className="field-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="btn-primary mt-2 w-full"
            >
              {submitting ? "Sending..." : "Send reset link"}
            </button>
          </form>
        )}

        <div className="mt-5 flex justify-center gap-4 text-[12.5px] text-ink-400 dark:text-ink-50/50">
          <Link
            href="/admin/login"
            className="hover:text-ink-900 dark:hover:text-ink-50"
          >
            Admin sign in
          </Link>
          <span>·</span>
          <Link
            href="/account/login"
            className="hover:text-ink-900 dark:hover:text-ink-50"
          >
            Customer sign in
          </Link>
        </div>
      </div>
    </div>
  );
}
