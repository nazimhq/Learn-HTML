import { Mail, Phone, MapPin } from "lucide-react";
import { prisma } from "@/lib/prisma";

// Force this route to be rendered fresh on every request rather than statically optimized at
// build time. Without this, Next.js can bake in whatever getSettings() returned during `npm
// run build` (in the sandbox, with no live DB access, that's always null) as permanent static
// HTML — so contact email/phone would silently stay blank forever, no matter what the admin
// saves in Settings, until a fresh production build/deploy. (Found 2026-09-17: AppSettings had
// real contactEmail/contactPhone saved, but the live /contact page still only showed the
// address block.)
export const dynamic = "force-dynamic";

async function getSettings() {
  try {
    return await prisma.appSettings.findUnique({ where: { id: "singleton" } });
  } catch {
    return null;
  }
}

export default async function ContactPage() {
  const settings = await getSettings();

  return (
    <div className="container-page max-w-2xl py-14">
      <h1 className="mb-2 font-display text-3xl text-ink-900 dark:text-ink-50">
        Contact us
      </h1>
      <p className="mb-8 text-[14px] text-ink-400 dark:text-ink-50/60">
        Questions about an order or a pallet listing? Reach us any of these
        ways.
      </p>
      <div className="flex flex-col gap-4">
        {settings?.contactEmail && (
          <a
            href={`mailto:${settings.contactEmail}`}
            className="flex items-center gap-3 rounded-xl border border-ink-900/10 p-4 text-[14px] font-medium text-ink-900 hover:bg-ink-900/5 dark:border-ink-50/10 dark:text-ink-50 dark:hover:bg-ink-50/5"
          >
            <Mail size={18} className="text-cta" /> {settings.contactEmail}
          </a>
        )}
        {settings?.contactPhone && (
          <a
            href={`tel:${settings.contactPhone}`}
            className="flex items-center gap-3 rounded-xl border border-ink-900/10 p-4 text-[14px] font-medium text-ink-900 hover:bg-ink-900/5 dark:border-ink-50/10 dark:text-ink-50 dark:hover:bg-ink-50/5"
          >
            <Phone size={18} className="text-cta" /> {settings.contactPhone}
          </a>
        )}
        <div className="flex items-center gap-3 rounded-xl border border-ink-900/10 p-4 text-[14px] font-medium text-ink-900 dark:border-ink-50/10 dark:text-ink-50">
          <MapPin size={18} className="text-cta" /> United Kingdom
        </div>
      </div>
    </div>
  );
}
