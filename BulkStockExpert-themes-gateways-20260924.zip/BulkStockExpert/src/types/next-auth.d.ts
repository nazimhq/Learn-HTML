import "next-auth";

declare module "next-auth" {
  interface Session {
    user?: {
      name?: string | null;
      email?: string | null;
      role?: string;
      id?: string;
      isSuperAdmin?: boolean;
    };
  }
  interface User {
    role?: string;
    isSuperAdmin?: boolean;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role?: string;
    id?: string;
    isSuperAdmin?: boolean;
  }
}
