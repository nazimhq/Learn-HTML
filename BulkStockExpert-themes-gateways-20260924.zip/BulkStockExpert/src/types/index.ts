export interface ProductCardData {
  id: string;
  name: string;
  slug: string;
  brand: string | null;
  basePrice: number;
  compareAtPrice: number | null;
  imageUrl: string;
  ratingAvg: number;
  reviewCount: number;
  inStock: boolean;
  /** Only populated by the homepage pallet browser (src/components/home/product-browser.tsx). */
  tags?: string[];
  categorySlug?: string;
  categoryName?: string;
  createdAt?: string;
}

export interface CartLine {
  productId: string;
  variantId: string;
  name: string;
  variantLabel?: string | null;
  price: number;
  imageUrl: string;
  qty: number;
  maxStock: number;
}
