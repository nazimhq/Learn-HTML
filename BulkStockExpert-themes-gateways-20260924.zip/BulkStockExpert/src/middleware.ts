import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

// Custom middleware function (rather than the plain options-object shorthand) so we can stamp
// every request that passes this gate with a header the admin layout can read. That header is
// what tells src/app/admin/layout.tsx "middleware already confirmed this request is an
// authenticated ADMIN" — see the comment there for why that matters (the sidebar used to
// disappear under this host's slow/hanging getServerSession() calls).
export default withAuth(
  function middleware(req) {
    // Setting this on the outgoing *response* headers wouldn't reach the Server Component
    // render — it has to go on the *request* headers Next.js forwards onward, per Next's
    // documented middleware pattern for passing data to the page/layout via headers().
    const requestHeaders = new Headers(req.headers);
    requestHeaders.set("x-admin-authenticated", "1");
    return NextResponse.next({ request: { headers: requestHeaders } });
  },
  {
    callbacks: {
      authorized: ({ token }) => token?.role === "ADMIN",
    },
    pages: { signIn: "/admin/login" },
  },
);

export const config = {
  // Protect every /admin route except the login page itself. IMPORTANT: "/admin/((?!login).*)"
  // alone does NOT match the bare "/admin" dashboard-root path (it requires a "/" after "admin"
  // followed by more characters) — that gap let the dashboard render with no auth check at all
  // and no sidebar (found 2026-09-17: /admin loaded real revenue/order data with zero gating,
  // while /admin/orders etc. were correctly protected). Matching "/admin" explicitly closes it.
  matcher: ["/admin", "/admin/((?!login).*)"],
};
