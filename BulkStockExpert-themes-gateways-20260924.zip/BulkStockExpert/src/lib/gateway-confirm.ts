import { prisma } from "@/lib/prisma";
import { markOrderPaid } from "@/lib/order-payment";
import { matchesPayment } from "@/lib/payment-validation";
import type { VerifiedPayment } from "@/lib/payment-adapters-intl";

export type ConfirmOutcome = "paid" | "unpaid" | "mismatch" | "not_found";

const NAMES: Record<string, string> = {
  mollie: "Mollie",
  razorpay: "Razorpay",
  paystack: "Paystack",
  flutterwave: "Flutterwave",
  bkash: "bKash",
};

/**
 * Applies a provider-verified payment to its order. The order must have been sent to this
 * gateway with this exact reference, and the verified amount/currency must match the order.
 * Idempotent: markOrderPaid() is a no-op for an order that is already PAID.
 */
export async function confirmVerifiedPayment(
  gateway: string,
  v: VerifiedPayment,
): Promise<{ outcome: ConfirmOutcome; orderNumber?: string }> {
  const order = await prisma.order.findFirst({
    where: { paymentReference: v.reference, paymentGateway: gateway },
  });
  if (!order || (v.orderId && v.orderId !== order.id)) return { outcome: "not_found" };
  if (!v.paid) return { outcome: "unpaid", orderNumber: order.orderNumber };
  if (!matchesPayment(order, { amount: v.amount, currency: v.currency })) {
    console.error(`${gateway}: verified amount/currency does not match order ${order.orderNumber}`);
    await prisma.orderActivityLog.create({
      data: {
        orderId: order.id,
        message: `A ${NAMES[gateway] ?? gateway} payment was received but the amount or currency did not match. Check it in the provider dashboard before shipping.`,
      },
    });
    return { outcome: "mismatch", orderNumber: order.orderNumber };
  }
  await markOrderPaid(order.id, {
    activityMessage: `Payment confirmed automatically via ${NAMES[gateway] ?? gateway}.`,
  });
  return { outcome: "paid", orderNumber: order.orderNumber };
}
