import { prisma } from "@/lib/prisma";
import {
  accentSchema,
  modeSchema,
  parseSlots,
  resolveTheme,
  skinSchema,
  type ResolvedTheme,
  type RotationConfig,
  type ThemeLook,
} from "@/lib/site-theme";

/** Rotation config, or null if the SiteTheme table doesn't exist yet (migration not run). */
export async function getRotationConfig(): Promise<RotationConfig | null> {
  try {
    const row = await prisma.siteTheme.findUnique({ where: { id: "singleton" } });
    if (!row) return null;
    return {
      skin: row.skin,
      rotationEnabled: row.rotationEnabled,
      rotationMode: row.rotationMode,
      rotationHours: row.rotationHours,
      timezone: row.timezone,
      slots: parseSlots(row.slots),
    };
  } catch {
    return null;
  }
}

/** The admin's fixed look: accent + mode from AppSettings, design from SiteTheme. */
export async function getBaseLook(cfg?: RotationConfig | null): Promise<ThemeLook> {
  const settings = await prisma.appSettings
    .findUnique({ where: { id: "singleton" }, select: { accentTheme: true, colorMode: true } })
    .catch(() => null);
  return {
    skin: skinSchema.catch("classic").parse(cfg?.skin),
    accent: accentSchema.catch("gold").parse(settings?.accentTheme),
    mode: modeSchema.catch("light").parse(settings?.colorMode),
  };
}

/** The look that should be live right now (respecting the automatic rotation). */
export async function getActiveTheme(now = new Date()): Promise<ResolvedTheme> {
  const cfg = await getRotationConfig();
  const base = await getBaseLook(cfg);
  return resolveTheme(base, cfg, now);
}
