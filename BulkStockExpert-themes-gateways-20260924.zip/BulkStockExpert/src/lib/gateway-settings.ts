import { getPaymentSettings } from "@/lib/payments";
import { unstable_cache, revalidateTag } from "next/cache";
import { prisma } from "@/lib/prisma";
import { decryptSecret } from "@/lib/payment-crypto";
import { GATEWAYS, Region } from "@/lib/gateway-catalog";
const cachedRows = unstable_cache(
  () => prisma.gatewayConfig.findMany(),
  ["gateway-config-v1"],
  { tags: ["gateways"], revalidate: 30 },
);
export function invalidateGateways() {
  revalidateTag("gateways");
}
export async function gatewayConfig(id: string) {
  const rows = await cachedRows();
  const row = rows.find((r) => r.id === id);
  return {
    enabled:
      row?.enabled ??
      (id === "cod" ? (await getPaymentSettings()).codEnabled : false),
    mode: row?.mode ?? "sandbox",
    credentials: row?.credentials
      ? (JSON.parse(decryptSecret(row.credentials)!) as Record<string, string>)
      : {},
  };
}
export async function availableGateways(region: Region) {
  const legacy = await getPaymentSettings();
  const result: { id: string; name: string }[] = [];
  const rows = await cachedRows();
  if (region !== "BD") {
    if (
      !rows.some((r) => r.id === "stripe") &&
      legacy.cardEnabled &&
      legacy.stripeSecretKey
    )
      result.push({ id: "stripe", name: "Stripe · cards and wallets" });
    if (
      !rows.some((r) => r.id === "paypal") &&
      legacy.paypalEnabled &&
      legacy.paypalClientId &&
      legacy.paypalClientSecret
    )
      result.push({ id: "paypal", name: "PayPal" });
  }

  for (const gateway of GATEWAYS.filter(
    (g) => g.ready && g.regions.includes(region),
  )) {
    const config = await gatewayConfig(gateway.id);
    const source = ["klarna", "clearpay"].includes(gateway.id)
      ? await gatewayConfig("stripe")
      : config;
    const fields = ["klarna", "clearpay"].includes(gateway.id)
      ? ["secretKey"]
      : gateway.fields;
    if (
      config.enabled &&
      source.enabled &&
      fields.every((f) => source.credentials[f])
    )
      result.push({ id: gateway.id, name: gateway.name });
  }
  return result;
}
