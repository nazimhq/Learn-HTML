import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/admin/login" },
  providers: [
    CredentialsProvider({
      name: "Email and password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
        });
        if (!user || !user.isActive) return null;
        // Both admin and customer accounts sign in through this same provider — the admin
        // panel itself is still gated separately by role in middleware.ts (ADMIN only), and
        // the admin login page double-checks the returned role and signs a non-admin back out.

        const valid = await bcrypt.compare(
          credentials.password,
          user.passwordHash,
        );
        if (!valid) return null;

        // isSuperAdmin is a newer column — some deployments' generated Prisma Client
        // predates it, so `user.isSuperAdmin` (typed) isn't safe to read. A raw query
        // works against the DB directly regardless of what the generated client knows
        // about; if the column doesn't exist yet either, this just fails safe to false.
        let isSuperAdmin = false;
        try {
          const rows = await prisma.$queryRaw<Array<{ isSuperAdmin: number }>>`
            SELECT isSuperAdmin FROM \`User\` WHERE id = ${user.id} LIMIT 1
          `;
          isSuperAdmin = !!rows[0]?.isSuperAdmin;
        } catch (err) {
          console.error(
            "isSuperAdmin lookup failed (column may not exist yet):",
            err,
          );
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          isSuperAdmin,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as { role: string }).role;
        token.id = (user as { id: string }).id;
        token.isSuperAdmin =
          (user as { isSuperAdmin?: boolean }).isSuperAdmin ?? false;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as { role?: string }).role = token.role as string;
        (session.user as { id?: string }).id = token.id as string;
        (session.user as { isSuperAdmin?: boolean }).isSuperAdmin =
          token.isSuperAdmin as boolean;
      }
      return session;
    },
  },
};
