export const SITE_NAME =
  process.env.NEXT_PUBLIC_SITE_NAME ?? "BulkStockExpert Ltd";
export const CURRENCY = process.env.NEXT_PUBLIC_CURRENCY ?? "GBP";

export const CURRENCY_SYMBOLS: Record<string, string> = {
  GBP: "£",
  EUR: "€",
  USD: "US$",
  CAD: "CA$",
  BDT: "৳",
  AUD: "A$",
  AED: "AED ",
  INR: "₹",
  NGN: "₦",
  GHS: "GH₵",
  KES: "KSh ",
  ZAR: "R ",
};

export function formatMoney(
  amount: number | string | { toString(): string },
  currency = CURRENCY,
): string {
  const n = Number(amount);
  const symbol = CURRENCY_SYMBOLS[currency] ?? currency + " ";
  return `${symbol}${n.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** UK outward-postcode prefix, e.g. "SW1A 1AA" -> "SW1A", "EH1 1BB" -> "EH1". */
export function outwardPostcode(postcode: string): string {
  const cleaned = postcode.trim().toUpperCase().replace(/\s+/g, " ");
  const parts = cleaned.split(" ");
  if (parts.length >= 2) return parts[0];
  // No space typed yet — best-effort: strip the last 3 chars (inward code is always 3 chars).
  return cleaned.length > 3 ? cleaned.slice(0, -3) : cleaned;
}

export function generateOrderNumber(seq: number): string {
  return `BSE-${(100000 + seq).toString()}`;
}

export const ORDER_STATUS_LABEL: Record<string, string> = {
  PENDING: "Order received",
  PROCESSING: "Preparing your order",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
};

export const ORDER_STATUS_SEQUENCE = [
  "PENDING",
  "PROCESSING",
  "SHIPPED",
  "DELIVERED",
] as const;
