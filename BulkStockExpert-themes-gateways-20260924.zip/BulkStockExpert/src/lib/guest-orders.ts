"use client";

/**
 * Guest order history, kept entirely in this browser (no account = no server-side record
 * tied to a person, just the order rows themselves looked up by order number + email).
 * Clearing browser data clears this list, same as the cart — that's the trade-off guests
 * accept by not creating an account.
 */
const ORDERS_KEY = "bse-guest-orders";
const SESSION_KEY = "bse-session-id";

export interface GuestOrderRef {
  orderNumber: string;
  email: string;
  placedAt: string;
}

export function getGuestOrders(): GuestOrderRef[] {
  try {
    const raw = localStorage.getItem(ORDERS_KEY);
    return raw ? (JSON.parse(raw) as GuestOrderRef[]) : [];
  } catch {
    return [];
  }
}

export function addGuestOrder(orderNumber: string, email: string) {
  try {
    const existing = getGuestOrders().filter(
      (o) => o.orderNumber !== orderNumber,
    );
    existing.unshift({
      orderNumber,
      email,
      placedAt: new Date().toISOString(),
    });
    localStorage.setItem(ORDERS_KEY, JSON.stringify(existing.slice(0, 50)));
  } catch {
    // localStorage unavailable (private mode, etc.) — nothing to persist, checkout still works.
  }
}

/** Stable per-browser id used only for real-time abandoned-checkout lead capture — not a
 *  login, not sent anywhere except attached to that one draft checkout row. */
export function getOrCreateSessionId(): string {
  try {
    let id = localStorage.getItem(SESSION_KEY);
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem(SESSION_KEY, id);
    }
    return id;
  } catch {
    return "";
  }
}
