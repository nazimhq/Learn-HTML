import { decryptSecret } from "@/lib/payment-crypto";
import Stripe from "stripe";
import { prisma } from "@/lib/prisma";

// Cast throughout: PaymentSettings is a new Prisma model (see prisma/schema.prisma) not yet in
// this sandbox's stale generated Prisma client (src/lib/prisma.ts) — same pattern used for the
// other new models added this project (AbandonedCheckout, Notification, Category.imageUrl…).
interface PaymentSettingsRow {
  id: string;
  codEnabled: boolean;
  cardEnabled: boolean;
  stripePublishableKey: string | null;
  stripeSecretKey: string | null;
  stripeWebhookSecret: string | null;
  paypalEnabled: boolean;
  paypalClientId: string | null;
  paypalClientSecret: string | null;
  paypalMode: string;
}

const DEFAULT_SETTINGS: PaymentSettingsRow = {
  id: "singleton",
  codEnabled: true,
  cardEnabled: false,
  stripePublishableKey: null,
  stripeSecretKey: null,
  stripeWebhookSecret: null,
  paypalEnabled: false,
  paypalClientId: null,
  paypalClientSecret: null,
  paypalMode: "sandbox",
};

export async function getPaymentSettings(): Promise<PaymentSettingsRow> {
  try {
    const row = await (
      prisma as unknown as {
        paymentSettings: {
          findUnique: (a: unknown) => Promise<PaymentSettingsRow | null>;
        };
      }
    ).paymentSettings.findUnique({ where: { id: "singleton" } });
    if (!row) return DEFAULT_SETTINGS;
    for (const key of [
      "stripePublishableKey",
      "stripeSecretKey",
      "stripeWebhookSecret",
      "paypalClientId",
      "paypalClientSecret",
    ] as const)
      row[key] = decryptSecret(row[key]);
    return row;
  } catch {
    // Table not migrated yet on this environment, or the DB is unreachable — degrade to
    // "Cash on Delivery only", the same safe default the checkout has always had.
    return DEFAULT_SETTINGS;
  }
}

/** Public-safe view — no secret keys, just which methods are usable right now. */
export async function getEnabledPaymentMethods() {
  const s = await getPaymentSettings();
  return {
    cod: s.codEnabled,
    card: s.cardEnabled && Boolean(s.stripeSecretKey),
    paypal:
      s.paypalEnabled && Boolean(s.paypalClientId && s.paypalClientSecret),
  };
}

function getStripeClient(secretKey: string) {
  return new Stripe(secretKey);
}

/**
 * Creates a Stripe Checkout Session for the given order total and returns its hosted-page URL
 * to redirect the shopper to. Returns null if Stripe isn't configured/enabled — the caller
 * falls back to the existing "record as Pending, chase payment manually" behaviour.
 */
export async function createStripeCheckoutSession(input: {
  orderNumber: string;
  orderId: string;
  amountGbp: number;
  customerEmail: string;
  siteUrl: string;
  currency?: string;
  gateway?: string;
}): Promise<{ url: string; sessionId: string } | null> {
  const settings = await getPaymentSettings();
  if (!settings.cardEnabled || !settings.stripeSecretKey) return null;

  const stripe = getStripeClient(settings.stripeSecretKey);
  const session = await stripe.checkout.sessions.create(
    {
      mode: "payment",
      payment_method_types:
        input.gateway === "klarna"
          ? ["klarna"]
          : input.gateway === "clearpay"
            ? ["afterpay_clearpay"]
            : ["card"],
      customer_email: input.customerEmail,
      line_items: [
        {
          price_data: {
            currency: (input.currency ?? "GBP").toLowerCase(),
            unit_amount: Math.round(input.amountGbp * 100),
            product_data: { name: `Order ${input.orderNumber}` },
          },
          quantity: 1,
        },
      ],
      success_url: `${input.siteUrl}/order-confirmation/${input.orderNumber}?payment=success`,
      cancel_url: `${input.siteUrl}/checkout?payment=cancelled`,
      metadata: { orderId: input.orderId, orderNumber: input.orderNumber },
    },
    { idempotencyKey: `checkout-${input.orderId}` },
  );

  if (!session.url) return null;
  return { url: session.url, sessionId: session.id };
}

export async function verifyStripeWebhookSignature(
  rawBody: string,
  signature: string,
) {
  const settings = await getPaymentSettings();
  if (!settings.stripeSecretKey || !settings.stripeWebhookSecret) return null;
  const stripe = getStripeClient(settings.stripeSecretKey);
  try {
    return stripe.webhooks.constructEvent(
      rawBody,
      signature,
      settings.stripeWebhookSecret,
    );
  } catch (err) {
    console.error("Stripe webhook signature verification failed:", err);
    return null;
  }
}

const PAYPAL_API_BASE: Record<string, string> = {
  sandbox: "https://api-m.sandbox.paypal.com",
  live: "https://api-m.paypal.com",
};

async function getPaypalAccessToken(
  settings: PaymentSettingsRow,
): Promise<string | null> {
  if (!settings.paypalClientId || !settings.paypalClientSecret) return null;
  const base = PAYPAL_API_BASE[settings.paypalMode] ?? PAYPAL_API_BASE.sandbox;
  const auth = Buffer.from(
    `${settings.paypalClientId}:${settings.paypalClientSecret}`,
  ).toString("base64");
  const res = await fetch(`${base}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) {
    console.error(
      "PayPal OAuth token request failed:",
      res.status,
      await res.text().catch(() => ""),
    );
    return null;
  }
  const json = (await res.json()) as { access_token?: string };
  return json.access_token ?? null;
}

/**
 * Creates a PayPal order (v2 Orders API) and returns the "approve" link to redirect the
 * shopper to. Returns null if PayPal isn't configured/enabled — same graceful fallback as
 * Stripe above.
 */
export async function createPaypalOrder(input: {
  orderNumber: string;
  orderId: string;
  amountGbp: number;
  siteUrl: string;
  currency?: string;
  gateway?: string;
}): Promise<{ approveUrl: string; paypalOrderId: string } | null> {
  const settings = await getPaymentSettings();
  if (!settings.paypalEnabled) return null;
  const token = await getPaypalAccessToken(settings);
  if (!token) return null;

  const base = PAYPAL_API_BASE[settings.paypalMode] ?? PAYPAL_API_BASE.sandbox;
  const res = await fetch(`${base}/v2/checkout/orders`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    signal: AbortSignal.timeout(20000),
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          custom_id: input.orderId,
          invoice_id: input.orderNumber,
          amount: {
            currency_code: input.currency ?? "GBP",
            value: input.amountGbp.toFixed(2),
          },
        },
      ],
      application_context: {
        return_url: `${input.siteUrl}/api/payments/paypal/capture?order=${input.orderNumber}`,
        cancel_url: `${input.siteUrl}/checkout?payment=cancelled`,
        user_action: "PAY_NOW",
        brand_name:
          (
            await prisma.appSettings.findUnique({
              where: { id: "singleton" },
              select: { siteName: true },
            })
          )?.siteName ?? "Store",
      },
    }),
  });
  if (!res.ok) {
    console.error(
      "PayPal order creation failed:",
      res.status,
      await res.text().catch(() => ""),
    );
    return null;
  }
  const json = (await res.json()) as {
    id: string;
    links: { rel: string; href: string }[];
  };
  const approve = json.links.find(
    (l) => l.rel === "approve" || l.rel === "payer-action",
  );
  if (!approve) return null;
  return { approveUrl: approve.href, paypalOrderId: json.id };
}

/** Captures a previously-approved PayPal order (called from the return_url handler). */
export async function capturePaypalOrder(
  paypalOrderId: string,
  expected: { total: number; currency: string; id: string },
): Promise<boolean> {
  const settings = await getPaymentSettings();
  const token = await getPaypalAccessToken(settings);
  if (!token) return false;
  const base = PAYPAL_API_BASE[settings.paypalMode] ?? PAYPAL_API_BASE.sandbox;
  const res = await fetch(
    `${base}/v2/checkout/orders/${paypalOrderId}/capture`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "PayPal-Request-Id": `capture-${expected.id}`,
      },
      signal: AbortSignal.timeout(20000),
    },
  );
  if (!res.ok) {
    console.error(
      "PayPal capture failed:",
      res.status,
      await res.text().catch(() => ""),
    );
    return false;
  }
  const json = await res.json();
  const unit = json.purchase_units?.[0];
  const capture = unit?.payments?.captures?.[0];
  return (
    json.status === "COMPLETED" &&
    capture?.status === "COMPLETED" &&
    capture.amount?.currency_code === expected.currency &&
    Math.round(Number(capture.amount?.value) * 100) ===
      Math.round(expected.total * 100) &&
    (!unit.custom_id || unit.custom_id === expected.id)
  );
}

export async function verifyPaypalWebhook(
  event: unknown,
  headers: Headers,
): Promise<boolean> {
  const settings = await getPaymentSettings();
  const token = await getPaypalAccessToken(settings);
  const config = await prisma.gatewayConfig.findUnique({
    where: { id: "paypal" },
  });
  const credentials = config?.credentials
    ? JSON.parse(decryptSecret(config.credentials)!)
    : {};
  if (!token || !credentials.webhookId) return false;
  const base = PAYPAL_API_BASE[settings.paypalMode] ?? PAYPAL_API_BASE.sandbox;
  const response = await fetch(
    `${base}/v1/notifications/verify-webhook-signature`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      signal: AbortSignal.timeout(20000),
      body: JSON.stringify({
        auth_algo: headers.get("paypal-auth-algo"),
        cert_url: headers.get("paypal-cert-url"),
        transmission_id: headers.get("paypal-transmission-id"),
        transmission_sig: headers.get("paypal-transmission-sig"),
        transmission_time: headers.get("paypal-transmission-time"),
        webhook_id: credentials.webhookId,
        webhook_event: event,
      }),
    },
  );
  return (
    response.ok && (await response.json()).verification_status === "SUCCESS"
  );
}
