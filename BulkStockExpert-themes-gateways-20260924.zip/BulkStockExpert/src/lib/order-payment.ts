import { deliverEmailJobs } from "@/lib/email-jobs";
import { prisma } from "@/lib/prisma";
import { sendPaidInvoiceEmail } from "@/lib/email";
import { buildInvoicePdf } from "@/lib/invoice";

/**
 * Atomically marks an order PAID and queues a retryable invoice email — shared by the admin
 * manual "update payment status" action and the automatic Stripe webhook / PayPal capture
 * handlers, so all three paths behave identically. Safe to call more than once for the same
 * order: it's a no-op (returns false) if the order is already PAID.
 */
export async function markOrderPaid(
  orderId: string,
  opts?: { activityMessage?: string },
): Promise<boolean> {
  const changed = await prisma.$transaction(async (tx) => {
    const claim = await tx.order.updateMany({
      where: { id: orderId, paymentStatus: { in: ["PENDING", "FAILED"] } },
      data: { paymentStatus: "PAID" },
    });
    if (!claim.count) return false;
    await tx.orderActivityLog.create({
      data: { orderId, message: opts?.activityMessage ?? "Payment confirmed." },
    });
    await tx.emailJob.upsert({
      where: { orderId_kind: { orderId, kind: "PAID_INVOICE" } },
      create: { orderId, kind: "PAID_INVOICE" },
      update: {},
    });
    return true;
  });
  await deliverEmailJobs(orderId);
  return changed;
}

export async function sendPaidOrderInvoice(orderId: string) {
  const order = await prisma.order.findUniqueOrThrow({
    where: { id: orderId },

    // Explicit select (rather than a bare include, which still implicitly asks for every
    // scalar field this generated Prisma client knows about — e.g. Order.userId /
    // .paymentReference) so this never throws P2022 if those newer columns aren't on the
    // live table yet. Only the fields actually read below are listed.
    select: {
      orderNumber: true,
      currency: true,
      email: true,
      customerName: true,
      phone: true,
      addressLine1: true,
      addressLine2: true,
      city: true,
      county: true,
      postcode: true,
      country: true,
      deliveryCharge: true,
      subtotal: true,
      discount: true,
      total: true,
      paymentMethod: true,
      createdAt: true,
      deliveryZone: { select: { name: true } },
      items: {
        select: {
          name: true,
          variantLabel: true,
          quantity: true,
          unitPrice: true,
        },
      },
    },
  });

  const settings = await prisma.appSettings
    .findUnique({
      where: { id: "singleton" },
      select: {
        siteName: true,
        contactEmail: true,
        logoUrl: true,
        contactPhone: true,
      },
    })
    .catch(() => null);
  const trackingUrl = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/track-order?order=${order.orderNumber}&email=${encodeURIComponent(order.email)}`;
  const invoiceItems = order.items.map((it) => ({
    name: it.name,
    variantLabel: it.variantLabel,
    quantity: it.quantity,
    unitPrice: Number(it.unitPrice),
  }));
  const invoicePdf = await buildInvoicePdf({
    settings: {
      logoUrl: settings?.logoUrl,
      siteName: settings?.siteName,
      contactEmail: settings?.contactEmail,
      contactPhone: settings?.contactPhone,
    },
    order: {
      orderNumber: order.orderNumber,
      currency: order.currency,
      customerName: order.customerName,
      email: order.email,
      phone: order.phone,
      addressLine1: order.addressLine1,
      addressLine2: order.addressLine2,
      city: order.city,
      county: order.county,
      postcode: order.postcode,
      country: order.country,
      deliveryZoneName: order.deliveryZone?.name,
      deliveryCharge: Number(order.deliveryCharge),
      subtotal: Number(order.subtotal),
      discount: Number(order.discount),
      total: Number(order.total),
      paymentMethod: order.paymentMethod,
      createdAt: order.createdAt,
      confirmedAt: new Date(),
      items: invoiceItems,
    },
    status: "paid",
  });
  await sendPaidInvoiceEmail(
    {
      orderNumber: order.orderNumber,
      currency: order.currency,
      customerName: order.customerName,
      customerEmail: order.email,
      phone: order.phone,
      addressLine1: order.addressLine1,
      addressLine2: order.addressLine2,
      city: order.city,
      county: order.county,
      postcode: order.postcode,
      country: order.country,
      deliveryZoneName: order.deliveryZone?.name,
      deliveryCharge: Number(order.deliveryCharge),
      subtotal: Number(order.subtotal),
      discount: Number(order.discount),
      total: Number(order.total),
      items: invoiceItems,
      trackingUrl,
      paymentMethod: order.paymentMethod,
      createdAt: order.createdAt,
      confirmedAt: new Date(),
      siteName: settings?.siteName,
      contactEmail: settings?.contactEmail,
      contactPhone: settings?.contactPhone,
    },
    [
      {
        filename: `invoice-${order.orderNumber}-paid.pdf`,
        content: invoicePdf,
        contentType: "application/pdf",
      },
    ],
  );
  return true;
}

/** Looks up an order by the gateway reference stored on it (Stripe session id / PayPal order id). */
export async function findOrderByPaymentReference(paymentReference: string) {
  return prisma.order.findFirst({ where: { paymentReference } });
}
