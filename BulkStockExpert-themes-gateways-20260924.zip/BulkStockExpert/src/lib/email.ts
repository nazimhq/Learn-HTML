import nodemailer from "nodemailer";
import { formatMoney, SITE_NAME } from "@/lib/constants";
import {
  renderInvoiceHtml,
  type InvoiceOrder,
  type InvoiceSettings,
} from "@/lib/invoice";
import { prisma } from "@/lib/prisma";

/** Resolves the dynamic site name to stamp on every outgoing email — prefers an explicitly
 *  passed value (callers that already loaded AppSettings, e.g. checkout), falls back to a
 *  fresh lookup, and finally the env/const default. Never throws — email must never be
 *  blocked by a settings-table hiccup. */
async function resolveSiteName(explicit?: string | null): Promise<string> {
  if (explicit) return explicit;
  try {
    const settings = await prisma.appSettings.findUnique({
      where: { id: "singleton" },
      select: { siteName: true },
    });
    return settings?.siteName || SITE_NAME;
  } catch {
    return SITE_NAME;
  }
}

export interface EmailAttachment {
  filename: string;
  content: Buffer;
  contentType?: string;
}

/**
 * Outgoing mail. Defaults to SMTP using the mailbox your domain's cPanel account provides
 * (e.g. orders@bramleigh.sarvice.top via mail.<yourdomain>:465) — see .env.example.
 * If your host's Node app can shell out to `sendmail` instead, swap the transport below for
 * `nodemailer.createTransport({ sendmail: true })`.
 */
function getTransport() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT ?? 465),
    secure: process.env.SMTP_SECURE !== "false",
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
      : undefined,
  });
}

export interface OrderEmailItem {
  name: string;
  variantLabel?: string | null;
  quantity: number;
  unitPrice: number;
}

export interface OrderEmailPayload {
  currency?: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string | null;
  city: string;
  county?: string | null;
  postcode: string;
  country?: string | null;
  deliveryZoneName?: string | null;
  deliveryCharge: number;
  subtotal: number;
  discount: number;
  total: number;
  items: OrderEmailItem[];
  trackingUrl: string;
  /** Extra fields used to render the attached invoice — optional so existing callers keep compiling. */
  paymentMethod?: string | null;
  createdAt?: Date | string;
  confirmedAt?: Date | string | null;
  siteName?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
}

function toInvoiceOrder(p: OrderEmailPayload): InvoiceOrder {
  return {
    orderNumber: p.orderNumber,
    currency: p.currency,
    customerName: p.customerName,
    email: p.customerEmail,
    phone: p.phone,
    addressLine1: p.addressLine1,
    addressLine2: p.addressLine2,
    city: p.city,
    county: p.county,
    postcode: p.postcode,
    country: p.country,
    deliveryZoneName: p.deliveryZoneName,
    deliveryCharge: p.deliveryCharge,
    subtotal: p.subtotal,
    discount: p.discount,
    total: p.total,
    paymentMethod: p.paymentMethod,
    createdAt: p.createdAt ?? new Date(),
    confirmedAt: p.confirmedAt,
    items: p.items.map((it) => ({
      name: it.name,
      variantLabel: it.variantLabel,
      quantity: it.quantity,
      unitPrice: it.unitPrice,
    })),
  };
}

function toInvoiceSettings(p: OrderEmailPayload): InvoiceSettings {
  return {
    siteName:
      p.siteName ?? process.env.NEXT_PUBLIC_SITE_NAME ?? "BulkStockExpert Ltd",
    contactEmail: p.contactEmail,
    contactPhone: p.contactPhone,
  };
}

function itemsRows(items: OrderEmailItem[], currency?: string): string {
  return items
    .map(
      (it) => `
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #eee;">
          ${it.name}${it.variantLabel ? ` <span style="color:#8a8578;">(${it.variantLabel})</span>` : ""}
          <br/><span style="color:#8a8578;font-size:12px;">Qty ${it.quantity}</span>
        </td>
        <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;white-space:nowrap;">
          ${formatMoney(it.unitPrice * it.quantity, currency)}
        </td>
      </tr>`,
    )
    .join("");
}

function addressBlock(p: OrderEmailPayload): string {
  return [
    p.addressLine1,
    p.addressLine2,
    p.city,
    p.county,
    p.postcode,
    p.country ?? "United Kingdom",
  ]
    .filter(Boolean)
    .join(", ");
}

function baseTemplate(
  title: string,
  bodyHtml: string,
  siteName: string,
): string {
  return `<!doctype html>
  <html>
    <body style="margin:0;background:#f4f2ee;font-family:'Work Sans',Arial,sans-serif;color:#241f19;">
      <table role="presentation" width="100%" style="padding:32px 0;">
        <tr><td align="center">
          <table role="presentation" width="100%" style="max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e8e5e0;">
            <tr><td style="background:#241f19;padding:22px 28px;">
              <span style="font-family:Georgia,serif;font-size:22px;color:#f4f2ee;letter-spacing:0.02em;">${siteName}</span>
            </td></tr>
            <tr><td style="padding:28px;">
              <h1 style="font-family:Georgia,serif;font-size:20px;margin:0 0 14px;">${title}</h1>
              ${bodyHtml}
            </td></tr>
            <tr><td style="padding:18px 28px;background:#f4f2ee;color:#8a8578;font-size:11.5px;">
              This is an automated message${"" /* keep footer generic */}.
            </td></tr>
          </table>
        </td></tr>
      </table>
    </body>
  </html>`;
}

export async function sendOrderConfirmationEmail(
  p: OrderEmailPayload,
  attachments?: EmailAttachment[],
) {
  const siteName = await resolveSiteName(p.siteName);
  const invoiceHtml = renderInvoiceHtml({
    settings: { ...toInvoiceSettings(p), siteName },
    order: toInvoiceOrder(p),
    status: "unpaid",
  });
  const html = baseTemplate(
    `Thank you, ${p.customerName.split(" ")[0]} — your order is confirmed`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Order <strong>${p.orderNumber}</strong> has been received and is being prepared.
      Payment is currently <strong>unpaid</strong> — you can track your order anytime here:
      <br/><a href="${p.trackingUrl}" style="color:#946f2f;">${p.trackingUrl}</a>
    </p>
    ${invoiceHtml}
    <p style="font-size:13px;line-height:1.6;color:#4a443b;margin-top:20px;">
      <strong>Delivering to</strong><br/>${addressBlock(p)}<br/>${p.phone}
    </p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to: p.customerEmail,
    subject: `Order confirmed (unpaid) — ${p.orderNumber}`,
    html,
    ...(attachments && attachments.length ? { attachments } : {}),
  });
}

/** Sent when an admin marks an order's payment status as PAID — the same invoice, now showing PAID.
 *  Also used for the "Delivered" status transition, since COD payment is treated as collected on
 *  delivery (see markOrderPaid / updateOrderStatus). */
export async function sendPaidInvoiceEmail(
  p: OrderEmailPayload,
  attachments?: EmailAttachment[],
) {
  const siteName = await resolveSiteName(p.siteName);
  const invoiceHtml = renderInvoiceHtml({
    settings: { ...toInvoiceSettings(p), siteName },
    order: toInvoiceOrder(p),
    status: "paid",
  });
  const html = baseTemplate(
    `Payment received — order ${p.orderNumber}`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Thank you, ${p.customerName.split(" ")[0]} — we've confirmed payment for order <strong>${p.orderNumber}</strong>.
      Here is your updated invoice, with a PDF copy attached.
      <br/><a href="${p.trackingUrl}" style="color:#946f2f;">Track your order →</a>
    </p>
    ${invoiceHtml}
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to: p.customerEmail,
    subject: `Payment received (paid) — ${p.orderNumber}`,
    html,
    ...(attachments && attachments.length ? { attachments } : {}),
  });
}

export async function sendAdminOrderAlertEmail(p: OrderEmailPayload) {
  const adminTo = process.env.ADMIN_NOTIFICATION_EMAIL;
  if (!adminTo) return;
  const siteName = await resolveSiteName(p.siteName);

  const html = baseTemplate(
    `New order — ${p.orderNumber}`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      <strong>${p.customerName}</strong> (${p.customerEmail}, ${p.phone}) just placed an order worth
      <strong>${formatMoney(p.total, p.currency)}</strong>.
    </p>
    <table role="presentation" width="100%" style="margin-top:14px;border-collapse:collapse;font-size:13.5px;">
      ${itemsRows(p.items, p.currency)}
    </table>
    <p style="font-size:13px;line-height:1.6;color:#4a443b;margin-top:18px;">
      <strong>Delivery area</strong><br/>${addressBlock(p)}
      ${p.deliveryZoneName ? `<br/>Zone: ${p.deliveryZoneName}` : ""}
    </p>
    <p style="margin-top:18px;">
      <a href="${p.trackingUrl.replace("/track-order", "/admin/orders")}" style="color:#946f2f;">Open in admin panel →</a>
    </p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to: adminTo,
    subject: `🛒 New order ${p.orderNumber} — ${formatMoney(p.total, p.currency)}`,
    html,
  });
}

/** Sent for both the admin panel and customer-account "forgot password" flows (same User table). */
export async function sendPasswordResetEmail(
  to: string,
  name: string,
  resetUrl: string,
) {
  const siteName = await resolveSiteName();
  const html = baseTemplate(
    "Reset your password",
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Hi ${name.split(" ")[0] || name}, we received a request to reset your password. This link expires in
      1 hour and can only be used once.
    </p>
    <p style="margin:22px 0;">
      <a href="${resetUrl}" style="background:#241f19;color:#f4f2ee;padding:11px 22px;border-radius:999px;text-decoration:none;font-size:13.5px;font-weight:600;">Reset password</a>
    </p>
    <p style="font-size:12.5px;line-height:1.6;color:#8a8578;">
      If you didn't request this, you can safely ignore this email — your password won't change.
      <br/>Link not working? Copy and paste this URL: ${resetUrl}
    </p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to,
    subject: "Reset your password",
    html,
  });
}

/** Sent when an admin updates order status generically (PENDING/PROCESSING, or as a fallback) —
 *  keeps the customer informed. SHIPPED and CANCELLED have their own more specific emails below
 *  (sendShippingUpdateEmail / sendOrderCancellationEmail) that updateOrderStatus prefers instead. */
export async function sendOrderStatusUpdateEmail(
  to: string,
  orderNumber: string,
  statusLabel: string,
  trackingUrl: string,
  note?: string,
  siteNameInput?: string | null,
) {
  const siteName = await resolveSiteName(siteNameInput);
  const html = baseTemplate(
    `Update on order ${orderNumber}`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Your order status is now: <strong>${statusLabel}</strong>.
      ${note ? `<br/>${note}` : ""}
    </p>
    <p style="font-size:13px;"><a href="${trackingUrl}" style="color:#946f2f;">Track your order →</a></p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to,
    subject: `Order ${orderNumber}: ${statusLabel}`,
    html,
  });
}

/** Sent specifically when an order is marked SHIPPED — surfaces the carrier/tracking number
 *  prominently (when set) rather than burying it in a generic status line. */
export async function sendShippingUpdateEmail(params: {
  to: string;
  orderNumber: string;
  trackingUrl: string;
  trackingCarrier?: string | null;
  trackingNumber?: string | null;
  note?: string;
  siteName?: string | null;
}) {
  const siteName = await resolveSiteName(params.siteName);
  const hasTracking = Boolean(params.trackingCarrier && params.trackingNumber);
  const html = baseTemplate(
    `Your order ${params.orderNumber} has shipped`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Good news — order <strong>${params.orderNumber}</strong> is on its way.
      ${params.note ? `<br/>${params.note}` : ""}
    </p>
    ${
      hasTracking
        ? `<div style="margin:16px 0;padding:14px 18px;border-radius:10px;background:#f4f2ee;font-size:13.5px;">
             <strong>Carrier:</strong> ${params.trackingCarrier}<br/>
             <strong>Tracking number:</strong> ${params.trackingNumber}
           </div>`
        : ""
    }
    <p style="font-size:13px;"><a href="${params.trackingUrl}" style="color:#946f2f;">Track your order →</a></p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to: params.to,
    subject: `📦 Order ${params.orderNumber} has shipped`,
    html,
  });
}

/** Sent specifically when an order is CANCELLED — a dedicated notice rather than the generic
 *  status-update email, and mentions that any stock/refund is being handled. */
export async function sendOrderCancellationEmail(params: {
  to: string;
  customerName: string;
  orderNumber: string;
  trackingUrl: string;
  note?: string;
  siteName?: string | null;
}) {
  const siteName = await resolveSiteName(params.siteName);
  const html = baseTemplate(
    `Order ${params.orderNumber} has been cancelled`,
    `
    <p style="font-size:14px;line-height:1.6;color:#4a443b;">
      Hi ${params.customerName.split(" ")[0] || params.customerName}, order <strong>${params.orderNumber}</strong>
      has been cancelled${params.note ? `: ${params.note}` : "."}
    </p>
    <p style="font-size:13.5px;line-height:1.6;color:#4a443b;">
      If you were charged for this order, any payment already taken will be refunded — please allow a few
      business days for it to appear back on your original payment method. If you have any questions, just
      reply to this email.
    </p>
    <p style="font-size:13px;"><a href="${params.trackingUrl}" style="color:#946f2f;">View order details →</a></p>
    `,
    siteName,
  );

  await getTransport().sendMail({
    from: process.env.EMAIL_FROM,
    to: params.to,
    subject: `Order ${params.orderNumber} cancelled`,
    html,
  });
}
