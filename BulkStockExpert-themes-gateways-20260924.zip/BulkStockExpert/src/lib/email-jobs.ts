import { prisma } from "@/lib/prisma";
import { sendPaidOrderInvoice } from "@/lib/order-payment";
import { sendOrderCancellationEmail } from "@/lib/email";
/** At-least-once SMTP delivery. A crashed worker can retry after its lease expires. */
export async function deliverEmailJobs(orderId?: string) {
  const jobs = await prisma.emailJob.findMany({
    where: {
      orderId,
      sentAt: null,
      OR: [{ lockedUntil: null }, { lockedUntil: { lt: new Date() } }],
    },
    take: 20,
    orderBy: { createdAt: "asc" },
  });
  for (const job of jobs) {
    const claim = await prisma.emailJob.updateMany({
      where: {
        id: job.id,
        sentAt: null,
        OR: [{ lockedUntil: null }, { lockedUntil: { lt: new Date() } }],
      },
      data: {
        lockedUntil: new Date(Date.now() + 120000),
        attempts: { increment: 1 },
      },
    });
    if (!claim.count) continue;
    try {
      const order = await prisma.order.findUniqueOrThrow({
        where: { id: job.orderId },
      });
      if (job.kind === "CANCELLED")
        await sendOrderCancellationEmail({
          to: order.email,
          customerName: order.customerName,
          orderNumber: order.orderNumber,
          trackingUrl: `${process.env.NEXT_PUBLIC_SITE_URL}/track-order?order=${order.orderNumber}`,
        });
      else {
        if (order.paymentStatus !== "PAID")
          throw new Error("Awaiting payment confirmation");
        await sendPaidOrderInvoice(order.id);
      }
      await prisma.emailJob.update({
        where: { id: job.id },
        data: { sentAt: new Date(), lockedUntil: null, lastError: null },
      });
    } catch (error) {
      await prisma.emailJob.update({
        where: { id: job.id },
        data: {
          lockedUntil: new Date(
            Date.now() +
              Math.min(3600000, 60000 * 2 ** Math.min(job.attempts, 6)),
          ),
          lastError: error instanceof Error ? error.name : "DeliveryError",
        },
      });
    }
  }
}
