import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

function createPrismaClient(): PrismaClient {
  try {
    return new PrismaClient({
      log:
        process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
    });
  } catch (err) {
    // A broken/un-generated Prisma engine (e.g. a build machine with no network access
    // to fetch engine binaries) would otherwise crash on import for every route that
    // merely references `prisma` — even ones that never run a query at build time. Fail
    // lazily per-call instead, so the build can still complete; a real deployment with a
    // working engine never hits this branch.
    // eslint-disable-next-line no-console
    console.error(
      "Prisma Client failed to initialize — queries will fail until this is fixed:",
      err,
    );
    return new Proxy(
      {},
      {
        get() {
          throw err;
        },
      },
    ) as PrismaClient;
  }
}

export const prisma = globalForPrisma.prisma ?? createPrismaClient();

// Always cache on globalThis, including in production: this app runs as a single
// long-lived custom server.js process (not serverless functions), so caching here is
// what guarantees exactly one PrismaClient/query-engine instance ever exists per running
// process — cheaper and more resilient under this host's tight CPU/process limits than
// letting a fresh module evaluation construct another one.
globalForPrisma.prisma = prisma;
