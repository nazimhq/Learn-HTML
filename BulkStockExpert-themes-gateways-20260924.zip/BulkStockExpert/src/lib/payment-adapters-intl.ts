import type { Order } from "@prisma/client";
import { gatewayConfig } from "@/lib/gateway-settings";

/**
 * International hosted-checkout gateways (added 2026-09).
 *
 * Every provider follows the same safe pattern:
 *  1. create()  — open a hosted payment page for the saved order and return its URL.
 *  2. verify()  — ask the provider's API (server-to-server) for the payment's real status,
 *                 amount and currency. A browser redirect or webhook body is never trusted
 *                 on its own; only the provider's API answer can mark an order paid.
 */

export interface VerifiedPayment {
  orderId: string;
  paid: boolean;
  amount: number;
  currency: string;
  reference: string;
}

interface HostedSession {
  url: string;
  reference: string;
}

const TIMEOUT = 20_000;

async function json(res: Response) {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Provider returned non-JSON (${res.status})`);
  }
}

function requireHttps(url: string, hostSuffixes: string[]) {
  const u = new URL(url);
  if (u.protocol !== "https:" || !hostSuffixes.some((h) => u.hostname === h || u.hostname.endsWith(`.${h}`)))
    throw new Error("Unexpected gateway redirect URL");
  return u.href;
}

const money2 = (n: number | string | { toString(): string }) => Number(n).toFixed(2);
/** Amount in the currency's minor unit (paise, kobo, cents…). All supported currencies use 2 decimals. */
const minor = (n: number | string | { toString(): string }) => Math.round(Number(n) * 100);

// ---------------------------------------------------------------------------
// Mollie — https://docs.mollie.com/reference/create-payment
// ---------------------------------------------------------------------------
async function mollieKey() {
  const c = await gatewayConfig("mollie");
  if (!c.credentials.apiKey) throw new Error("Mollie not configured");
  return c.credentials.apiKey;
}

export const mollie = {
  async create(o: Order, siteUrl: string): Promise<HostedSession> {
    const key = await mollieKey();
    const res = await fetch("https://api.mollie.com/v2/payments", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: { currency: o.currency, value: money2(o.total) },
        description: `Order ${o.orderNumber}`,
        redirectUrl: `${siteUrl}/api/payments/mollie/return?order=${encodeURIComponent(o.orderNumber)}`,
        webhookUrl: `${siteUrl}/api/webhooks/mollie`,
        metadata: { orderId: o.id, orderNumber: o.orderNumber },
      }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || !j.id || !j._links?.checkout?.href) throw new Error("Mollie payment unavailable");
    return { url: requireHttps(j._links.checkout.href, ["mollie.com"]), reference: j.id };
  },
  async verify(paymentId: string): Promise<VerifiedPayment> {
    if (!/^tr_[A-Za-z0-9]+$/.test(paymentId)) throw new Error("Invalid Mollie id");
    const key = await mollieKey();
    const res = await fetch(`https://api.mollie.com/v2/payments/${paymentId}`, {
      headers: { Authorization: `Bearer ${key}` },
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok) throw new Error("Mollie lookup failed");
    return {
      orderId: String(j.metadata?.orderId ?? ""),
      paid: j.status === "paid",
      amount: Number(j.amount?.value),
      currency: String(j.amount?.currency ?? ""),
      reference: j.id,
    };
  },
};

// ---------------------------------------------------------------------------
// Razorpay Payment Links — https://razorpay.com/docs/api/payments/payment-links/
// ---------------------------------------------------------------------------
async function razorpayAuth() {
  const c = await gatewayConfig("razorpay");
  if (!c.credentials.keyId || !c.credentials.keySecret) throw new Error("Razorpay not configured");
  return "Basic " + Buffer.from(`${c.credentials.keyId}:${c.credentials.keySecret}`).toString("base64");
}

export const razorpay = {
  async create(o: Order, siteUrl: string): Promise<HostedSession> {
    const res = await fetch("https://api.razorpay.com/v1/payment_links", {
      method: "POST",
      headers: { Authorization: await razorpayAuth(), "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: minor(o.total),
        currency: o.currency,
        reference_id: o.orderNumber.slice(0, 40),
        description: `Order ${o.orderNumber}`,
        customer: { name: o.customerName, email: o.email, contact: o.phone },
        notify: { sms: false, email: false },
        callback_url: `${siteUrl}/api/payments/razorpay/return`,
        callback_method: "get",
        notes: { orderId: o.id },
      }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || !j.id || !j.short_url) throw new Error("Razorpay link unavailable");
    return { url: requireHttps(j.short_url, ["rzp.io", "razorpay.com"]), reference: j.id };
  },
  async verify(linkId: string): Promise<VerifiedPayment> {
    if (!/^plink_[A-Za-z0-9]+$/.test(linkId)) throw new Error("Invalid Razorpay id");
    const res = await fetch(`https://api.razorpay.com/v1/payment_links/${linkId}`, {
      headers: { Authorization: await razorpayAuth() },
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok) throw new Error("Razorpay lookup failed");
    return {
      orderId: String(j.notes?.orderId ?? ""),
      paid: j.status === "paid" && Number(j.amount_paid) >= Number(j.amount),
      amount: Number(j.amount_paid) / 100,
      currency: String(j.currency ?? ""),
      reference: j.id,
    };
  },
};

// ---------------------------------------------------------------------------
// Paystack — https://paystack.com/docs/api/transaction/
// ---------------------------------------------------------------------------
async function paystackKey() {
  const c = await gatewayConfig("paystack");
  if (!c.credentials.secretKey) throw new Error("Paystack not configured");
  return c.credentials.secretKey;
}

export const paystack = {
  async create(o: Order, siteUrl: string): Promise<HostedSession> {
    const reference = `${o.orderNumber}-${Date.now().toString(36)}`.slice(0, 100);
    const res = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${await paystackKey()}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        email: o.email,
        amount: minor(o.total),
        currency: o.currency,
        reference,
        callback_url: `${siteUrl}/api/payments/paystack/return`,
        metadata: { orderId: o.id, orderNumber: o.orderNumber },
      }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || !j.status || !j.data?.authorization_url) throw new Error("Paystack unavailable");
    return { url: requireHttps(j.data.authorization_url, ["paystack.com", "paystack.co"]), reference: j.data.reference };
  },
  async verify(reference: string): Promise<VerifiedPayment> {
    if (!/^[A-Za-z0-9._=-]{1,100}$/.test(reference)) throw new Error("Invalid Paystack reference");
    const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${await paystackKey()}` },
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || !j.data) throw new Error("Paystack lookup failed");
    return {
      orderId: String(j.data.metadata?.orderId ?? ""),
      paid: j.data.status === "success",
      amount: Number(j.data.amount) / 100,
      currency: String(j.data.currency ?? ""),
      reference: j.data.reference,
    };
  },
  /** HMAC-SHA512 of the raw body with the secret key (x-paystack-signature header). */
  async validSignature(rawBody: string, signature: string | null) {
    if (!signature) return false;
    const { createHmac, timingSafeEqual } = await import("node:crypto");
    const expected = createHmac("sha512", await paystackKey()).update(rawBody).digest("hex");
    return expected.length === signature.length && timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  },
};

// ---------------------------------------------------------------------------
// Flutterwave Standard — https://developer.flutterwave.com/docs/collecting-payments/standard
// ---------------------------------------------------------------------------
async function flutterwaveKey() {
  const c = await gatewayConfig("flutterwave");
  if (!c.credentials.secretKey) throw new Error("Flutterwave not configured");
  return c.credentials.secretKey;
}

export const flutterwave = {
  async create(o: Order, siteUrl: string): Promise<HostedSession> {
    const txRef = `${o.orderNumber}-${Date.now().toString(36)}`;
    const res = await fetch("https://api.flutterwave.com/v3/payments", {
      method: "POST",
      headers: { Authorization: `Bearer ${await flutterwaveKey()}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        tx_ref: txRef,
        amount: money2(o.total),
        currency: o.currency,
        redirect_url: `${siteUrl}/api/payments/flutterwave/return`,
        customer: { email: o.email, name: o.customerName, phonenumber: o.phone },
        customizations: { title: `Order ${o.orderNumber}` },
        meta: { orderId: o.id },
      }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || j.status !== "success" || !j.data?.link) throw new Error("Flutterwave unavailable");
    return { url: requireHttps(j.data.link, ["flutterwave.com"]), reference: txRef };
  },
  async verify(transactionId: string): Promise<VerifiedPayment> {
    if (!/^\d{1,20}$/.test(transactionId)) throw new Error("Invalid Flutterwave id");
    const res = await fetch(`https://api.flutterwave.com/v3/transactions/${transactionId}/verify`, {
      headers: { Authorization: `Bearer ${await flutterwaveKey()}` },
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await json(res);
    if (!res.ok || !j.data) throw new Error("Flutterwave lookup failed");
    return {
      orderId: String(j.data.meta?.orderId ?? ""),
      paid: j.data.status === "successful",
      amount: Number(j.data.amount),
      currency: String(j.data.currency ?? ""),
      // tx_ref is what we stored as the order's payment reference.
      reference: String(j.data.tx_ref ?? ""),
    };
  },
};

// ---------------------------------------------------------------------------
// bKash tokenized checkout — https://developer.bka.sh/docs/tokenized-checkout-overview
// ---------------------------------------------------------------------------
async function bkashConfig() {
  const c = await gatewayConfig("bkash");
  const { username, password, appKey, appSecret } = c.credentials;
  if (!username || !password || !appKey || !appSecret) throw new Error("bKash not configured");
  const base =
    c.mode === "live"
      ? "https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/checkout"
      : "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout";
  return { base, username, password, appKey, appSecret };
}

let bkashToken: { key: string; token: string; expires: number } | null = null;

async function bkashAuth() {
  const cfg = await bkashConfig();
  const cacheKey = `${cfg.base}|${cfg.appKey}`;
  if (bkashToken && bkashToken.key === cacheKey && bkashToken.expires > Date.now()) return { cfg, token: bkashToken.token };
  const res = await fetch(`${cfg.base}/token/grant`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", username: cfg.username, password: cfg.password },
    body: JSON.stringify({ app_key: cfg.appKey, app_secret: cfg.appSecret }),
    signal: AbortSignal.timeout(TIMEOUT),
  });
  const j = await json(res);
  if (!res.ok || !j.id_token) throw new Error("bKash token unavailable");
  // Tokens last an hour; refresh a little early.
  bkashToken = { key: cacheKey, token: j.id_token, expires: Date.now() + 50 * 60_000 };
  return { cfg, token: j.id_token as string };
}

async function bkashPost(path: string, body: unknown) {
  const { cfg, token } = await bkashAuth();
  const res = await fetch(`${cfg.base}/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: token, "X-App-Key": cfg.appKey },
    body: JSON.stringify(body),
    cache: "no-store",
    signal: AbortSignal.timeout(TIMEOUT),
  });
  return json(res);
}

export const bkash = {
  async create(o: Order, siteUrl: string): Promise<HostedSession> {
    if (o.currency !== "BDT") throw new Error("bKash only accepts BDT");
    const j = await bkashPost("create", {
      mode: "0011",
      payerReference: o.phone.replace(/\D/g, "").slice(-11) || o.orderNumber,
      callbackURL: `${siteUrl}/api/payments/bkash/return`,
      amount: money2(o.total),
      currency: "BDT",
      intent: "sale",
      merchantInvoiceNumber: o.orderNumber,
    });
    if (!j.paymentID || !j.bkashURL) throw new Error("bKash payment unavailable");
    return { url: requireHttps(j.bkashURL, ["bkash.com", "bka.sh"]), reference: j.paymentID };
  },
  /** Executes (captures) an authorised payment, or reads its status if already executed. */
  async verify(paymentId: string): Promise<VerifiedPayment & { invoice: string }> {
    if (!/^[A-Za-z0-9]{6,64}$/.test(paymentId)) throw new Error("Invalid bKash id");
    let j = await bkashPost("execute", { paymentID: paymentId });
    if (j.transactionStatus !== "Completed") j = await bkashPost("payment/status", { paymentID: paymentId });
    return {
      orderId: "",
      invoice: String(j.merchantInvoiceNumber ?? ""),
      paid: j.transactionStatus === "Completed",
      amount: Number(j.amount),
      currency: String(j.currency ?? "BDT"),
      reference: String(j.paymentID ?? paymentId),
    };
  },
};
