import { z } from "zod";

/** Site designs. "classic" is the original storefront look; "nexaweb" is the dark purple design. */
export const SKINS = [
  { id: "classic", label: "Classic", description: "The original warm, editorial look." },
  { id: "nexaweb", label: "NEXAWEB", description: "Dark, electric-purple design with glow and grid." },
] as const;

export const ACCENTS = [
  { id: "red", label: "Bright Red", swatch: "#c8382d" },
  { id: "gold", label: "Deep Gold", swatch: "#a87d28" },
  { id: "maroon", label: "Deep / Burgundy Red", swatch: "#7a1e26" },
  { id: "yellow", label: "Warm Yellow", swatch: "#d6a50a" },
  { id: "black", label: "Black / Charcoal", swatch: "#171310" },
  { id: "purple", label: "Electric Purple", swatch: "#8b5cf6" },
] as const;

export type SkinId = (typeof SKINS)[number]["id"];
export type AccentId = (typeof ACCENTS)[number]["id"];
export type ColorMode = "light" | "dark";

export const skinSchema = z.enum(["classic", "nexaweb"]);
export const accentSchema = z.enum(["red", "gold", "maroon", "yellow", "black", "purple"]);
export const modeSchema = z.enum(["light", "dark"]);

export const slotSchema = z.object({
  skin: skinSchema,
  accent: accentSchema,
  mode: modeSchema,
  /** Daily switch time "HH:MM" (24h), used in schedule mode. */
  at: z
    .string()
    .regex(/^([01]\d|2[0-3]):[0-5]\d$/)
    .optional(),
});
export type ThemeSlot = z.infer<typeof slotSchema>;

export interface ThemeLook {
  skin: SkinId;
  accent: AccentId;
  mode: ColorMode;
}

export interface RotationConfig {
  skin: string;
  rotationEnabled: boolean;
  rotationMode: string;
  rotationHours: number;
  timezone: string;
  slots: ThemeSlot[];
}

export interface ResolvedTheme extends ThemeLook {
  /** "base" = admin's fixed choice, "rotation" = picked by the automatic rotation. */
  source: "base" | "rotation";
  /** When the rotation will next switch looks (ISO string), if rotation is active. */
  nextChangeAt: string | null;
  /** Index of the active rotation slot, if any. */
  slotIndex: number | null;
}

export function isValidTimeZone(tz: string) {
  try {
    new Intl.DateTimeFormat("en-GB", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export function parseSlots(raw: unknown): ThemeSlot[] {
  try {
    const value = typeof raw === "string" ? JSON.parse(raw) : raw;
    const parsed = z.array(slotSchema).safeParse(value);
    return parsed.success ? parsed.data : [];
  } catch {
    return [];
  }
}

/** Minutes since local midnight in `timeZone`, plus the local calendar date parts. */
function localClock(now: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? 0);
  return { minutes: get("hour") * 60 + get("minute"), seconds: get("second") };
}

const toMinutes = (at: string) => Number(at.slice(0, 2)) * 60 + Number(at.slice(3, 5));

/**
 * Works out which look is live right now. Pure and deterministic: every server instance and
 * every open browser tab computes the same answer from the clock, so no background job is
 * needed for the rotation to happen.
 */
export function resolveTheme(base: ThemeLook, cfg: RotationConfig | null, now = new Date()): ResolvedTheme {
  const fallback: ResolvedTheme = { ...base, source: "base", nextChangeAt: null, slotIndex: null };
  if (!cfg || !cfg.rotationEnabled || cfg.slots.length === 0) return fallback;

  if (cfg.rotationMode === "schedule") {
    const timed = cfg.slots
      .map((s, i) => ({ s, i }))
      .filter((x) => x.s.at)
      .sort((a, b) => toMinutes(a.s.at!) - toMinutes(b.s.at!));
    if (timed.length === 0) return fallback;
    const tz = isValidTimeZone(cfg.timezone) ? cfg.timezone : "UTC";
    const { minutes, seconds } = localClock(now, tz);
    let current = timed[timed.length - 1]; // before the first time today = yesterday's last slot
    for (const t of timed) if (toMinutes(t.s.at!) <= minutes) current = t;
    const next = timed.find((t) => toMinutes(t.s.at!) > minutes) ?? timed[0];
    let delta = toMinutes(next.s.at!) - minutes;
    if (delta <= 0) delta += 24 * 60;
    const nextChangeAt = new Date(now.getTime() + delta * 60_000 - seconds * 1000);
    return {
      skin: current.s.skin,
      accent: current.s.accent,
      mode: current.s.mode,
      source: "rotation",
      nextChangeAt: nextChangeAt.toISOString(),
      slotIndex: current.i,
    };
  }

  const hours = Math.min(24 * 30, Math.max(1, Math.round(cfg.rotationHours || 6)));
  const period = hours * 3_600_000;
  const block = Math.floor(now.getTime() / period);
  const index = block % cfg.slots.length;
  const slot = cfg.slots[index];
  return {
    skin: slot.skin,
    accent: slot.accent,
    mode: slot.mode,
    source: "rotation",
    nextChangeAt: new Date((block + 1) * period).toISOString(),
    slotIndex: index,
  };
}
