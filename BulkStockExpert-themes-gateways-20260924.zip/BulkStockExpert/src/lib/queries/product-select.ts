import { Prisma } from "@prisma/client";

/**
 * The one shared `select` shape every storefront query uses. `costPrice` is deliberately
 * absent here — it only appears in admin-side queries (src/app/admin/**) — so the hidden
 * purchase cost can never leak onto a public page by accident.
 */
export const publicProductCardSelect = {
  id: true,
  name: true,
  slug: true,
  basePrice: true,
  compareAtPrice: true,
  ratingAvg: true,
  reviewCount: true,
  // tags/category/createdAt are only consumed by the homepage pallet browser (see
  // src/components/home/product-browser.tsx) for the Popular/New Manifest badges,
  // category filtering and "newest" heuristics — other callers of this shared select
  // simply ignore the extra fields.
  tags: true,
  createdAt: true,
  category: { select: { name: true, slug: true } },
  brand: { select: { name: true, slug: true } },
  images: {
    select: { url: true, altText: true },
    orderBy: { position: "asc" },
    take: 1,
  },
  variants: { select: { stock: true } },
} satisfies Prisma.ProductSelect;

export type PublicProductCard = Prisma.ProductGetPayload<{
  select: typeof publicProductCardSelect;
}>;

export const publicProductDetailSelect = {
  id: true,
  name: true,
  slug: true,
  description: true,
  tags: true,
  videoUrl: true,
  ratingAvg: true,
  reviewCount: true,
  // categoryId (not just the nested category.name/slug below) is needed by the "You Might
  // Also Like" related-products query on the PDP, which matches on category first.
  categoryId: true,
  category: { select: { name: true, slug: true } },
  brand: { select: { name: true, slug: true } },
  images: {
    select: { id: true, url: true, altText: true },
    orderBy: { position: "asc" },
  },
  variants: {
    select: {
      id: true,
      sku: true,
      label: true,
      price: true,
      compareAtPrice: true,
      stock: true,
      lowStockAt: true,
      imageUrl: true,
    },
  },
  reviews: {
    where: { status: "APPROVED" },
    select: {
      id: true,
      customerName: true,
      rating: true,
      comment: true,
      createdAt: true,
    },
    orderBy: { createdAt: "desc" },
  },
} satisfies Prisma.ProductSelect;

export type PublicProductDetail = Prisma.ProductGetPayload<{
  select: typeof publicProductDetailSelect;
}>;
