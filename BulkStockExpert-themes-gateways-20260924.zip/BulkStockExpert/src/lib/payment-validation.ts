export function matchesPayment(
  expected: {
    total: number | string | { toString(): string };
    currency: string;
  },
  actual: { amount: unknown; currency: unknown },
) {
  const amount = Number(actual.amount);
  return (
    Number.isFinite(amount) &&
    Math.round(Number(expected.total) * 100) === Math.round(amount * 100) &&
    expected.currency === actual.currency
  );
}
