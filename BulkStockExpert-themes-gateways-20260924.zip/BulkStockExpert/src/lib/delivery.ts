import { prisma } from "@/lib/prisma";
import { outwardPostcode } from "@/lib/constants";

/**
 * Best-effort auto-match of a UK postcode to an admin-configured DeliveryZone by its
 * outward-code prefix list (e.g. Highlands & Islands: ["IV","KW","ZE","HS","PA20".."PA49"]).
 * Falls back to the lowest-`position` active zone with no prefixes set (the "everywhere else"
 * default zone) when nothing matches.
 */
export async function matchDeliveryZone(postcode: string, countryCode = "GB") {
  const zones = await prisma.deliveryZone.findMany({
    where: { isActive: true, countryCode },
    orderBy: { position: "asc" },
  });
  if (zones.length === 0) return null;

  const outward = outwardPostcode(postcode);
  const specific = zones.find(
    (z) =>
      Array.isArray(z.postcodePrefixes) &&
      z.postcodePrefixes.some(
        (p) => typeof p === "string" && outward.startsWith(p),
      ),
  );
  if (specific) return specific;

  return (
    zones.find(
      (z) =>
        Array.isArray(z.postcodePrefixes) && z.postcodePrefixes.length === 0,
    ) ?? zones[0]
  );
}
