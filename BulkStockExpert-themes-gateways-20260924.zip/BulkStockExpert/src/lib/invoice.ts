import { formatMoney } from "@/lib/constants";
export { buildInvoicePdf } from "@/lib/invoice-pdf";
export interface InvoiceItem {
  name: string;
  variantLabel?: string | null;
  quantity: number;
  unitPrice: number;
}

export interface InvoiceOrder {
  orderNumber: string;
  currency?: string;
  customerName: string;
  email: string;
  phone?: string | null;
  addressLine1: string;
  addressLine2?: string | null;
  city: string;
  county?: string | null;
  postcode: string;
  country?: string | null;
  deliveryZoneName?: string | null;
  deliveryCharge: number;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod?: string | null;
  createdAt: Date | string;
  confirmedAt?: Date | string | null;
  items: InvoiceItem[];
}

export interface InvoiceSettings {
  logoUrl?: string | null;
  siteName?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
}

export type InvoiceStatus = "unpaid" | "paid";

export function renderInvoiceHtml({
  settings,
  order,
  status,
}: {
  settings: InvoiceSettings;
  order: InvoiceOrder;
  status: InvoiceStatus;
}): string {
  const isPaid = status === "paid";
  const badgeColor = isPaid ? "#2e7d32" : "#b03a2e";
  const siteName = settings.siteName || "BulkStockExpert Ltd";
  const esc = (s: unknown) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c] as string,
    );

  const rows = order.items
    .map(
      (it) => `
      <tr style="border-bottom:1px solid #eee;">
        <td style="padding:8px 0;">${esc(it.name)}${it.variantLabel ? ` <span style="color:#8a8578;">(${esc(it.variantLabel)})</span>` : ""}<br/><span style="color:#8a8578;font-size:12px;">Qty ${it.quantity} × ${esc(formatMoney(it.unitPrice, order.currency))}</span></td>
        <td style="padding:8px 0;text-align:right;white-space:nowrap;">${esc(formatMoney(it.unitPrice * it.quantity, order.currency))}</td>
      </tr>`,
    )
    .join("");

  return `
    <div style="border:1px solid #e8e5e0;border-radius:10px;overflow:hidden;margin-bottom:8px;">
      <div style="background:#f4f2ee;padding:20px 24px;display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <div style="font-family:Georgia,serif;font-size:19px;font-weight:bold;color:#241f19;">${esc(siteName)}</div>
          <div style="font-size:12px;color:#8a8578;margin-top:2px;">Invoice #${esc(order.orderNumber)}</div>
        </div>
        <div style="background:${badgeColor};color:#fff;font-weight:bold;font-size:12.5px;letter-spacing:0.5px;padding:8px 16px;border-radius:5px;white-space:nowrap;">
          ${isPaid ? "PAID" : "UNPAID"}
        </div>
      </div>
      <div style="padding:20px 24px;">
        <table role="presentation" width="100%" cellpadding="8" cellspacing="0" style="font-size:13.5px;border-collapse:collapse;">
          <tr style="border-bottom:1px solid #241f19;">
            <td style="font-weight:700;padding-left:0;">Item</td>
            <td style="font-weight:700;text-align:right;padding-right:0;">Amount</td>
          </tr>
          ${rows}
          <tr><td style="padding:8px 0 0;color:#8a8578;">Delivery${order.deliveryZoneName ? ` (${esc(order.deliveryZoneName)})` : ""}</td><td style="padding:8px 0 0;text-align:right;">${esc(formatMoney(order.deliveryCharge, order.currency))}</td></tr>
          ${order.discount > 0 ? `<tr><td style="padding:4px 0;color:#8a8578;">Discount</td><td style="padding:4px 0;text-align:right;">-${esc(formatMoney(order.discount, order.currency))}</td></tr>` : ""}
          <tr><td style="padding:10px 0 0;font-weight:700;font-size:15px;">Total</td><td style="padding:10px 0 0;text-align:right;font-weight:700;font-size:15px;">${esc(formatMoney(order.total, order.currency))}</td></tr>
        </table>
        <div style="margin-top:16px;font-size:12px;color:#5c5749;">
          ${isPaid ? "Payment received — thank you!" : `Payment method: ${esc(order.paymentMethod || "-")}. We'll email you again the moment this is marked Paid.`}
        </div>
      </div>
    </div>
    <p style="font-size:12px;color:#8a8578;">A PDF copy of this invoice is attached to this email for your records.</p>
  `;
}

function fmtDate(d?: Date | string | null) {
  return new Date(d ?? Date.now()).toLocaleDateString("en-GB");
}
