import { REGIONS, Region } from "@/lib/gateway-catalog";
// Catalog and delivery prices are denominated in GBP. Never merely relabel money.
export function regionPricing(region: Region) {
  const currency = REGIONS[region];
  const rate =
    currency === "GBP" ? 1 : Number(process.env[`FX_GBP_${currency}`]);
  if (!Number.isFinite(rate) || rate <= 0)
    throw new Error(`Pricing for ${currency} is not configured`);
  return { currency, rate };
}
export function convertMoney(value: number, rate: number) {
  return Math.round((value * rate + Number.EPSILON) * 100) / 100;
}

/**
 * Same as regionPricing(), but prefers the admin-editable rate (Admin → Currencies) and falls
 * back to the FX_GBP_<CODE> environment variable. Used by checkout and the payment-methods API.
 */
export async function getRegionPricing(region: Region) {
  const currency = REGIONS[region];
  if (currency === "GBP") return { currency, rate: 1 };
  try {
    const { prisma } = await import("@/lib/prisma");
    const row = await prisma.currencyRate.findUnique({ where: { code: currency } });
    const rate = row ? Number(row.rate) : NaN;
    if (Number.isFinite(rate) && rate > 0) return { currency, rate };
  } catch {
    // Table not migrated yet — use the environment variable below.
  }
  return regionPricing(region);
}
