import { hasOrderAccess } from "@/lib/order-access";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

/** Used by both the confirmation page and the tracking page — customer-safe (no costPrice). */
export async function getOrderForTracking(orderNumber: string, email?: string) {
  if (!email && !(await hasOrderAccess(orderNumber.trim().toUpperCase()))) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return null;
    email = session.user.email;
  }
  return prisma.order.findFirst({
    where: {
      orderNumber: orderNumber.trim().toUpperCase(),
      ...(email ? { email: { equals: email.trim().toLowerCase() } } : {}),
    },
    select: {
      orderNumber: true,
      currency: true,
      status: true,
      paymentStatus: true,
      customerName: true,
      email: true,
      phone: true,
      addressLine1: true,
      addressLine2: true,
      city: true,
      county: true,
      postcode: true,
      deliveryZone: { select: { name: true, estimatedDays: true } },
      deliveryCharge: true,
      subtotal: true,
      discount: true,
      total: true,
      trackingNumber: true,
      trackingCarrier: true,
      createdAt: true,
      items: {
        select: {
          name: true,
          variantLabel: true,
          quantity: true,
          unitPrice: true,
        },
      },
      activity: {
        select: { message: true, createdAt: true },
        orderBy: { createdAt: "asc" },
      },
    },
  });
}
