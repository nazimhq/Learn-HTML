import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "node:crypto";
function signature(order: string) {
  const key = process.env.NEXTAUTH_SECRET;
  if (!key) throw new Error("NEXTAUTH_SECRET is required");
  return createHmac("sha256", key).update(order).digest("hex");
}
export async function grantOrderAccess(order: string) {
  (await cookies()).set(`order-${order}`, signature(order), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}
export async function hasOrderAccess(order: string) {
  const value = (await cookies()).get(`order-${order}`)?.value;
  if (!value) return false;
  const expected = signature(order);
  return (
    value.length === expected.length &&
    timingSafeEqual(Buffer.from(value), Buffer.from(expected))
  );
}
