import { Order } from "@prisma/client";
import { createPaypalOrder, createStripeCheckoutSession } from "@/lib/payments";
import { gatewayConfig } from "@/lib/gateway-settings";
export interface PaymentAdapter {
  create(
    order: Order,
    siteUrl: string,
  ): Promise<{ url: string; reference: string }>;
}
export const adapters: Record<string, PaymentAdapter> = {
  stripe: {
    async create(o, url) {
      const r = await createStripeCheckoutSession({
        orderId: o.id,
        orderNumber: o.orderNumber,
        amountGbp: Number(o.total),
        customerEmail: o.email,
        siteUrl: url,
        currency: o.currency,
        gateway: o.paymentGateway ?? "stripe",
      });
      if (!r) throw new Error("Stripe session unavailable");
      return { url: r.url, reference: r.sessionId };
    },
  },
  paypal: {
    async create(o, url) {
      const r = await createPaypalOrder({
        orderId: o.id,
        orderNumber: o.orderNumber,
        amountGbp: Number(o.total),
        siteUrl: url,
        currency: o.currency,
      });
      if (!r) throw new Error("PayPal session unavailable");
      return { url: r.approveUrl, reference: r.paypalOrderId };
    },
  },
  sslcommerz: {
    async create(o, url) {
      const c = await gatewayConfig("sslcommerz");
      const base =
        c.mode === "live"
          ? "https://securepay.sslcommerz.com"
          : "https://sandbox.sslcommerz.com";
      const callback = `${url}/api/webhooks/sslcommerz`;
      const body = new URLSearchParams({
        store_id: c.credentials.storeId,
        store_passwd: c.credentials.storePassword,
        total_amount: Number(o.total).toFixed(2),
        currency: o.currency,
        tran_id: o.id,
        success_url: callback,
        fail_url: `${url}/checkout?payment=failed`,
        cancel_url: `${url}/checkout?payment=cancelled`,
        ipn_url: callback,
        shipping_method: "YES",
        num_of_item: "1",
        product_name: `Order ${o.orderNumber}`,
        product_category: "General",
        product_profile: "general",
        cus_name: o.customerName,
        cus_email: o.email,
        cus_add1: o.addressLine1,
        cus_city: o.city,
        cus_postcode: o.postcode,
        cus_country: "Bangladesh",
        cus_phone: o.phone,
        ship_name: o.customerName,
        ship_add1: o.addressLine1,
        ship_city: o.city,
        ship_postcode: o.postcode,
        ship_country: "Bangladesh",
      });
      const r = await fetch(`${base}/gwprocess/v4/api.php`, {
        method: "POST",
        body,
        signal: AbortSignal.timeout(20000),
      });
      const j = await r.json();
      if (!r.ok || j.status !== "SUCCESS" || !j.GatewayPageURL)
        throw new Error("SSLCommerz session unavailable");
      const redirect = new URL(j.GatewayPageURL);
      if (
        redirect.protocol !== "https:" ||
        !redirect.hostname.endsWith(".sslcommerz.com")
      )
        throw new Error("Invalid gateway URL");
      return { url: redirect.href, reference: o.id };
    },
  },
};
adapters.klarna = adapters.stripe;
adapters.clearpay = adapters.stripe;

// International gateways (added 2026-09) — see src/lib/payment-adapters-intl.ts.
import { bkash, flutterwave, mollie, paystack, razorpay } from "@/lib/payment-adapters-intl";
adapters.mollie = mollie;
adapters.razorpay = razorpay;
adapters.paystack = paystack;
adapters.flutterwave = flutterwave;
adapters.bkash = bkash;
