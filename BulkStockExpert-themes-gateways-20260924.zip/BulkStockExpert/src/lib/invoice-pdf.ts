import PDFDocument from "pdfkit";
import path from "node:path";
import { existsSync } from "node:fs";
import type {
  InvoiceSettings,
  InvoiceOrder,
  InvoiceStatus,
} from "@/lib/invoice";

/** Paginated invoices with embedded Latin/Bengali fonts; no remote fetch during rendering. */
export async function buildInvoicePdf({
  settings,
  order,
  status,
}: {
  settings: InvoiceSettings;
  order: InvoiceOrder;
  status: InvoiceStatus;
}): Promise<Buffer> {
  const doc = new PDFDocument({
    size: "A4",
    margin: 48,
    bufferPages: true,
    info: {
      Title: `Invoice ${order.orderNumber}`,
      Author: settings.siteName ?? "Store",
    },
  });
  const chunks: Buffer[] = [];
  const finished = new Promise<Buffer>((resolve, reject) => {
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  doc.registerFont(
    "Latin",
    path.join(process.cwd(), "public/fonts/invoice-latin.woff"),
  );
  doc.registerFont(
    "Bengali",
    path.join(process.cwd(), "public/fonts/invoice-bengali.woff"),
  );
  const money = (n: number) => `${order.currency ?? "GBP"} ${n.toFixed(2)}`;
  const font = (s: string) =>
    doc.font(/[\u0980-\u09ff]/.test(s) ? "Bengali" : "Latin");
  const text = (s: string, x: number, y: number, width = 499, size = 10) => {
    doc.x = x;
    doc.y = y;
    const runs = s.split(/([\u0980-\u09ff]+)/).filter(Boolean);
    runs.forEach((run, i) => {
      font(run)
        .fontSize(size)
        .fillColor("#243044")
        .text(run, { width, continued: i < runs.length - 1 });
    });
    return doc.y;
  };
  let y = 48;
  if (settings.logoUrl?.startsWith("/uploads/")) {
    const uploads = path.resolve("public/uploads");
    const logo = path.resolve("public", `.${settings.logoUrl}`);
    if (
      logo.startsWith(uploads + path.sep) &&
      existsSync(logo) &&
      /\.(png|jpe?g)$/i.test(logo)
    ) {
      try {
        doc.image(logo, 48, 40, { fit: [80, 45] });
        y = 100;
      } catch {
        /* Fall back to the site-name wordmark. */
      }
    }
  }
  y = text(settings.siteName ?? "Store", 48, y, 499, 21) + 8;
  y = text(`${status.toUpperCase()} INVOICE`, 48, y, 499, 12) + 8;
  y =
    text(
      `Order ${order.orderNumber}  |  ${new Date(order.createdAt).toLocaleDateString("en-GB")}`,
      48,
      y,
    ) + 14;
  for (const line of [
    order.customerName,
    order.addressLine1,
    order.addressLine2,
    order.city,
    order.county,
    order.postcode,
    order.country,
    order.email,
  ].filter(Boolean))
    y = text(line!, 48, y, 320) + 2;
  y += 18;
  const heading = () => {
    doc.rect(48, y, 499, 25).fill("#eef1f6");
    text("Item", 56, y + 6, 280, 9);
    text("Qty", 340, y + 6, 38, 9);
    text("Unit", 381, y + 6, 72, 9);
    text("Amount", 465, y + 6, 78, 9);
    y += 34;
  };
  const page = () => {
    doc.addPage();
    y = 48;
    text(`Invoice ${order.orderNumber} - continued`, 48, y, 499, 10);
    y += 30;
    heading();
  };
  heading();
  for (const item of order.items) {
    const name = [item.name, item.variantLabel].filter(Boolean).join(" / ");
    font(name).fontSize(10);
    const h = Math.max(26, doc.heightOfString(name, { width: 274 }) + 12);
    if (y + h > 738) page();
    text(name, 56, y, 274);
    text(String(item.quantity), 340, y, 35);
    text(money(item.unitPrice), 381, y, 79, 8);
    text(money(item.unitPrice * item.quantity), 465, y, 80, 8);
    y += h;
    doc
      .moveTo(48, y - 5)
      .lineTo(547, y - 5)
      .strokeColor("#e1e5ec")
      .stroke();
  }
  if (y + 150 > 738) page();
  y += 12;
  for (const [label, value] of [
    ["Subtotal", order.subtotal],
    ["Delivery", order.deliveryCharge],
    ["Discount", -order.discount],
    ["Total", order.total],
  ] as const) {
    text(label, 330, y, 100, label === "Total" ? 12 : 10);
    text(money(value), 438, y, 109, label === "Total" ? 12 : 10);
    y += 24;
  }
  y = text(
    status === "paid"
      ? "Payment received. Thank you for your order."
      : "Payment pending. This invoice is not proof of payment.",
    48,
    y + 10,
    499,
    9,
  );
  if (settings.contactEmail) text(settings.contactEmail, 48, y + 6, 499, 9);
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i++) {
    doc.switchToPage(i);
    text(
      `${settings.siteName ?? "Store"}  |  ${i + 1} / ${range.count}`,
      48,
      777,
      499,
      8,
    );
  }
  doc.end();
  return finished;
}
