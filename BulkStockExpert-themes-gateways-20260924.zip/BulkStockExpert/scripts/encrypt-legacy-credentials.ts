import { prisma } from "../src/lib/prisma";
import { encryptSecret } from "../src/lib/payment-crypto";
async function main() {
  const row = await prisma.paymentSettings.findUnique({
    where: { id: "singleton" },
  });
  if (!row) return;
  const patch: Record<string, string> = {};
  for (const key of [
    "stripePublishableKey",
    "stripeSecretKey",
    "stripeWebhookSecret",
    "paypalClientId",
    "paypalClientSecret",
  ] as const) {
    if (row[key] && !row[key]!.startsWith("v1:"))
      patch[key] = encryptSecret(row[key]!);
  }
  await prisma.paymentSettings.update({
    where: { id: "singleton" },
    data: patch,
  });
  console.log("Legacy credentials encrypted. No values printed.");
}
main().finally(() => prisma.$disconnect());
