-- Round 4 CMS additions: site logo + social links (on AppSettings) and admin-editable
-- policy/info pages (new ContentPage table), for the "make the site dynamically editable"
-- request. Run this whole file in phpMyAdmin's SQL tab (sarvicet_bramleigh database) once,
-- then redeploy the new build. Safe to re-run — uses IF NOT EXISTS / INSERT IGNORE guards
-- are not available for ADD COLUMN in MySQL, so if a column already exists this will error
-- on that one line only; just delete the lines that already succeeded and re-run the rest.

ALTER TABLE `AppSettings` ADD COLUMN `logoUrl` VARCHAR(191) NULL AFTER `colorMode`;
ALTER TABLE `AppSettings` ADD COLUMN `facebookUrl` VARCHAR(191) NULL AFTER `logoUrl`;
ALTER TABLE `AppSettings` ADD COLUMN `instagramUrl` VARCHAR(191) NULL AFTER `facebookUrl`;
ALTER TABLE `AppSettings` ADD COLUMN `tiktokUrl` VARCHAR(191) NULL AFTER `instagramUrl`;

CREATE TABLE `ContentPage` (
  `id` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `body` TEXT NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `ContentPage_slug_key` (`slug`)
) DEFAULT CHARACTER SET utf8mb4;

INSERT INTO `ContentPage` (`id`, `slug`, `title`, `body`, `updatedAt`) VALUES
('cp-about',   'about',   'About Us',
 'BulkStockExpert Ltd sources genuine customer-return pallets and manifested job lots from major UK retailers, then sells them on directly to traders, resellers and bargain-hunters nationwide.\n\nEvery lot is manifested where possible so you know roughly what you are getting, and every order ships fully tracked from our UK warehouse.',
 NOW(3)),
('cp-terms',   'terms',   'Terms & Conditions',
 'By placing an order with BulkStockExpert Ltd you agree to these terms.\n\nAll pallets are sold as genuine customer returns and general merchandise stock — items may be untested, missing accessories, or show signs of previous use unless stated otherwise. Please read each listing carefully before ordering.\n\nPayment is required in full at checkout (or on delivery for Cash on Delivery orders). Ownership of goods transfers once payment has been received in full.',
 NOW(3)),
('cp-privacy', 'privacy', 'Privacy Policy',
 'We collect the personal information you give us at checkout (name, address, email, phone) solely to process and deliver your order, and to contact you about it.\n\nWe do not sell your personal data to third parties. Payment details are handled directly by our payment providers (Stripe/PayPal) and are never stored on our own servers.\n\nContact us at the email address in our footer if you would like your data removed.',
 NOW(3)),
('cp-returns', 'returns', 'Returns & Refunds',
 'Because our stock is genuine customer-return and manifested pallets sold as-is, individual items within a pallet are not eligible for return once the pallet has been opened, except where the pallet materially does not match its listing.\n\nIf your order arrives damaged in transit, or is significantly different from its manifest, contact us within 48 hours of delivery with photos and we will work with you on a resolution.',
 NOW(3));
