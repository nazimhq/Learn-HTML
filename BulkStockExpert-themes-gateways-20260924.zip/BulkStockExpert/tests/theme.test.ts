import assert from "node:assert/strict";
import { resolveTheme, parseSlots, type RotationConfig } from "../src/lib/site-theme";

const base = { skin: "classic", accent: "gold", mode: "light" } as const;
const slots = [
  { skin: "classic", accent: "red", mode: "light", at: "08:00" },
  { skin: "nexaweb", accent: "purple", mode: "dark", at: "18:00" },
  { skin: "classic", accent: "black", mode: "dark", at: "22:30" },
] as const;
const cfg = (patch: Partial<RotationConfig>): RotationConfig => ({
  skin: "classic",
  rotationEnabled: true,
  rotationMode: "interval",
  rotationHours: 6,
  timezone: "UTC",
  slots: slots.map((s) => ({ ...s })),
  ...patch,
});

// Off → the admin's fixed look.
assert.deepEqual(resolveTheme(base, cfg({ rotationEnabled: false })).skin, "classic");
assert.equal(resolveTheme(base, cfg({ rotationEnabled: false })).source, "base");
assert.equal(resolveTheme(base, null).accent, "gold");
assert.equal(resolveTheme(base, cfg({ slots: [] })).source, "base");

// Interval: every 6 hours, cycling in order, same answer everywhere for the same instant.
const t0 = new Date(Date.UTC(2026, 0, 1, 0, 0, 0)); // block index divisible by 3? compute below
const period = 6 * 3_600_000;
const idx = (d: Date) => Math.floor(d.getTime() / period) % 3;
const a = resolveTheme(base, cfg({}), t0);
assert.equal(a.slotIndex, idx(t0));
const b = resolveTheme(base, cfg({}), new Date(t0.getTime() + period));
assert.equal(b.slotIndex, (idx(t0) + 1) % 3);
assert.equal(new Date(a.nextChangeAt!).getTime() - t0.getTime() <= period, true);
// 5-hour interval changes at 5h boundaries.
const five = resolveTheme(base, cfg({ rotationHours: 5 }), t0);
assert.equal(new Date(five.nextChangeAt!).getTime() % (5 * 3_600_000), 0);

// Schedule: pick the latest slot at or before the local time; before the first slot = yesterday's last.
const at = (h: number, m = 0) => new Date(Date.UTC(2026, 5, 10, h, m));
const sched = cfg({ rotationMode: "schedule" });
assert.equal(resolveTheme(base, sched, at(9)).accent, "red");
assert.equal(resolveTheme(base, sched, at(18)).skin, "nexaweb");
assert.equal(resolveTheme(base, sched, at(23)).accent, "black");
assert.equal(resolveTheme(base, sched, at(3)).accent, "black");
assert.equal(resolveTheme(base, sched, at(9)).nextChangeAt, at(18).toISOString());
assert.equal(resolveTheme(base, sched, at(23)).nextChangeAt, new Date(Date.UTC(2026, 5, 11, 8)).toISOString());
// Time zones: 18:00 in Dhaka (UTC+6) is 12:00 UTC.
const dhaka = cfg({ rotationMode: "schedule", timezone: "Asia/Dhaka" });
assert.equal(resolveTheme(base, dhaka, at(12)).skin, "nexaweb");
assert.equal(resolveTheme(base, dhaka, at(11, 59)).accent, "red");
// Unknown zone falls back to UTC rather than crashing.
assert.equal(resolveTheme(base, cfg({ rotationMode: "schedule", timezone: "Nowhere/Land" }), at(18)).skin, "nexaweb");

// Stored JSON is validated; bad data is ignored.
assert.equal(parseSlots('[{"skin":"nexaweb","accent":"purple","mode":"dark"}]').length, 1);
assert.equal(parseSlots('[{"skin":"hacker","accent":"purple","mode":"dark"}]').length, 0);
assert.equal(parseSlots("not json").length, 0);

console.log("PASS: theme rotation (off, interval cycling, 5h boundaries, daily schedule, time zones, bad data).");
