import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { writeFile, mkdir } from "node:fs/promises";
import { encryptSecret, decryptSecret } from "../src/lib/payment-crypto";
import { regionPricing, convertMoney } from "../src/lib/region-pricing";
import { GATEWAYS } from "../src/lib/gateway-catalog";
import { buildInvoicePdf } from "../src/lib/invoice-pdf";
import { matchesPayment } from "../src/lib/payment-validation";
async function main() {
  process.env.PAYMENT_ENCRYPTION_KEY = randomBytes(32).toString("hex");
  const secret = "a live credential with unicode বাংলা";
  const a = encryptSecret(secret),
    b = encryptSecret(secret);
  assert.notEqual(a, b);
  assert.equal(decryptSecret(a), secret);
  assert(!a.includes(secret));
  const parts = a.split(":");
  const cipher = Buffer.from(parts[3], "base64");
  cipher[0] ^= 1;
  parts[3] = cipher.toString("base64");
  assert.throws(() => decryptSecret(parts.join(":")));
  const key = process.env.PAYMENT_ENCRYPTION_KEY;
  process.env.PAYMENT_ENCRYPTION_KEY = randomBytes(32).toString("hex");
  assert.throws(() => decryptSecret(a));
  process.env.PAYMENT_ENCRYPTION_KEY = key;
  assert.equal(regionPricing("GB").currency, "GBP");
  delete process.env.FX_GBP_BDT;
  assert.throws(() => regionPricing("BD"));
  process.env.FX_GBP_BDT = "150";
  assert.equal(regionPricing("BD").rate, 150);
  assert.equal(convertMoney(19.99, 150), 2998.5);
  assert(GATEWAYS.length >= 50);
  assert.equal(new Set(GATEWAYS.map((g) => g.id)).size, GATEWAYS.length);
  assert(GATEWAYS.filter((g) => !g.ready).every((g) => g.regions.length === 0));
  assert(
    matchesPayment(
      { total: 100, currency: "GBP" },
      { amount: "100.00", currency: "GBP" },
    ),
  );
  assert(
    !matchesPayment(
      { total: 100, currency: "GBP" },
      { amount: "100.00", currency: "USD" },
    ),
  );
  assert(
    !matchesPayment(
      { total: 100, currency: "GBP" },
      { amount: "99.99", currency: "GBP" },
    ),
  );
  assert(
    !matchesPayment(
      { total: 100, currency: "GBP" },
      { amount: "NaN", currency: "GBP" },
    ),
  );
  const pdf = await buildInvoicePdf({
    settings: {
      siteName: "BulkStockExpert",
      contactEmail: "orders@example.test",
    },
    status: "paid",
    order: {
      currency: "BDT",
      orderNumber: "ORD-PDF-QA",
      customerName: "নাজিম",
      email: "customer@example.test",
      addressLine1: "ঢাকা",
      city: "Dhaka",
      postcode: "1205",
      country: "BD",
      subtotal: 299850,
      discount: 0,
      deliveryCharge: 150,
      total: 300000,
      createdAt: new Date("2026-09-19"),
      items: Array.from({ length: 60 }, (_, i) => ({
        name: `Product ${i + 1} - multi-line inventory test with a longer product name`,
        quantity: 1,
        unitPrice: 4997.5,
      })),
    },
  });
  assert.equal(pdf.subarray(0, 4).toString(), "%PDF");
  await mkdir("../qa", { recursive: true });
  await writeFile("../qa/invoice.pdf", pdf);
  console.log(
    "PASS: encryption roundtrip, randomized IV, tamper rejection, wrong key, region pricing, rounding, registry capability gating, paginated Bengali invoice generation.",
  );
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
