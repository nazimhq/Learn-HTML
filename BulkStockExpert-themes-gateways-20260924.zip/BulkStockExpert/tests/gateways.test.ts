import assert from "node:assert/strict";
import path from "node:path";

// Stub the credentials store so adapters can run without a database.
const settingsPath = path.resolve("src/lib/gateway-settings.ts");
const creds: Record<string, Record<string, string>> = {
  mollie: { apiKey: "test_abc" },
  razorpay: { keyId: "rzp_test_1", keySecret: "s3cret" },
  paystack: { secretKey: "sk_test_x" },
  flutterwave: { secretKey: "FLWSECK_TEST-x" },
  bkash: { username: "u", password: "p", appKey: "ak", appSecret: "as" },
};
(require.cache as Record<string, unknown>)[settingsPath] = {
  id: settingsPath,
  filename: settingsPath,
  loaded: true,
  exports: { gatewayConfig: async (id: string) => ({ enabled: true, mode: "sandbox", credentials: creds[id] ?? {} }) },
};

type Call = { url: string; init?: RequestInit };
const calls: Call[] = [];
let responder: (url: string, init?: RequestInit) => unknown = () => ({});
globalThis.fetch = (async (input: string | URL, init?: RequestInit) => {
  const url = String(input);
  calls.push({ url, init });
  const body = responder(url, init);
  return new Response(JSON.stringify(body), { status: 200, headers: { "content-type": "application/json" } });
}) as typeof fetch;

// eslint-disable-next-line @typescript-eslint/no-require-imports
const { mollie, razorpay, paystack, flutterwave, bkash } = require("../src/lib/payment-adapters-intl");

const order = {
  id: "ord_1",
  orderNumber: "ORD-ABC123",
  total: "1234.50",
  currency: "EUR",
  email: "buyer@example.com",
  customerName: "Test Buyer",
  phone: "+8801712345678",
} as never;
const bodyOf = (i: number) => JSON.parse(String(calls[i].init?.body));

async function main() {
  // Mollie: amount as string, redirect + webhook URLs, verify reads status from API.
  responder = () => ({ id: "tr_123", _links: { checkout: { href: "https://www.mollie.com/checkout/x" } } });
  const m = await mollie.create(order, "https://shop.test");
  assert.equal(m.reference, "tr_123");
  assert.deepEqual(bodyOf(0).amount, { currency: "EUR", value: "1234.50" });
  assert.equal(bodyOf(0).webhookUrl, "https://shop.test/api/webhooks/mollie");
  responder = () => ({ id: "tr_123", status: "paid", amount: { value: "1234.50", currency: "EUR" }, metadata: { orderId: "ord_1" } });
  const mv = await mollie.verify("tr_123");
  assert.deepEqual([mv.paid, mv.amount, mv.currency, mv.orderId], [true, 1234.5, "EUR", "ord_1"]);
  await assert.rejects(mollie.verify("../admin"), /Invalid/);
  // A checkout URL on a foreign host is refused.
  responder = () => ({ id: "tr_9", _links: { checkout: { href: "https://evil.example/pay" } } });
  await assert.rejects(mollie.create(order, "https://shop.test"), /Unexpected/);

  // Razorpay: amount in paise, Basic auth, paid only when amount_paid covers amount.
  calls.length = 0;
  responder = () => ({ id: "plink_1", short_url: "https://rzp.io/i/abc" });
  await razorpay.create({ ...(order as object), currency: "INR" }, "https://shop.test");
  assert.equal(bodyOf(0).amount, 123450);
  assert.match(String((calls[0].init?.headers as Record<string, string>).Authorization), /^Basic /);
  responder = () => ({ id: "plink_1", status: "paid", amount: 123450, amount_paid: 123450, currency: "INR", notes: { orderId: "ord_1" } });
  const rv = await razorpay.verify("plink_1");
  assert.deepEqual([rv.paid, rv.amount], [true, 1234.5]);
  responder = () => ({ id: "plink_1", status: "partially_paid", amount: 123450, amount_paid: 100, currency: "INR" });
  assert.equal((await razorpay.verify("plink_1")).paid, false);

  // Paystack: kobo, unique reference, signature check.
  calls.length = 0;
  responder = () => ({ status: true, data: { authorization_url: "https://checkout.paystack.com/x", reference: "ORD-ABC123-r" } });
  const p = await paystack.create({ ...(order as object), currency: "NGN" }, "https://shop.test");
  assert.equal(bodyOf(0).amount, 123450);
  assert.equal(p.reference, "ORD-ABC123-r");
  responder = () => ({ data: { status: "success", amount: 123450, currency: "NGN", reference: "ORD-ABC123-r", metadata: { orderId: "ord_1" } } });
  assert.equal((await paystack.verify("ORD-ABC123-r")).amount, 1234.5);
  const { createHmac } = await import("node:crypto");
  const raw = '{"event":"charge.success"}';
  assert.equal(await paystack.validSignature(raw, createHmac("sha512", "sk_test_x").update(raw).digest("hex")), true);
  assert.equal(await paystack.validSignature(raw, "bad"), false);
  assert.equal(await paystack.validSignature(raw, null), false);

  // Flutterwave: tx_ref is our reference; verify uses the numeric transaction id.
  calls.length = 0;
  responder = () => ({ status: "success", data: { link: "https://checkout.flutterwave.com/v3/hosted/pay/x" } });
  const f = await flutterwave.create({ ...(order as object), currency: "KES" }, "https://shop.test");
  assert.equal(bodyOf(0).tx_ref, f.reference);
  responder = () => ({ data: { status: "successful", amount: 1234.5, currency: "KES", tx_ref: f.reference, meta: { orderId: "ord_1" } } });
  const fv = await flutterwave.verify("123456");
  assert.deepEqual([fv.paid, fv.reference], [true, f.reference]);
  await assert.rejects(flutterwave.verify("abc"), /Invalid/);

  // bKash: token grant, then create; verify executes and falls back to status query.
  calls.length = 0;
  responder = (url) =>
    url.endsWith("/token/grant")
      ? { id_token: "tok" }
      : { paymentID: "TR0011abc", bkashURL: "https://sandbox.payment.bkash.com/?paymentId=TR0011abc" };
  await assert.rejects(bkash.create(order, "https://shop.test"), /BDT/);
  const bk = await bkash.create({ ...(order as object), currency: "BDT" }, "https://shop.test");
  assert.equal(bk.reference, "TR0011abc");
  assert.ok(calls.some((c) => c.url.includes("tokenized.sandbox.bka.sh")));
  let n = 0;
  responder = (url) =>
    url.endsWith("/execute")
      ? { statusCode: "2062", statusMessage: "already completed" }
      : url.endsWith("/payment/status")
        ? (n++, { transactionStatus: "Completed", amount: "1234.50", currency: "BDT", paymentID: "TR0011abc", merchantInvoiceNumber: "ORD-ABC123" })
        : { id_token: "tok" };
  const bv = await bkash.verify("TR0011abc");
  assert.deepEqual([bv.paid, bv.amount, bv.invoice, n], [true, 1234.5, "ORD-ABC123", 1]);

  console.log("PASS: gateways (Mollie, Razorpay, Paystack, Flutterwave, bKash) request shape, minor units, host pinning, id validation, signature and API verification.");
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
