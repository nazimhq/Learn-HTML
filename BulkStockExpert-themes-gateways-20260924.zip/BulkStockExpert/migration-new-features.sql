-- BulkStockExpert Ltd (hr.sarvice.top) — schema changes for the new theme/dark-mode,
-- accounts/forgot-password, abandoned-checkout and notifications features.
-- Run this in phpMyAdmin against the sarvicet_bramleigh database.
-- Safe to run once; re-running will error on "already exists" (harmless — just skip those lines).

-- 1) Admin + customer "forgot password" tokens
CREATE TABLE IF NOT EXISTS `PasswordResetToken` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `tokenHash` VARCHAR(191) NOT NULL,
  `expiresAt` DATETIME(3) NOT NULL,
  `usedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PasswordResetToken_tokenHash_key` (`tokenHash`),
  KEY `PasswordResetToken_userId_idx` (`userId`),
  CONSTRAINT `PasswordResetToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) Link an order to the customer account that placed it (nullable — guests stay NULL)
ALTER TABLE `Order` ADD COLUMN `userId` VARCHAR(191) NULL AFTER `country`;
ALTER TABLE `Order` ADD CONSTRAINT `Order_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 3) Site-wide theme settings (accent colour preset + default light/dark)
ALTER TABLE `AppSettings` ADD COLUMN `accentTheme` VARCHAR(191) NOT NULL DEFAULT 'red';
ALTER TABLE `AppSettings` ADD COLUMN `colorMode` VARCHAR(191) NOT NULL DEFAULT 'light';

-- 4) Abandoned-checkout / lead capture
CREATE TABLE IF NOT EXISTS `AbandonedCheckout` (
  `id` VARCHAR(191) NOT NULL,
  `sessionId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `name` VARCHAR(191) NULL,
  `email` VARCHAR(191) NULL,
  `phone` VARCHAR(191) NULL,
  `addressLine1` VARCHAR(191) NULL,
  `addressLine2` VARCHAR(191) NULL,
  `city` VARCHAR(191) NULL,
  `county` VARCHAR(191) NULL,
  `postcode` VARCHAR(191) NULL,
  `country` VARCHAR(191) NULL,
  `itemsSnapshot` TEXT NOT NULL,
  `subtotal` DECIMAL(10,2) NULL,
  `stage` VARCHAR(191) NOT NULL DEFAULT 'CART',
  `convertedOrderId` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `AbandonedCheckout_sessionId_idx` (`sessionId`),
  KEY `AbandonedCheckout_email_idx` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5) In-admin-panel notification feed (new orders, etc.)
CREATE TABLE IF NOT EXISTS `Notification` (
  `id` VARCHAR(191) NOT NULL,
  `type` VARCHAR(191) NOT NULL,
  `message` TEXT NOT NULL,
  `orderId` VARCHAR(191) NULL,
  `isRead` BOOLEAN NOT NULL DEFAULT false,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Notification_isRead_idx` (`isRead`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
