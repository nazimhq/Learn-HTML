-- Additive migration for the supplied schema snapshot. Apply once after the four
-- existing migration files have been applied. Back up first; use staging first.
ALTER TABLE `PaymentSettings`
 MODIFY `stripePublishableKey` TEXT NULL,
 MODIFY `stripeSecretKey` TEXT NULL,
 MODIFY `stripeWebhookSecret` TEXT NULL,
 MODIFY `paypalClientId` TEXT NULL,
 MODIFY `paypalClientSecret` TEXT NULL;
ALTER TABLE `Order`
 ADD COLUMN `currency` VARCHAR(191) NOT NULL DEFAULT 'GBP',
 ADD COLUMN `paymentGateway` VARCHAR(191) NULL,
 ADD COLUMN `checkoutKey` VARCHAR(191) NULL,
 ADD COLUMN `stockRestoredAt` DATETIME(3) NULL,
 ADD UNIQUE INDEX `Order_checkoutKey_key` (`checkoutKey`);
ALTER TABLE `DeliveryZone` ADD COLUMN `countryCode` VARCHAR(191) NOT NULL DEFAULT 'GB';
CREATE TABLE `GatewayConfig` (
 `id` VARCHAR(191) NOT NULL,
 `enabled` BOOLEAN NOT NULL DEFAULT false,
 `mode` VARCHAR(191) NOT NULL DEFAULT 'sandbox',
 `credentials` TEXT NULL,
 `updatedAt` DATETIME(3) NOT NULL,
 PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE `EmailJob` (
 `id` VARCHAR(191) NOT NULL,
 `orderId` VARCHAR(191) NOT NULL,
 `kind` VARCHAR(191) NOT NULL,
 `attempts` INTEGER NOT NULL DEFAULT 0,
 `lockedUntil` DATETIME(3) NULL,
 `sentAt` DATETIME(3) NULL,
 `lastError` TEXT NULL,
 `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`),
 UNIQUE INDEX `EmailJob_orderId_kind_key` (`orderId`, `kind`),
 INDEX `EmailJob_sentAt_lockedUntil_idx` (`sentAt`, `lockedUntil`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
UPDATE `Order` SET `email`=LOWER(TRIM(`email`));
-- Historical cancelled orders already used the legacy restock workflow.
UPDATE `Order` SET `stockRestoredAt`=`updatedAt` WHERE `status`='CANCELLED';
