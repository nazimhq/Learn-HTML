# Verification record — 19 September 2026

Completed on the modified source:

- Prisma 5.22 schema parsed and generated client produced in-process using Prisma's own internals. Standard Prisma generation could not spawn its child process in this environment. Generated clients/engines are not included in the archive; generate on the deployment host.
- `node node_modules/typescript/bin/tsc --noEmit --pretty false`: PASS.
- `node tests/run.cjs`: PASS. Tests cover encryption randomization, roundtrip, tampering, wrong key, currency configuration/rounding, registry capability gating, mismatched payment amount/currency and multi-page invoice generation.
- Production bundle compilation: PASS on Next.js 15.5.25. `next build` did NOT complete: worker process creation returned `spawn EPERM`; a worker-thread attempt instead failed with `DataCloneError`. Normal worker configuration is restored in the delivered source. Run and pass the entire production build on staging before deployment.
- `npm audit --omit=dev`: 0 vulnerabilities reported at verification time.
- A 60-item BDT invoice with Bengali customer/address was rendered into five pages. All five rendered pages were visually inspected for clipping, missing characters and table/totals placement. Font files and licenses are included.

Not verified here:

- MySQL migration against the live or staging database; real order creation, concurrent stock transactions, admin authorization and email-job persistence against a running database.
- Provider sandbox/live payments, merchant eligibility, provider callbacks, SMTP delivery and scheduler execution.
- Browser end-to-end storefront/admin checks on a running migrated database, including mobile focus/theme behavior.
- Full production build/start and target-host smoke tests.

No live deployment, production database mutation, real charge or customer email was performed. See UPGRADE.md for specific remaining acceptance tests and the gateway capability boundary.
