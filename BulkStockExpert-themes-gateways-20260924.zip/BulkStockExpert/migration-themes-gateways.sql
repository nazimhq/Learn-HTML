-- Design themes, automatic theme rotation, and admin exchange rates (added 2026-09).
-- Additive only: creates two new tables and changes nothing existing. Safe to run once on
-- MySQL/MariaDB after backing up. "IF NOT EXISTS" makes a repeated run harmless.
-- Nothing else in the database needs changing for the new payment gateways: they reuse
-- Order.paymentGateway / Order.paymentReference / Order.currency and GatewayConfig.

CREATE TABLE IF NOT EXISTS `SiteTheme` (
    `id` VARCHAR(191) NOT NULL DEFAULT 'singleton',
    `skin` VARCHAR(191) NOT NULL DEFAULT 'classic',
    `rotationEnabled` BOOLEAN NOT NULL DEFAULT false,
    `rotationMode` VARCHAR(191) NOT NULL DEFAULT 'interval',
    `rotationHours` INTEGER NOT NULL DEFAULT 6,
    `timezone` VARCHAR(191) NOT NULL DEFAULT 'UTC',
    `slots` TEXT NULL,
    `updatedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `CurrencyRate` (
    `code` VARCHAR(191) NOT NULL,
    `rate` DECIMAL(18, 6) NOT NULL,
    `updatedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`code`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Super-admin flag used by Admin → Team. The application already read this column, but it was
-- missing from the schema; without it the Team page cannot be opened. Adds nothing else.
-- MySQL 8 / MariaDB 10.5+: "IF NOT EXISTS" keeps a repeat run harmless. On older MySQL, drop
-- the "IF NOT EXISTS" and skip this statement if the column is already present.
ALTER TABLE `User` ADD COLUMN IF NOT EXISTS `isSuperAdmin` BOOLEAN NOT NULL DEFAULT false;

-- Make the first/oldest admin a super admin so the Team page is reachable after upgrading.
UPDATE `User` SET `isSuperAdmin` = true
 WHERE `role` = 'ADMIN'
   AND NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM `User` WHERE `role` = 'ADMIN' AND `isSuperAdmin` = true LIMIT 1) AS t)
 ORDER BY `createdAt` ASC
 LIMIT 1;
