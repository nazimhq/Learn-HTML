-- BulkStockExpert Ltd (hr.sarvice.top) — part 3: Cash on Delivery + real Card/PayPal payments.
-- Run this in phpMyAdmin against sarvicet_bramleigh, IN ADDITION to the earlier migration files
-- (migration-new-features.sql, migration-part2-categories-products.sql) if you haven't already.

ALTER TABLE `Order` ADD COLUMN `paymentReference` VARCHAR(191) NULL;

CREATE TABLE `PaymentSettings` (
  `id` VARCHAR(191) NOT NULL DEFAULT 'singleton',
  `codEnabled` BOOLEAN NOT NULL DEFAULT true,
  `cardEnabled` BOOLEAN NOT NULL DEFAULT false,
  `stripePublishableKey` VARCHAR(191) NULL,
  `stripeSecretKey` VARCHAR(191) NULL,
  `stripeWebhookSecret` VARCHAR(191) NULL,
  `paypalEnabled` BOOLEAN NOT NULL DEFAULT false,
  `paypalClientId` VARCHAR(191) NULL,
  `paypalClientSecret` VARCHAR(191) NULL,
  `paypalMode` VARCHAR(191) NOT NULL DEFAULT 'sandbox',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed the singleton row with Cash on Delivery already on, Card/PayPal off until you paste in
-- real keys and flip them on from Admin → Settings → Payments.
INSERT INTO `PaymentSettings` (`id`, `codEnabled`) VALUES ('singleton', true);
