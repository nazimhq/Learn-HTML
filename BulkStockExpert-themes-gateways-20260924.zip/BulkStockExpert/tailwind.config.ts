import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  // Site-wide dark mode toggle: adds `dark:` variants, active whenever <html data-mode="dark">
  // is set (see ThemeToggle + the inline anti-flash script in layout.tsx).
  darkMode: ["selector", '[data-mode="dark"]'],
  theme: {
    extend: {
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        // Fixed faces used by the NEXAWEB design (also usable anywhere).
        grotesk: ['"Space Grotesk"', "Inter", "system-ui", "sans-serif"],
        inter: ['"Inter"', "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      colors: {
        ink: {
          50: "#f5f4f2",
          100: "#e8e5e0",
          400: "#7c7468",
          600: "#4a443b",
          800: "#241f19",
          900: "#171310",
        },
        // Brand tones are CSS variables (defaults in globals.css = the original hex values), so a
        // site design such as the NEXAWEB skin can re-tint them without touching components.
        brand: {
          50: "rgb(var(--brand-50) / <alpha-value>)",
          100: "rgb(var(--brand-100) / <alpha-value>)",
          300: "rgb(var(--brand-300) / <alpha-value>)",
          500: "rgb(var(--brand-500) / <alpha-value>)",
          600: "rgb(var(--brand-600) / <alpha-value>)",
          700: "rgb(var(--brand-700) / <alpha-value>)",
          900: "rgb(var(--brand-900) / <alpha-value>)",
        },
        // Accent is admin-selectable at runtime (Settings → Theme) via CSS variables set on
        // <html data-accent="...">, see globals.css. The <alpha-value> placeholder lets Tailwind
        // opacity modifiers (e.g. accent-500/25) keep working against the CSS-variable colour.
        accent: {
          400: "rgb(var(--accent-400) / <alpha-value>)",
          500: "rgb(var(--accent-500) / <alpha-value>)",
          600: "rgb(var(--accent-600) / <alpha-value>)",
        },
        // Text colour to use ON TOP of an accent-500/600 surface — flips light/dark per accent
        // preset (see globals.css) so e.g. a "Black" theme's near-black accent still gets light
        // text instead of the default dark text becoming invisible.
        "accent-fg": "rgb(var(--accent-fg) / <alpha-value>)",

        // ---- Fixed semantic palette (see globals.css for the CSS-variable values) ----
        // Not admin-switchable — brand-fixed roles applied consistently site-wide.
        cta: {
          DEFAULT: "rgb(var(--cta-500) / <alpha-value>)",
          600: "rgb(var(--cta-600) / <alpha-value>)",
        },
        discount: {
          DEFAULT: "rgb(var(--discount-500) / <alpha-value>)",
          600: "rgb(var(--discount-600) / <alpha-value>)",
        },
        deal: {
          DEFAULT: "rgb(var(--deal-500) / <alpha-value>)",
          600: "rgb(var(--deal-600) / <alpha-value>)",
        },
        voucher: "rgb(var(--voucher-500) / <alpha-value>)",
        success: "rgb(var(--success-500) / <alpha-value>)",
        combo: {
          DEFAULT: "rgb(var(--combo-500) / <alpha-value>)",
          600: "rgb(var(--combo-600) / <alpha-value>)",
        },
        crimson: {
          DEFAULT: "rgb(var(--crimson-500) / <alpha-value>)",
          600: "rgb(var(--crimson-600) / <alpha-value>)",
        },
        // Mode-aware page/card backgrounds — same class works in light and dark, see globals.css.
        surface: {
          DEFAULT: "rgb(var(--surface-canvas) / <alpha-value>)",
          alt: "rgb(var(--surface-alt) / <alpha-value>)",
        },
        panel: "rgb(var(--panel) / <alpha-value>)",
      },
    },
  },
  plugins: [],
};

export default config;
